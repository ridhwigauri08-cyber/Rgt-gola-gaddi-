"""
Public endpoints for the end-user app.

These are called by an app that anyone can download from the Play Store, so
there is no shared API key — a key shipped inside an APK is not a secret.

What that means for safety:
  * only non-sensitive data is exposed (today's rates WITHOUT floor/ceiling)
  * writes are limited to callback requests, with a per-phone rate limit
  * nothing here can change a rate, a booking or a call
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import settings
from .db import get_db
from .models import CallbackRequest, DailyRate, FreightCharge, Grain, LabourCharge

router = APIRouter(prefix="/public", tags=["public"])

COMPANY = {
    "name": "RGT Gola Gaddi",
    "legal_name": "Ridhwi Gauri Traders Pvt Ltd",
    "support_number": "06111-291499",
    "address": "Mandi Road, Kota, Rajasthan",
    "timings": "Subah 6:00 se shaam 8:00 baje tak (Mon-Sat)",
    "payment_terms": "Cash / UPI / Advance. Credit sirf approved parties ke liye.",
}


class CallbackIn(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    phone: str = Field(min_length=10, max_length=15)
    grain: str | None = None
    quantity_qtl: float | None = Field(default=None, ge=0, le=100000)
    note: str | None = Field(default=None, max_length=300)


@router.get("/info")
def info() -> dict[str, Any]:
    return COMPANY


@router.get("/rates")
def rates(db: Session = Depends(get_db)) -> dict[str, Any]:
    """Today's rates for the public app. Floor and ceiling are never included."""
    rows = db.scalars(
        select(DailyRate).join(Grain, DailyRate.grain_id == Grain.id).order_by(DailyRate.id.desc())
    ).all()

    seen: set[tuple[str, str]] = set()
    out: list[dict[str, Any]] = []
    for r in rows:
        key = (r.grain.name, r.grain.grade)
        if key in seen:  # keep the latest per grain+grade
            continue
        seen.add(key)
        out.append({
            "grain": r.grain.name,
            "grade": r.grain.grade,
            "rate_per_quintal": r.base_rate,
            "unit": "quintal",
            "currency": "INR",
            "valid_till": r.valid_till.isoformat() if r.valid_till else None,
            "status": r.status,
        })

    freight = db.scalars(select(FreightCharge).order_by(FreightCharge.zone)).all()
    labour = db.scalars(select(LabourCharge)).all()
    return {
        "rates": out,
        "labour": [
            {"type": l.type, "rate": l.rate, "unit": l.unit} for l in labour
        ],
        "freight": [
            {"zone": f.zone, "vehicle_type": f.vehicle_type,
             "rate_per_quintal": f.rate_per_qtl, "min_charge": f.min_charge}
            for f in freight
        ],
        "note": "Rates change daily. Loading/freight final quote par confirm hota hai.",
    }


@router.post("/callback")
def request_callback(body: CallbackIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    """Ask the company to call this number back."""
    phone = body.phone.strip().replace(" ", "")
    digits = "".join(ch for ch in phone if ch.isdigit())
    if len(digits) < 10:
        raise HTTPException(422, "phone number theek nahi hai")

    # Simple abuse guard: one request per number per minute.
    cutoff = datetime.utcnow() - timedelta(minutes=1)
    recent = db.scalar(
        select(CallbackRequest)
        .where(CallbackRequest.phone == phone, CallbackRequest.created_at >= cutoff)
        .limit(1)
    )
    if recent is not None:
        raise HTTPException(429, "Aapki request already mil chuki hai. 1 minute baad try karein.")

    req = CallbackRequest(
        name=body.name.strip(),
        phone=phone,
        grain=body.grain,
        quantity_qtl=body.quantity_qtl,
        note=body.note,
        status="new",
    )
    db.add(req)
    db.commit()
    db.refresh(req)
    return {
        "ok": True,
        "request_id": req.id,
        "message": "Dhanyavaad! Hum aapko thodi der mein call karenge.",
        "support_number": COMPANY["support_number"],
    }


@router.get("/callback", dependencies=[])
def list_callbacks(
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
) -> list[dict[str, Any]]:
    """Admin view of callback requests (used by the admin app)."""
    rows = db.scalars(
        select(CallbackRequest).order_by(CallbackRequest.id.desc()).limit(limit)
    ).all()
    return [
        {
            "id": r.id,
            "name": r.name,
            "phone": r.phone,
            "grain": r.grain,
            "quantity_qtl": r.quantity_qtl,
            "note": r.note,
            "status": r.status,
            "created_at": r.created_at.isoformat(),
        }
        for r in rows
    ]
