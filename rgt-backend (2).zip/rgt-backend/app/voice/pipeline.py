"""
Per-call conversation session.

Owns the turn loop for one live call: buffer the caller's speech, detect
end-of-utterance, transcribe, ask the agent, synthesise the reply and stream it
back as 20 ms mu-law frames. Handles barge-in (caller talks over the AI) and
writes every turn to the database so the dashboard sees it live.
"""
from __future__ import annotations

import asyncio
import base64
import logging
from typing import Awaitable, Callable

from sqlalchemy.orm import Session

from .. import sarvam
from ..db import SessionLocal
from ..models import Call, CallTurn, Caller
from . import audio
from .agent import respond

log = logging.getLogger("rgt.voice")

AudioSink = Callable[[bytes], Awaitable[None]]   # send one mu-law frame
ClearSink = Callable[[], Awaitable[None]]        # ask the carrier to drop queued audio


class CallSession:
    def __init__(
        self,
        call_id: int,
        send_audio: AudioSink,
        clear_audio: ClearSink,
        language: str = "hi-IN",
    ) -> None:
        self.call_id = call_id
        self._send_audio = send_audio
        self._clear_audio = clear_audio
        self.language = language

        self.vad = audio.Vad()
        self.history: list[dict] = []
        self.speaking = False
        self._barge_in = False
        self._speak_task: asyncio.Task | None = None
        self.closed = False
        self.recording = bytearray()

    # ------------------------------------------------------------ helpers

    def _db(self) -> Session:
        return SessionLocal()

    def _load_call(self, db: Session) -> Call | None:
        return db.get(Call, self.call_id)

    def _append_turn(self, speaker: str, text: str, text_hi: str | None = None) -> None:
        with self._db() as db:
            db.add(CallTurn(call_id=self.call_id, speaker=speaker, text=text, text_hi=text_hi))
            db.commit()

    # ------------------------------------------------------------ audio in

    async def on_audio_frame(self, mulaw_frame: bytes) -> None:
        """Feed one 20 ms mu-law frame from the carrier."""
        if self.closed:
            return
        self.recording.extend(mulaw_frame)

        pcm = audio.ulaw_to_pcm16(mulaw_frame)

        # Barge-in: caller speaks while we are talking -> stop and listen.
        if self.speaking and audio.frame_rms(pcm) >= self.vad.threshold:
            self._barge_in = True
            if self._speak_task and not self._speak_task.done():
                self._speak_task.cancel()
            self.speaking = False
            try:
                await self._clear_audio()
            except Exception:
                pass

        if self.vad.push(pcm):
            utterance = self.vad.take()
            if utterance:
                asyncio.create_task(self._handle_utterance(utterance))

    # ------------------------------------------------------------ turn loop

    async def _handle_utterance(self, pcm: bytes) -> None:
        if not sarvam.is_configured():
            log.warning("call %s: audio received but SARVAM_API_KEY is not set", self.call_id)
            return
        try:
            wav = audio.pcm16_to_wav_bytes(pcm, audio.TELEPHONY_RATE)
            stt = await sarvam.transcribe(wav, "utterance.wav", self.language, "transcribe")
            text = (stt.get("transcript") or "").strip()
        except Exception as exc:
            log.warning("call %s: STT failed: %s", self.call_id, exc)
            return
        if not text:
            return
        await self.handle_text(text, persist_caller=True)

    async def handle_text(self, user_text: str, persist_caller: bool = True) -> str:
        """Run one full turn from text. Returns the assistant's reply text."""
        if persist_caller:
            self._append_turn("caller", user_text)

        with self._db() as db:
            call = self._load_call(db)
            reply = await respond(db, call, user_text, self.history)

        self.history.append({"role": "user", "content": user_text})
        self.history.append({"role": "assistant", "content": reply.text})
        self._append_turn("ai", reply.text)

        await self._speak(reply.text)
        return reply.text

    # ------------------------------------------------------------ audio out

    async def _speak(self, text: str) -> None:
        if not text or not sarvam.is_configured():
            return
        try:
            tts = await sarvam.speak(text, self.language)
            mulaw = audio.wav_base64_to_telephony_mulaw(tts.get("audio_base64", ""))
        except Exception as exc:
            log.warning("call %s: TTS failed: %s", self.call_id, exc)
            return
        if not mulaw:
            return

        self.speaking = True
        self._barge_in = False
        self._speak_task = asyncio.create_task(self._stream_mulaw(mulaw))

    async def _stream_mulaw(self, mulaw: bytes) -> None:
        try:
            for i in range(0, len(mulaw), 160):
                if self._barge_in or self.closed:
                    break
                await self._send_audio(mulaw[i:i + 160])
                await asyncio.sleep(0.02)  # real-time pacing
        except asyncio.CancelledError:
            pass
        finally:
            self.speaking = False

    # ------------------------------------------------------------ lifecycle

    async def close(self) -> None:
        self.closed = True
        if self._speak_task and not self._speak_task.done():
            self._speak_task.cancel()
        with self._db() as db:
            call = self._load_call(db)
            if call is not None:
                from datetime import datetime
                call.ended_at = datetime.utcnow()
                db.commit()


class SessionRegistry:
    """Keeps live sessions addressable (e.g. for dashboard takeover)."""

    def __init__(self) -> None:
        self._sessions: dict[int, CallSession] = {}

    def add(self, session: CallSession) -> None:
        self._sessions[session.call_id] = session

    def get(self, call_id: int) -> CallSession | None:
        return self._sessions.get(call_id)

    def remove(self, call_id: int) -> None:
        self._sessions.pop(call_id, None)

    def count(self) -> int:
        return len(self._sessions)


registry = SessionRegistry()


def ensure_call(phone: str, name: str | None = None, language: str = "hi-IN") -> int:
    """Find or create the Call row for an inbound number."""
    with SessionLocal() as db:
        caller = db.query(Caller).filter(Caller.phone == phone).one_or_none()
        if caller is None:
            caller = Caller(phone=phone, name=name, village=None)
            db.add(caller)
            db.commit()
            db.refresh(caller)
        call = Call(caller_id=caller.id, language=language, status="ai")
        db.add(call)
        db.commit()
        db.refresh(call)
        return call.id


def decode_twilio_payload(payload_b64: str) -> bytes:
    return base64.b64decode(payload_b64)


def encode_twilio_payload(mulaw: bytes) -> str:
    return base64.b64encode(mulaw).decode("ascii")
