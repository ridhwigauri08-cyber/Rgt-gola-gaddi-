#!/usr/bin/env bash
#
# RGT Gola Gaddi - Control API : cURL cookbook  (v2 - includes agent tools)
#
# Usage:
#   export BASE_URL="https://your-public-host"    # NOT localhost if Sarvam's cloud must reach it
#   export API_KEY="your-app-api-key"
#   bash rgt-api-examples.sh
#
# Sections:
#   1. Health + auth
#   2. AGENT TOOLS   <- paste these into Sarvam's "Configure HTTP Tool"
#   3. Dashboard     <- for the Android app / supervisor screens
#   4. Voice + telephony
#   5. WebSockets
#
# NOTE: no `set -e` on purpose - several examples demonstrate expected 4xx.

set -uo pipefail

BASE_URL="${BASE_URL:-http://localhost:8000}"
API_KEY="${API_KEY:-dev-key-change-me}"

json() { python3 -m json.tool 2>/dev/null || cat; }
say()  { printf '\n\033[1m== %s ==\033[0m\n' "$1"; }

AUTH=(-H "X-API-Key: $API_KEY")
JSON=(-H "Content-Type: application/json")

# ==========================================================================
# 1. Health + auth
# ==========================================================================

say "GET /health  (only endpoint that needs no key)"
curl -s "$BASE_URL/health" | json

say "401 example - missing key"
curl -s -o /dev/null -w 'HTTP %{http_code}\n' "$BASE_URL/agent/get_rate" \
  -X POST "${JSON[@]}" -d '{"grain":"Gehu"}'

# ==========================================================================
# 2. AGENT TOOLS  ->  Sarvam "Configure HTTP Tool"
#
#    For every tool in the Sarvam builder:
#      Method : POST
#      Auth   : API Key  ->  key name "X-API-Key", value = $API_KEY
#      Headers: only Content-Type: application/json (delete everything else)
#
#    Response fields to map with @field:
#      get_rate -> @rate_per_quintal
#      quote    -> @landed_per_quintal  @landed_total
#      bargain  -> @offer_per_quintal   @action   @instruction
#      book     -> @total               @status
# ==========================================================================

say "GET /agent/manifest  (public - lists every tool + body shape)"
curl -s "$BASE_URL/agent/manifest" | json

say "TOOL get_rate"
curl -s -X POST "$BASE_URL/agent/get_rate" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"grain":"Gehu","grade":"FAQ"}' | json

say "TOOL get_rate - unknown grain (soft failure, agent should offer callback)"
curl -s -X POST "$BASE_URL/agent/get_rate" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"grain":"Rajma"}' | json

say "TOOL quote - 40 qtl Gehu, Rampur pickup"
curl -s -X POST "$BASE_URL/agent/quote" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"grain":"Gehu","quantity_qtl":40,"zone":"Rampur","vehicle_type":"pickup"}' | json

say "TOOL bargain - round 0 (first offer)"
curl -s -X POST "$BASE_URL/agent/bargain" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"grain":"Gehu","caller_ask":2600,"round_no":0}' | json

say "TOOL bargain - round 1 (caller pushed again)"
curl -s -X POST "$BASE_URL/agent/bargain" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"grain":"Gehu","caller_ask":2600,"round_no":1}' | json

say "TOOL bargain - rounds exhausted -> action=escalate"
curl -s -X POST "$BASE_URL/agent/bargain" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"grain":"Gehu","caller_ask":2600,"round_no":3}' | json

say "TOOL book - confirm the deal"
curl -s -X POST "$BASE_URL/agent/book" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"caller_name":"Ramesh Yadav","grain":"Gehu","quantity_qtl":40,
       "final_rate":2510,"labour":1400,"freight":1800,"delivery_date":"2026-10-26"}' | json

say "TOOL book - rejected (note the opaque reason, no floor hint)"
curl -s -X POST "$BASE_URL/agent/book" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"caller_name":"Ramesh Yadav","grain":"Gehu","quantity_qtl":40,"final_rate":1000}' | json

say "TOOL escalate - complaints / legal / abuse"
curl -s -X POST "$BASE_URL/agent/escalate" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"reason":"caller ne gaali di"}' | json

say "TOOL info - godown address / timing / payment"
curl -s -X POST "$BASE_URL/agent/info" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"topic":"address"}' | json

# ==========================================================================
# 3. Dashboard endpoints
#
#    WARNING: these DO return floor_rate / ceiling_rate because a supervisor
#    needs to see them. Never expose them to a language model - use /agent/*.
# ==========================================================================

say "GET /rates - all configured rates"
curl -s "$BASE_URL/rates" "${AUTH[@]}" | json

say "GET /rates/current - includes floor_rate (dashboard only)"
curl -s "$BASE_URL/rates/current?grain=Gehu&grade=FAQ" "${AUTH[@]}" | json

say "POST /rates/publish - morning rate push"
curl -s -X POST "$BASE_URL/rates/publish" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"published_by":"Rate Manager","approve":true,"rates":[
        {"grain":"Bajra","grade":"FAQ","location":"Kota","base_rate":2360,
         "floor_rate":2320,"ceiling_rate":2400,"step":10,"max_rounds":3,
         "direction":"up","valid_till":"2026-10-26T20:00:00"}]}' | json

say "422 example - floor higher than base (rejected)"
curl -s -o /dev/null -w 'HTTP %{http_code}\n' -X POST "$BASE_URL/rates/publish" \
  "${AUTH[@]}" "${JSON[@]}" \
  -d '{"rates":[{"grain":"Gehu","grade":"FAQ","base_rate":2400,"floor_rate":2500}]}'

say "POST /pricing/quote - dashboard version (full breakdown)"
curl -s -X POST "$BASE_URL/pricing/quote" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"grain":"Gehu","grade":"FAQ","quantity_qtl":40,"zone":"Rampur",
       "vehicle_type":"pickup","loading_by":"us"}' | json

say "POST /bargain/next - dashboard version (includes floor_rate)"
curl -s -X POST "$BASE_URL/bargain/next" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"grain":"Gehu","grade":"FAQ","round_no":1,"caller_ask":2600}' | json

say "GET /calls/live"
curl -s "$BASE_URL/calls/live" "${AUTH[@]}" | json

say "GET /calls"
curl -s "$BASE_URL/calls" "${AUTH[@]}" | json

say "POST /calls - create a call record"
curl -s -X POST "$BASE_URL/calls" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"phone":"+919812345678","name":"Ramesh Yadav","village":"Rampur",
       "grain":"Gehu","quantity_qtl":40,"language":"hi-IN"}' | json

say "POST /calls/1/turns - append a transcript turn"
curl -s -X POST "$BASE_URL/calls/1/turns" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"speaker":"caller","text":"Gehu ka bhaav kya hai?","text_hi":"गेहूँ का भाव क्या है?"}' | json

say "POST /calls/1/instruction - live instruction"
curl -s -X POST "$BASE_URL/calls/1/instruction" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"text":"Deal close karo","type":"quick","issued_by":"Supervisor"}' | json

say "409 example - instruction that breaks the floor guard"
curl -s -X POST "$BASE_URL/calls/1/instruction" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"text":"Is party ko 3000 de do","issued_by":"Supervisor"}' | json

say "Same instruction with admin override"
curl -s -X POST "$BASE_URL/calls/1/instruction" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"text":"Is party ko 3000 de do","issued_by":"Admin","admin_override":true}' | json

say "POST /calls/1/takeover"
curl -s -X POST "$BASE_URL/calls/1/takeover" "${AUTH[@]}" | json

say "POST /bookings"
curl -s -X POST "$BASE_URL/bookings" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"call_id":1,"caller_name":"Ramesh Yadav","phone":"+919812345678",
       "grain":"Gehu","quantity_qtl":40,"final_rate":2500,
       "labour":1400,"freight":1800,"delivery_date":"2026-10-26"}' | json

say "GET /bookings"
curl -s "$BASE_URL/bookings" "${AUTH[@]}" | json

say "PATCH /bookings/1"
curl -s -X PATCH "$BASE_URL/bookings/1" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"status":"confirmed"}' | json

say "GET /analytics/summary"
curl -s "$BASE_URL/analytics/summary" "${AUTH[@]}" | json

# ==========================================================================
# 4. Voice + telephony
# ==========================================================================

say "GET /voice/status"
curl -s "$BASE_URL/voice/status" | json

say "POST /voice/simulate - full AI turn, no phone needed"
curl -s -X POST "$BASE_URL/voice/simulate" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"text":"gehu ka rate kya hai","phone":"+919812345678"}' | json

say "POST /voice/speak - needs SARVAM_API_KEY"
curl -s -X POST "$BASE_URL/voice/speak" "${AUTH[@]}" "${JSON[@]}" \
  -d '{"text":"Namaste, RGT Gola Gaddi.","language_code":"hi-IN"}' \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); print("request_id:", d.get("request_id")); print("audio b64 len:", len(d.get("audio_base64","")))' 2>/dev/null || true

say "POST /voice/transcribe - needs SARVAM_API_KEY (mono 16kHz WAV, <=30s)"
curl -s -X POST "$BASE_URL/voice/transcribe?language_code=hi-IN&mode=transcribe" \
  "${AUTH[@]}" -F "file=@sample.wav" | json

say "POST /telephony/twilio/voice - TwiML for Twilio (XML)"
curl -s -X POST "$BASE_URL/telephony/twilio/voice" \
  -d "From=%2B919812345678" -d "CallSid=CA1234567890"

# ==========================================================================
# 5. WebSockets (curl cannot do these - use wscat)
# ==========================================================================

say "Live monitor + Twilio media stream"
echo "wscat -c \"ws://localhost:8000/calls/live/ws?api_key=$API_KEY\""
echo "wscat -c \"wss://<your-host>/telephony/twilio/stream\""

printf '\n\033[1mDone.\033[0m  BASE_URL=%s\n\n' "$BASE_URL"
