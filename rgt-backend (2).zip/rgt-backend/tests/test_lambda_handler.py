"""
Tests for the AWS Lambda entry point.

The handler is invoked with real API Gateway HTTP API (payload 2.0) events, so
this exercises the same code path Lambda will.
"""
import json
import os
import pathlib

DB_PATH = pathlib.Path(__file__).parent / "test_rgt.db"
os.environ.setdefault("DATABASE_URL", f"sqlite:///{DB_PATH}")
os.environ.setdefault("APP_API_KEY", "test-key")
os.environ.setdefault("SARVAM_API_KEY", "")

import pytest  # noqa: E402

from app import lambda_handler as lh  # noqa: E402
from app.config import settings  # noqa: E402


def evt(path, method="GET", body=None, headers=None):
    return {
        "version": "2.0",
        "routeKey": "$default",
        "rawPath": path,
        "rawQueryString": "",
        "headers": headers or {"host": "test.example.com"},
        "requestContext": {
            "http": {"method": method, "path": path,
                     "protocol": "HTTP/1.1", "sourceIp": "1.2.3.4"},
            "stage": "$default",
        },
        "body": body,
        "isBase64Encoded": False,
    }


def invoke(path, method="GET", body=None, headers=None):
    r = lh.handler(evt(path, method, body, headers), None)
    payload = None
    if r.get("body"):
        try:
            payload = json.loads(r["body"])
        except (json.JSONDecodeError, TypeError):
            payload = r["body"]
    return r["statusCode"], payload


def test_health_through_lambda():
    code, body = invoke("/health")
    assert code == 200
    assert body["status"] == "ok"


def test_public_rates_through_lambda():
    code, body = invoke("/public/rates")
    assert code == 200
    assert len(body["rates"]) >= 7
    # the public endpoint must never expose the hidden price band
    assert "floor_rate" not in json.dumps(body)
    assert "ceiling_rate" not in json.dumps(body)


def test_agent_tool_requires_key_through_lambda():
    code, _ = invoke("/agent/get_rate", "POST", json.dumps({"grain": "Gehu"}),
                     {"host": "x", "content-type": "application/json"})
    assert code == 401

    code, body = invoke("/agent/get_rate", "POST", json.dumps({"grain": "Gehu"}),
                        {"host": "x", "content-type": "application/json",
                         "x-api-key": "test-key"})
    assert code == 200
    assert body["rate_per_quintal"] == 2500


def test_webhook_route_reachable_over_http():
    """Webhooks are plain POSTs, so they work even though WS does not."""
    code, body = invoke("/sarvam/webhook", "POST", json.dumps({}),
                        {"host": "x", "content-type": "application/json"})
    # 503 because WEBHOOK_TOKEN is not set in tests - but it routed correctly
    assert code == 503


def test_sqlite_guard_raises_on_lambda(monkeypatch):
    monkeypatch.setenv("AWS_LAMBDA_FUNCTION_NAME", "rgt-api")
    monkeypatch.setattr(settings, "database_url", "sqlite:///./rgt.db")
    with pytest.raises(lh.LambdaConfigError) as err:
        lh.ensure_lambda_safe_config()
    assert "SQLite" in str(err.value)


def test_sqlite_guard_allows_postgres(monkeypatch):
    monkeypatch.setenv("AWS_LAMBDA_FUNCTION_NAME", "rgt-api")
    monkeypatch.setattr(settings, "database_url",
                        "postgresql+psycopg://u:p@host:5432/rgt?sslmode=require")
    lh.ensure_lambda_safe_config()  # must not raise


def test_guard_is_noop_off_lambda(monkeypatch):
    monkeypatch.delenv("AWS_LAMBDA_FUNCTION_NAME", raising=False)
    monkeypatch.setattr(settings, "database_url", "sqlite:///./rgt.db")
    lh.ensure_lambda_safe_config()  # local dev keeps working
