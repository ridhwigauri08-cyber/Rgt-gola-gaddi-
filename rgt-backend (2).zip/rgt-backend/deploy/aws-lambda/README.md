# Deploying the RGT Control API on AWS Lambda

API Gateway (HTTP API) → Lambda (container image) → FastAPI via Mangum.

---

## Read this first — what changes on Lambda

| | Under uvicorn / App Runner | On Lambda |
|---|---|---|
| Database | SQLite is fine | **RDS Postgres required.** Lambda's disk is read-only and `/tmp` is wiped between invocations |
| WebSockets (`/calls/live/ws`, `/telephony/twilio/stream`) | work | **not reachable** — API Gateway WebSockets are a different programming model |
| Cold start | none | 1–3 s unless you enable provisioned concurrency |
| Request timeout | none | **29 s** (API Gateway hard limit) |
| Startup work | once | `create_all` + seed runs on **every cold start** |

None of these break the Sarvam hosted-agent setup: the dashboard and the agent
only use plain HTTP endpoints. `/voice/transcribe` is the one to watch — 30 s
audio can exceed the 29 s gateway limit.

The code refuses to start on Lambda with a SQLite URL (`app/lambda_handler.py`),
so you get a clear error instead of silently losing data.

---

## 1. Prerequisites

- **RDS Postgres** created and reachable (the Terraform in `deploy/aws/terraform`
  creates one; you can apply just that part)
- Docker
- AWS CLI v2 configured
- A Lambda execution role:

```bash
aws iam create-role --role-name rgt-lambda-role \
  --assume-role-policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},"Action":"sts:AssumeRole"}]}'

aws iam attach-role-policy --role-name rgt-lambda-role \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

# only if the database is in a private VPC:
aws iam attach-role-policy --role-name rgt-lambda-role \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole
```

## 2. Configure

```bash
cd deploy/aws-lambda
cp env.lambda.example env.lambda
# edit env.lambda: DATABASE_URL, APP_API_KEY, ROLE_ARN, X_API_KEY, ...
```

## 3. Deploy

```bash
chmod +x deploy.sh
./deploy.sh
```

This builds `linux/amd64`, pushes to ECR, and creates or updates the function.
The script prints the exact API Gateway commands to run next.

## 4. Put API Gateway in front (console)

1. **API Gateway → Create API → HTTP API → Build**
2. Add integration: **Lambda** → your function → payload format **2.0**
3. Route: `ANY /{proxy+}`
4. Stage: `$default`, auto-deploy **on**
5. Copy the **Invoke URL**

Then test:

```bash
curl -s "https://<api-id>.execute-api.ap-south-1.amazonaws.com/health"
```

If you get `{"status":"ok"}`, the Lambda path is live.

## 5. VPC (only if RDS is private)

Lambda needs to sit in the same VPC. Console → **Configuration → VPC → Edit** →
pick two private subnets and a security group that the RDS security group
allows on 5432.

A private subnet with no NAT gateway cannot reach the internet, which breaks the
Sarvam API calls. Either put the function in a subnet with a NAT gateway, or
leave RDS publicly accessible with a locked-down security group.

## 6. Kill cold starts

For a voice agent, a 1–3 s cold start mid-call is not acceptable:

```bash
aws lambda put-provisioned-concurrency-config \
  --function-name rgt-api --qualifier '$LATEST' \
  --provisioned-concurrent-executions 1 --region ap-south-1
```

---

## Cost sketch (ap-south-1)

| Item | ~Monthly |
|---|---|
| Lambda (1 GB, provisioned concurrency 1) | ~$15 |
| API Gateway HTTP API | ~$1 |
| RDS db.t4g.micro | ~$14 |
| NAT gateway (if used) | ~$35 ⚠️ |
| **Total** | **~$30 without NAT, ~$65 with** |

The NAT gateway is the surprise cost. If you can reach RDS without a private
subnet, skip it.

---

## Updating the code

```bash
./deploy.sh      # rebuild, push, update-function-code
```

## Verified vs not verified

- The handler was invoked locally with real API Gateway HTTP API v2 events:
  `/health` → 200, `/public/rates` → 200 (7 grains), `/agent/get_rate` with a
  key → 200, without a key → 401. The SQLite-on-Lambda guard is unit-tested.
- **The image has not been built or pushed**, and nothing was deployed to AWS —
  this environment has no Docker daemon and no AWS credentials. Run
  `./deploy.sh` and read its output; if the image build fails it will be on the
  `public.ecr.aws/lambda/python:3.12` base or a missing system library.
