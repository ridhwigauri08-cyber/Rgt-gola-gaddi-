"""
App-facing endpoints for the Sarvam Voice Agent.

The Android dashboard calls these. They proxy to Sarvam so the workspace API key
never leaves the server.

    GET  /sarvam/status                      is it wired up? which deployment?
    GET  /sarvam/calls                       recent calls (list)
    GET  /sarvam/call/{interaction_id}       one call + transcript + cost
    GET  /sarvam/call/{interaction_id}/recording
    POST /sarvam/dial                        place an outbound AI call
    POST /sarvam/webhook                     Sarvam -> us (call completion)
    GET  /sarvam/events                      webhook events we stored
"""
from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import sarvam_agents
from .config import settings
from .db import get_db
from .models import SarvamEvent

router = APIRouter(prefix="/sarvam", tags=["sarvam-agent"])


def require_api_key(x_api_key: str | None = Header(default=None, alias="X-API-Key")) -> None:
    if not x_api_key or x_api_key != settings.app_api_key:
        raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key header")


protected = [Depends(require_api_key)]


def _fail(exc: sarvam_agents.SarvamAgentsError) -> HTTPException:
    if exc.status_code in (401, 403):
        return HTTPException(502, f"Sarvam rejected our credentials: {exc}")
    if exc.status_code is not None:
        return HTTPException(502, f"Sarvam API error {exc.status_code}: {exc.body[:200]}")
    return HTTPException(503, str(exc))


# --------------------------------------------------------------------------
# Status
# --------------------------------------------------------------------------

@router.get("/status", dependencies=protected)
async def status() -> dict[str, Any]:
    out: dict[str, Any] = {
        "configured": sarvam_agents.is_configured(),
        "org_id": settings.sarvam_org_id or None,
        "workspace_id": settings.sarvam_workspace_id or None,
        "app_id": settings.sarvam_app_id or None,
        "deployment_id": settings.sarvam_deployment_id or None,
        "outbound_ready": bool(settings.sarvam_connection_id and settings.sarvam_agent_phone_number),
        "cost_per_minute_inr": settings.sarvam_cost_per_minute,
        "webhook_configured": bool(settings.webhook_token),
    }
    if not sarvam_agents.is_configured():
        out["hint"] = (
            "Set X_API_KEY (workspace key, sent as the X-API-Key header), "
            "SARVAM_ORG_ID, SARVAM_WORKSPACE_ID and SARVAM_APP_ID on the server."
        )
        return out

    try:
        deployment = await sarvam_agents.get_deployment()
        out["deployment"] = {
            "found": deployment is not None,
            "name": (deployment or {}).get("name"),
            "status": (deployment or {}).get("status"),
            "phone_numbers": (deployment or {}).get("phone_numbers"),
            "channel_direction": (deployment or {}).get("channel_direction"),
            "app_version": (deployment or {}).get("app_version"),
        }
    except sarvam_agents.SarvamAgentsError as exc:
        out["deployment"] = {"found": False, "error": str(exc)}
    return out


# --------------------------------------------------------------------------
# Calls
# --------------------------------------------------------------------------

@router.get("/calls", dependencies=protected)
async def list_calls(
    hours: int = Query(24, ge=1, le=24 * 30),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    with_transcript: bool = False,
) -> dict[str, Any]:
    try:
        raw = await sarvam_agents.list_interactions(
            hours=hours, limit=limit, offset=offset, include_transcript=with_transcript
        )
    except sarvam_agents.SarvamAgentsError as exc:
        raise _fail(exc)

    items = [sarvam_agents.normalise_interaction(i) for i in raw.get("items", [])]
    return {
        "total": raw.get("total"),
        "limit": raw.get("limit"),
        "offset": raw.get("offset"),
        "next_page_uri": raw.get("next_page_uri"),
        "calls": items,
    }


@router.get("/call/{interaction_id:path}", dependencies=protected)
async def get_call(interaction_id: str) -> dict[str, Any]:
    try:
        transcript = await sarvam_agents.get_transcript(interaction_id)
    except sarvam_agents.SarvamAgentsError as exc:
        raise _fail(exc)

    messages = transcript.get("messages") or []
    turns = [
        {
            "speaker": "AI" if (m.get("role") or "").lower() in ("assistant", "agent") else "Caller",
            "text": m.get("content", ""),
            "language": m.get("language_name"),
            "turn": m.get("turn_id"),
        }
        for m in messages
    ]
    return {
        "interaction_id": transcript.get("interaction_id", interaction_id),
        "turn_count": len(turns),
        "transcript": turns,
        "recording_available": True,
        "recording_url": f"/sarvam/call/{interaction_id}/recording",
    }


@router.get("/call/{interaction_id:path}/recording", dependencies=protected)
async def get_recording(interaction_id: str) -> Response:
    try:
        content, content_type = await sarvam_agents.get_recording(interaction_id)
    except sarvam_agents.SarvamAgentsError as exc:
        raise _fail(exc)
    return Response(content=content, media_type=content_type)


# --------------------------------------------------------------------------
# Outbound
# --------------------------------------------------------------------------

class DialIn(BaseModel):
    phone: str = Field(description="E.164, e.g. +919812345678")
    app_version: int | None = None
    language: str | None = None
    agent_variables: dict[str, Any] | None = None


@router.post("/dial", dependencies=protected)
async def dial(body: DialIn) -> dict[str, Any]:
    if not body.phone.startswith("+"):
        raise HTTPException(422, "phone must be in E.164 format, e.g. +919812345678")
    try:
        result = await sarvam_agents.create_outbound(
            user_phone_number=body.phone,
            app_version=body.app_version,
            agent_variables=body.agent_variables,
            language=body.language,
        )
    except sarvam_agents.SarvamAgentsError as exc:
        raise _fail(exc)
    return {"ok": True, "attempt_id": result.get("attempt_id"), "phone": body.phone}


# --------------------------------------------------------------------------
# Webhook receiver
# --------------------------------------------------------------------------

@router.post("/webhook")
async def webhook(
    request: Request,
    x_webhook_token: str | None = Header(default=None, alias="X-Webhook-Token"),
    token: str | None = Query(default=None),
    db: Session = Depends(get_db),
) -> dict[str, Any]:
    """
    Sarvam POSTs the call result here (campaign `app_config.webhook_config` or
    the `webhook_config` on an instant outbound call).

    Sarvam does not document a request signature, so we authenticate with a
    shared token: either the `X-Webhook-Token` header or `?token=` in the URL.
    """
    if not settings.webhook_token:
        raise HTTPException(503, "WEBHOOK_TOKEN is not set on the server")
    if (x_webhook_token or token or "") != settings.webhook_token:
        raise HTTPException(401, "invalid webhook token")

    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "body must be JSON")

    transcript = payload.get("interaction_transcript")
    event = SarvamEvent(
        interaction_id=payload.get("interaction_id"),
        attempt_id=payload.get("attempt_id"),
        app_id=payload.get("app_id"),
        caller_number=payload.get("user_phone_number"),
        agent_phone_number=payload.get("agent_phone_number"),
        direction=payload.get("channel_direction") or payload.get("direction"),
        completion_status=payload.get("completion_status"),
        connectivity_status=payload.get("connectivity_status"),
        duration_sec=payload.get("duration"),
        started_at=payload.get("start_datetime"),
        ended_at=payload.get("end_datetime"),
        transcript_json=json.dumps(transcript, ensure_ascii=False) if transcript else None,
        raw_json=json.dumps(payload, ensure_ascii=False),
    )
    db.add(event)
    db.commit()
    db.refresh(event)
    return {"ok": True, "event_id": event.id}


@router.get("/events", dependencies=protected)
def list_events(limit: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.scalars(select(SarvamEvent).order_by(SarvamEvent.id.desc()).limit(limit)).all()
    return [
        {
            "id": e.id,
            "interaction_id": e.interaction_id,
            "attempt_id": e.attempt_id,
            "caller_number": e.caller_number,
            "completion_status": e.completion_status,
            "connectivity_status": e.connectivity_status,
            "duration_sec": e.duration_sec,
            "started_at": e.started_at,
            "ended_at": e.ended_at,
            "cost_inr": sarvam_agents.estimate_cost_inr(e.duration_sec),
            "transcript": json.loads(e.transcript_json) if e.transcript_json else None,
            "received_at": e.received_at.isoformat(),
        }
        for e in rows
    ]
