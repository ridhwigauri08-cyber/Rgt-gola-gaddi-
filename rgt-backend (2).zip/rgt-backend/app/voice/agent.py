"""
The conversation brain.

The LLM handles language and turn-taking only. Every rupee figure it speaks
comes from a tool call (PRD rule BG-2), and a post-generation number guard
throws away any reply containing a price the tools never produced
(PRD section 13, "LLM hallucinate kare" -> number-guard).

If SARVAM_API_KEY is absent, `respond` falls back to a deterministic scripted
agent so the whole pipeline still runs end to end in development.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy.orm import Session

from .. import sarvam
from ..models import Call
from . import tools

SYSTEM_PROMPT = """Tum RGT Gola Gaddi ke AI voice assistant ho. RGT Gola Gaddi ek anaaj
(grain) trading firm hai — kisan aur vyapari apna maal bechne ke liye call karte hain.

BAAT KARNE KA TARIKA
- Hindi ya Hinglish me baat karo, jaisa caller bole. Simple gaon ke shabd use karo.
- Chhote jawab do — ek turn me 1-2 vaakya. Phone par lambi baat achhi nahi lagti.
- Saaf, dheeme, izzat se. Caller ko "ji" se bulao.

SABSE ZAROORI NIYAM
- Koi bhi rate, price ya paisa ka number tum apne se mat bolo. Sirf tool se aaya
  number bolo. Agar tool nahi bulaya to number bolna hi nahi hai.
- Minimum/floor rate ka zikr kabhi mat karo — wo caller ko nahi batana hai.
- Agar rate set nahi hai ya stale hai, to kaho "abhi rate update ho raha hai" aur
  callback ya human offer karo.
- Complaint, legal, payment dispute, ya gaali — turant escalate_to_human.
- Agar caller poochhe ki tum insaan ho ya nahi, saaf bata do ki tum AI assistant ho.

CALL FLOW
1. Namaste + madad poochho.
2. Anaaj, quantity, gaon poochho.
3. get_rate se rate lo, calculate_price se landed price batao.
4. Bhaav-taav par next_bargain_offer use karo. Jo offer aaye wahi bolo.
5. Caller haan bole to create_booking. Nahi to callback offer karo.

Deal tabhi confirm karo jab caller saaf "haan" bole, aur final rate dohra do.
"""

MAX_TOOL_ROUNDS = 4


@dataclass
class AgentReply:
    text: str
    used_tools: list[str] = field(default_factory=list)
    guard_passed: bool = True
    offline: bool = False


# --------------------------------------------------------------------------
# Number guard
# --------------------------------------------------------------------------

_NUM_RE = re.compile(r"\d[\d,]*")


def extract_numbers(text: str) -> set[int]:
    out: set[int] = set()
    for m in _NUM_RE.findall(text or ""):
        try:
            out.add(int(m.replace(",", "")))
        except ValueError:
            continue
    return out


def _numbers_in(obj: Any) -> set[int]:
    """Every integer that appears anywhere inside a tool result."""
    found: set[int] = set()

    def walk(node: Any) -> None:
        if isinstance(node, bool):
            return
        if isinstance(node, (int, float)):
            found.add(int(round(node)))
        elif isinstance(node, str):
            found |= extract_numbers(node)
        elif isinstance(node, dict):
            for v in node.values():
                walk(v)
        elif isinstance(node, (list, tuple)):
            for v in node:
                walk(v)

    walk(obj)
    return found


def numbers_ok(reply: str, allowed: set[int], min_price: int = 100) -> bool:
    """
    True when the reply does not contain a price-like number that the tools
    never produced. Small numbers (1-99) are allowed because they are usually
    quantities, round numbers or "ek second".
    """
    for n in extract_numbers(reply):
        if n >= min_price and n not in allowed:
            return False
    return True


# --------------------------------------------------------------------------
# Online agent (Sarvam)
# --------------------------------------------------------------------------

async def _online_reply(
    db: Session, call: Call | None, user_text: str, history: list[dict]
) -> AgentReply:
    context_bits = []
    if call:
        context_bits.append(f"Caller ka number: {call.caller.phone if call.caller else 'unknown'}")
        if call.grain_name:
            context_bits.append(f"Anaaj: {call.grain_name}")
        if call.quantity_qtl:
            context_bits.append(f"Quantity: {call.quantity_qtl} quintal")
        if call.offered_rate:
            context_bits.append(f"Abhi tak ka best offer: Rs {call.offered_rate:.0f}/qtl")
    system = SYSTEM_PROMPT + ("\n\nIS CALL KA CONTEXT\n" + "\n".join(context_bits) if context_bits else "")

    messages: list[dict] = [{"role": "system", "content": system}]
    messages.extend(history[-8:])
    messages.append({"role": "user", "content": user_text})

    used: list[str] = []
    allowed: set[int] = extract_numbers(user_text) | set(range(1, 100))

    for _ in range(MAX_TOOL_ROUNDS):
        resp = await sarvam.chat(messages, tools=tools.TOOLS)
        choice = (resp.get("choices") or [{}])[0]
        msg = choice.get("message") or {}
        tool_calls = msg.get("tool_calls") or []

        if tool_calls:
            messages.append({
                "role": "assistant",
                "content": msg.get("content") or "",
                "tool_calls": tool_calls,
            })
            for tc in tool_calls:
                fn = (tc.get("function") or {})
                name = fn.get("name", "")
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                except json.JSONDecodeError:
                    args = {}
                result = tools.execute(db, call, name, args)
                used.append(name)
                allowed |= _numbers_in(result)
                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.get("id", name),
                    "name": name,
                    "content": json.dumps(result, ensure_ascii=False),
                })
            continue

        text = (msg.get("content") or "").strip()
        if not text:
            break

        if numbers_ok(text, allowed):
            return AgentReply(text=text, used_tools=used, guard_passed=True)

        # One corrective retry, then give up on this reply.
        messages.append({"role": "assistant", "content": text})
        messages.append({
            "role": "system",
            "content": (
                "STOP. Tumne ek rate bolo jo tool se nahi aaya. Sirf tool se aaya "
                "number bolo, warna bina number ke jawab do."
            ),
        })
        retry = await sarvam.chat(messages, tools=tools.TOOLS)
        retry_msg = ((retry.get("choices") or [{}])[0]).get("message") or {}
        retry_text = (retry_msg.get("content") or "").strip()
        if retry_text and numbers_ok(retry_text, allowed):
            return AgentReply(text=retry_text, used_tools=used, guard_passed=True)

        return AgentReply(
            text="Ji, is rate par main abhi confirm nahi kar sakta. Main aapko malik se "
                 "poochkar 5 minute me call karwa deta hoon.",
            used_tools=used,
            guard_passed=False,
        )

    return AgentReply(
        text="Ji, ek second \u2014 main aapki baat note kar raha hoon.",
        used_tools=used,
        guard_passed=True,
    )


# --------------------------------------------------------------------------
# Offline agent (no Sarvam key) - deterministic, uses the same tools
# --------------------------------------------------------------------------

_BARGAIN_HINTS = ("badha", "kam", "zyada", "thoda", "aur", "chhoot", "adjust", "bhav", "bhaav")
_YES_HINTS = ("haan", "ha ", "theek", "thik", "kar do", "book", "chalega", "ok")
_GRAINS = ("gehu", "chana", "sarson", "soyabean", "makka", "bajra")
_COMPLAINT = ("complaint", "shikayat", "legal", "court", "gaali", "bakwas", "dhokha")


def _offline_reply(db: Session, call: Call | None, user_text: str) -> AgentReply:
    low = user_text.lower().strip()

    if any(w in low for w in _COMPLAINT):
        tools.execute(db, call, "escalate_to_human", {"reason": "complaint/dispute"})
        return AgentReply(
            text="Ji, main aapka call humare supervisor se jod raha hoon. Ek second.",
            used_tools=["escalate_to_human"], offline=True,
        )

    grain = next((g for g in _GRAINS if g in low), None)
    if grain:
        grain = grain.title()
        if call is not None:
            call.grain_name = grain
            db.commit()

    known_grain = grain or (call.grain_name if call else None)

    # Bargaining
    if any(w in low for w in _BARGAIN_HINTS) and known_grain:
        ask = extract_numbers(user_text)
        ask_val = max(ask) if ask else None
        res = tools.execute(db, call, "next_bargain_offer",
                            {"grain": known_grain, "caller_ask": ask_val})
        if "error" in res:
            return AgentReply(text="Ji, abhi rate update ho raha hai.", used_tools=["next_bargain_offer"], offline=True)
        offer = int(res["offer"])
        if res["action"] == "escalate":
            text = (f"Ji, isse zyada abhi mere haath me nahi hai. Main aapko malik se "
                    f"poochkar 5 minute me call karwa doon?")
        elif res["action"] == "close":
            text = f"Ji theek hai, {offer} rupaye prati quintal par booking kar doon?"
        else:
            text = f"Ji, main aapke liye {offer} rupaye prati quintal kar deta hoon."
        return AgentReply(text=text, used_tools=["next_bargain_offer"], offline=True)

    # Booking confirmation
    if any(w in low for w in _YES_HINTS) and call and call.offered_rate and known_grain:
        res = tools.execute(db, call, "create_booking", {
            "caller_name": (call.caller.name if call.caller and call.caller.name else "Kisan"),
            "grain": known_grain,
            "quantity_qtl": call.quantity_qtl or 10,
            "final_rate": call.offered_rate,
        })
        if "error" not in res:
            return AgentReply(
                text=f"Ji booking confirm ho gayi. {int(call.offered_rate)} rupaye prati quintal. Dhanyavaad!",
                used_tools=["create_booking"], offline=True,
            )

    # Rate question
    if known_grain and ("rate" in low or "bhav" in low or "bhaav" in low or "kitna" in low):
        res = tools.execute(db, call, "get_rate", {"grain": known_grain})
        if "error" in res:
            return AgentReply(text=res.get("say", "Ji, abhi rate update ho raha hai."),
                              used_tools=["get_rate"], offline=True)
        return AgentReply(
            text=(f"Ji, aaj {known_grain} ka bhaav {int(res['base_rate'])} rupaye prati quintal hai. "
                  f"Aap kitna quintal laa rahe hain?"),
            used_tools=["get_rate"], offline=True,
        )

    # Greeting / unknown
    return AgentReply(
        text="Namaste, RGT Gola Gaddi me aapka swagat hai. Kaunsa anaaj bechna hai aur kitna quintal?",
        used_tools=[], offline=True,
    )


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

async def respond(
    db: Session,
    call: Call | None,
    user_text: str,
    history: list[dict] | None = None,
) -> AgentReply:
    history = history or []
    if sarvam.is_configured():
        try:
            return await _online_reply(db, call, user_text, history)
        except Exception:
            # Never drop a live call because the LLM is down.
            return _offline_reply(db, call, user_text)
    return _offline_reply(db, call, user_text)
