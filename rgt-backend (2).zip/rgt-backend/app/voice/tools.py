"""
Tools the voice agent may call.

Rule BG-2 from the PRD: the LLM never invents a rate. Every number it speaks
must come back from one of these tools, and the floor/ceiling is deliberately
withheld from the tool output so the model cannot leak it.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..engines import LabourLine, compute_quote, next_offer
from ..models import Booking, Call, DailyRate, FreightCharge, Grain, LabourCharge, QuantitySlab

# --------------------------------------------------------------------------
# JSON schemas handed to the model
# --------------------------------------------------------------------------

TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "get_rate",
            "description": (
                "Aaj ka rate (per quintal) for a grain. Call this before quoting any "
                "price. Returns base_rate only - never guess a number."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "grain": {"type": "string", "description": "e.g. Gehu, Chana, Sarson, Soyabean, Makka, Bajra"},
                    "grade": {"type": "string", "description": "FAQ, Mill, Desi", "default": "FAQ"},
                },
                "required": ["grain"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculate_price",
            "description": (
                "Landed price for a quantity: grain + labour + freight + other - discount. "
                "Use this whenever the caller asks what it will cost or what they will get."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "grain": {"type": "string"},
                    "quantity_qtl": {"type": "number"},
                    "zone": {"type": "string", "description": "caller's village / freight zone"},
                    "vehicle_type": {"type": "string", "description": "pickup, 407, 10-wheeler, trailer"},
                    "loading_by": {"type": "string", "enum": ["us", "caller"], "default": "us"},
                },
                "required": ["grain", "quantity_qtl"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "next_bargain_offer",
            "description": (
                "When the caller asks for a better rate. Returns the next allowed offer and "
                "what to do (offer / close / escalate). Never quote a number yourself."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "grain": {"type": "string"},
                    "caller_ask": {"type": "number", "description": "rate the caller is asking for"},
                },
                "required": ["grain", "caller_ask"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_booking",
            "description": "Confirm a deal. Only call after the caller clearly says yes.",
            "parameters": {
                "type": "object",
                "properties": {
                    "caller_name": {"type": "string"},
                    "grain": {"type": "string"},
                    "quantity_qtl": {"type": "number"},
                    "final_rate": {"type": "number"},
                    "labour": {"type": "number"},
                    "freight": {"type": "number"},
                    "delivery_date": {"type": "string"},
                },
                "required": ["caller_name", "grain", "quantity_qtl", "final_rate"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "escalate_to_human",
            "description": (
                "Transfer to a supervisor. Use for complaints, legal or payment disputes, "
                "abuse, or when the caller insists beyond what you are allowed to offer."
            ),
            "parameters": {
                "type": "object",
                "properties": {"reason": {"type": "string"}},
                "required": ["reason"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_mandi_info",
            "description": "Godown address, timings, payment terms and other static info.",
            "parameters": {
                "type": "object",
                "properties": {
                    "topic": {"type": "string", "enum": ["address", "timing", "payment", "general"]}
                },
                "required": ["topic"],
            },
        },
    },
]

TOOL_NAMES = {t["function"]["name"] for t in TOOLS}


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def _rate_for(db: Session, grain: str, grade: str = "FAQ") -> DailyRate | None:
    return db.scalar(
        select(DailyRate)
        .join(Grain, DailyRate.grain_id == Grain.id)
        .where(Grain.name == grain, Grain.grade == grade)
        .order_by(DailyRate.id.desc())
        .limit(1)
    )


def _labour(db: Session, grain: str, loading_by: str) -> list[LabourLine]:
    rows = db.scalars(
        select(LabourCharge).where(LabourCharge.grain_name.in_([grain, "*"]))
    ).all()
    out: list[LabourLine] = []
    for r in rows:
        if r.type == "loading" and loading_by == "caller":
            continue
        out.append(LabourLine(type=r.type, rate=r.rate, unit=r.unit))
    return out


def _freight(db: Session, zone: str, vehicle: str) -> FreightCharge | None:
    return db.scalar(
        select(FreightCharge).where(
            FreightCharge.zone == zone, FreightCharge.vehicle_type == vehicle
        ).limit(1)
    )


# --------------------------------------------------------------------------
# Executor
# --------------------------------------------------------------------------

def execute(db: Session, call: Call | None, name: str, args: dict[str, Any]) -> dict[str, Any]:
    """Run a tool. Always returns a JSON-able dict, never raises."""
    try:
        if name == "get_rate":
            grain = str(args.get("grain", "")).strip().title()
            grade = str(args.get("grade", "FAQ") or "FAQ")
            rate = _rate_for(db, grain, grade)
            if rate is None:
                return {"error": "rate_not_found",
                        "say": "Abhi is anaaj ka rate set nahi hai, main callback le leta hoon."}
            stale = rate.valid_till is not None and rate.valid_till < datetime.utcnow()
            if stale:
                return {"error": "rate_update_pending",
                        "say": "Abhi rate update ho raha hai, main aapko 5 minute me call karwa deta hoon."}
            # NOTE: floor_rate and ceiling_rate are intentionally not returned.
            return {
                "grain": grain,
                "grade": grade,
                "base_rate": rate.base_rate,
                "unit": "per quintal",
                "currency": "INR",
            }

        if name == "calculate_price":
            grain = str(args.get("grain", "")).strip().title()
            qty = float(args.get("quantity_qtl", 0) or 0)
            if qty <= 0:
                return {"error": "bad_quantity", "say": "Kitna quintal maal hai, bata dijiye."}
            rate = _rate_for(db, grain)
            if rate is None:
                return {"error": "rate_not_found"}
            zone = str(args.get("zone", "Rampur") or "Rampur")
            vehicle = str(args.get("vehicle_type", "pickup") or "pickup")
            loading_by = str(args.get("loading_by", "us") or "us")
            freight = _freight(db, zone, vehicle)

            slab = db.scalar(
                select(QuantitySlab)
                .where(QuantitySlab.rate_id == rate.id, QuantitySlab.min_qty <= qty)
                .order_by(QuantitySlab.min_qty.desc())
                .limit(1)
            )
            q = compute_quote(
                grain_rate=rate.base_rate,
                quantity_qtl=qty,
                labour_lines=_labour(db, grain, loading_by),
                freight_rate_per_qtl=freight.rate_per_qtl if freight else 0.0,
                freight_min_charge=freight.min_charge if freight else 0.0,
                discount_per_qtl=slab.extra_discount if slab else 0.0,
            )
            return {
                "grain": grain,
                "quantity_qtl": qty,
                "grain_rate": q.grain_rate,
                "labour": q.labour_total,
                "freight": q.freight_total,
                "discount": q.discount_total,
                "landed_total": q.landed_total,
                "landed_per_qtl": q.landed_per_qtl,
                "currency": "INR",
            }

        if name == "next_bargain_offer":
            grain = str(args.get("grain", "")).strip().title()
            ask = args.get("caller_ask")
            ask_val = float(ask) if ask is not None else None
            rate = _rate_for(db, grain)
            if rate is None:
                return {"error": "rate_not_found"}
            explicit_round = args.get("round_no")
            if explicit_round is not None:
                round_no = int(explicit_round)
            elif call is not None:
                round_no = call.round_no + 1
            else:
                round_no = 0
            result = next_offer(
                base_rate=rate.base_rate,
                floor_rate=rate.floor_rate,
                step=rate.step,
                max_rounds=rate.max_rounds,
                round_no=round_no,
                caller_ask=ask_val,
                previous_offer=call.offered_rate if call else None,
                ceiling_rate=rate.ceiling_rate,
                direction=rate.direction,
            )
            if call:
                call.offered_rate = result.offer
                call.round_no = result.round_no
                if result.action == "escalate":
                    call.status = "human"
                db.commit()
            return {
                "offer": result.offer,
                "action": result.action,
                "round_no": result.round_no,
                "remaining_rounds": result.remaining_rounds,
                "at_limit": result.at_limit,
                "currency": "INR",
            }

        if name == "create_booking":
            grain = str(args.get("grain", "")).strip().title()
            qty = float(args.get("quantity_qtl", 0) or 0)
            final_rate = float(args.get("final_rate", 0) or 0)
            labour = float(args.get("labour", 0) or 0)
            freight = float(args.get("freight", 0) or 0)
            name_caller = str(args.get("caller_name", "Unknown"))

            # Guard: never book below the floor, whatever the model says.
            rate = _rate_for(db, grain)
            if rate is not None and final_rate < rate.floor_rate:
                return {"error": "below_floor",
                        "say": "Is rate par booking nahi ho sakti, main malik se baat karke batata hoon."}

            booking = Booking(
                call_id=call.id if call else None,
                caller_name=name_caller,
                phone=call.caller.phone if call and call.caller else "",
                grain_name=grain,
                quantity_qtl=qty,
                final_rate=final_rate,
                labour=labour,
                freight=freight,
                total=round(final_rate * qty + labour + freight, 2),
                delivery_date=str(args.get("delivery_date") or ""),
                status="new",
            )
            db.add(booking)
            if call:
                call.outcome = "booked"
            db.commit()
            db.refresh(booking)
            return {
                "booking_id": booking.id,
                "total": booking.total,
                "final_rate": booking.final_rate,
                "status": booking.status,
                "currency": "INR",
            }

        if name == "escalate_to_human":
            if call:
                call.status = "human"
                call.outcome = "escalated"
                db.commit()
            return {"status": "transferred", "reason": str(args.get("reason", ""))}

        if name == "get_mandi_info":
            topic = str(args.get("topic", "general"))
            info = {
                "address": "RGT Gola Gaddi, Mandi Road, Kota",
                "timing": "Subah 6 baje se shaam 8 baje tak",
                "payment": "Cash, UPI ya advance. Credit sirf approved parties ke liye.",
                "general": "RGT Gola Gaddi, a unit of Ridhwi Gauri Traders Pvt Ltd.",
            }
            return {"topic": topic, "info": info.get(topic, info["general"])}

        return {"error": "unknown_tool", "name": name}
    except Exception as exc:  # never break a live call because a tool failed
        return {"error": "tool_failed", "name": name, "detail": str(exc)[:200]}
