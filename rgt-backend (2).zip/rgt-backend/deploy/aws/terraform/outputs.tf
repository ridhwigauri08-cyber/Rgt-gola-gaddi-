output "service_url" {
  description = "Public HTTPS base URL of the API (empty until deploy_service = true)."
  value       = try("https://${aws_apprunner_service.api[0].service_url}", "")
}

output "service_arn" {
  description = "App Runner service ARN (empty until deploy_service = true)."
  value       = try(aws_apprunner_service.api[0].arn, "")
}

output "ecr_repository_url" {
  description = "Push your image here."
  value       = aws_ecr_repository.api.repository_url
}

output "database_endpoint" {
  description = "RDS host:port (private)."
  value       = "${aws_db_instance.postgres.address}:${aws_db_instance.postgres.port}"
}

output "secret_arns" {
  description = "Secrets Manager entries holding runtime configuration."
  value = {
    database_url   = aws_secretsmanager_secret.db_url.arn
    app_api_key    = aws_secretsmanager_secret.app_key.arn
    sarvam_api_key = aws_secretsmanager_secret.sarvam_key.arn
  }
}

output "app_api_key" {
  description = "The X-API-Key to configure in the Android app and the Sarvam HTTP tool."
  value       = random_password.app_api_key.result
  sensitive   = true
}
