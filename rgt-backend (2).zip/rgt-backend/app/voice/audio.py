"""
Audio helpers.

Twilio Media Streams speak G.711 mu-law, 8 kHz, mono, in 20 ms frames
(160 bytes per frame). Sarvam wants a normal audio file (WAV recommended) and
returns base64 WAV. This module converts between the two.

Implemented in pure Python so it does not depend on `audioop`, which was
removed from the standard library in Python 3.13.
"""
from __future__ import annotations

import base64
import io
import struct
import wave
from array import array

TELEPHONY_RATE = 8000
FRAME_MS = 20
FRAME_BYTES = TELEPHONY_RATE * FRAME_MS // 1000 * 2  # 16-bit mono -> 320 bytes


# --------------------------------------------------------------------------
# G.711 mu-law
# --------------------------------------------------------------------------

def _build_decode_table() -> list[int]:
    table = []
    for i in range(256):
        u = (~i) & 0xFF
        t = ((u & 0x0F) << 3) + 0x84
        t <<= (u & 0x70) >> 4
        table.append((0x84 - t) if (u & 0x80) else (t - 0x84))
    return table


_ULAW_DECODE = _build_decode_table()


def _build_exp_table() -> list[int]:
    """Canonical G.711 exponent lookup: index -> number of significant bits."""
    exp = [0] * 256
    for i in range(256):
        if i < 2:
            exp[i] = 0
        elif i < 4:
            exp[i] = 1
        elif i < 8:
            exp[i] = 2
        elif i < 16:
            exp[i] = 3
        elif i < 32:
            exp[i] = 4
        elif i < 64:
            exp[i] = 5
        elif i < 128:
            exp[i] = 6
        else:
            exp[i] = 7
    return exp


_EXP_LUT = _build_exp_table()
_BIAS = 0x84
_CLIP = 32635


def ulaw_to_pcm16(data: bytes) -> bytes:
    """Decode G.711 mu-law bytes to signed 16-bit little-endian PCM."""
    out = array("h", bytes(len(data) * 2))
    for i, b in enumerate(data):
        out[i] = _ULAW_DECODE[b]
    return out.tobytes()


def pcm16_to_ulaw(pcm: bytes) -> bytes:
    """Encode signed 16-bit little-endian PCM to G.711 mu-law."""
    if len(pcm) % 2:
        pcm = pcm[:-1]
    samples = array("h")
    samples.frombytes(pcm)
    out = bytearray(len(samples))
    for i, s in enumerate(samples):
        sign = (s >> 8) & 0x80
        if sign:
            s = -s
        if s > _CLIP:
            s = _CLIP
        s += _BIAS
        exponent = _EXP_LUT[(s >> 7) & 0xFF]
        mantissa = (s >> (exponent + 3)) & 0x0F
        out[i] = (~(sign | (exponent << 4) | mantissa)) & 0xFF
    return bytes(out)


# --------------------------------------------------------------------------
# Resampling (linear; adequate for telephony speech)
# --------------------------------------------------------------------------

def resample_pcm16(pcm: bytes, src_rate: int, dst_rate: int) -> bytes:
    if src_rate == dst_rate or not pcm:
        return pcm
    samples = array("h")
    samples.frombytes(pcm[: len(pcm) - (len(pcm) % 2)])
    n = len(samples)
    if n == 0:
        return b""
    ratio = src_rate / float(dst_rate)
    out_len = int(n / ratio)
    out = array("h", bytes(out_len * 2))
    for i in range(out_len):
        pos = i * ratio
        i0 = int(pos)
        i1 = i0 + 1 if i0 + 1 < n else n - 1
        frac = pos - i0
        v = samples[i0] * (1.0 - frac) + samples[i1] * frac
        out[i] = int(max(-32768, min(32767, v)))
    return out.tobytes()


# --------------------------------------------------------------------------
# Containers
# --------------------------------------------------------------------------

def decode_to_pcm16_mono(raw: bytes) -> tuple[bytes, int]:
    """
    Accepts a WAV file (any common rate / width / channel count) or raw 16-bit
    PCM, and returns (mono 16-bit PCM, sample_rate).
    """
    if raw[:4] == b"RIFF" and raw[8:12] == b"WAVE":
        with wave.open(io.BytesIO(raw), "rb") as w:
            channels = w.getnchannels()
            width = w.getsampwidth()
            rate = w.getframerate()
            frames = w.readframes(w.getnframes())

        if width == 1:  # 8-bit unsigned -> 16-bit signed
            pcm = array("h", bytes(len(frames) * 2))
            for i, b in enumerate(frames):
                pcm[i] = (b - 128) << 8
            pcm_bytes = pcm.tobytes()
        elif width == 2:
            pcm_bytes = frames
        elif width == 3:  # 24-bit -> 16-bit
            n = len(frames) // 3
            pcm = array("h", bytes(n * 2))
            for i in range(n):
                b0, b1, b2 = frames[i * 3], frames[i * 3 + 1], frames[i * 3 + 2]
                pcm[i] = struct.unpack("<h", bytes((b1, b2)))[0]
            pcm_bytes = pcm.tobytes()
        elif width == 4:
            n = len(frames) // 4
            pcm = array("h", bytes(n * 2))
            for i in range(n):
                val = struct.unpack("<i", frames[i * 4:(i + 1) * 4])[0]
                pcm[i] = max(-32768, min(32767, val >> 16))
            pcm_bytes = pcm.tobytes()
        else:
            raise ValueError(f"unsupported sample width: {width}")

        if channels > 1:
            samples = array("h")
            samples.frombytes(pcm_bytes)
            n = len(samples) // channels
            mono = array("h", bytes(n * 2))
            for i in range(n):
                total = 0
                for c in range(channels):
                    total += samples[i * channels + c]
                mono[i] = int(total / channels)
            pcm_bytes = mono.tobytes()

        return pcm_bytes, rate

    # Assume raw 16-bit PCM at telephony rate.
    return raw, TELEPHONY_RATE


def wav_base64_to_telephony_mulaw(audio_b64: str, assume_rate: int = 24000) -> bytes:
    """Sarvam returns base64 WAV; convert to 8 kHz mu-law for the phone line."""
    raw = base64.b64decode(audio_b64)
    pcm, rate = decode_to_pcm16_mono(raw)
    if rate != TELEPHONY_RATE:
        pcm = resample_pcm16(pcm, rate, TELEPHONY_RATE)
    return pcm16_to_ulaw(pcm)


def telephony_mulaw_to_wav(mulaw: bytes, path: str) -> None:
    """Save a call recording as an 8 kHz WAV."""
    pcm = ulaw_to_pcm16(mulaw)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(TELEPHONY_RATE)
        w.writeframes(pcm)


def pcm16_to_wav_bytes(pcm: bytes, rate: int = TELEPHONY_RATE) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return buf.getvalue()


# --------------------------------------------------------------------------
# Voice activity detection
# --------------------------------------------------------------------------

def frame_rms(pcm16: bytes) -> float:
    """Root-mean-square energy of a 16-bit PCM frame."""
    if len(pcm16) < 2:
        return 0.0
    samples = array("h")
    samples.frombytes(pcm16[: len(pcm16) - (len(pcm16) % 2)])
    if not samples:
        return 0.0
    total = 0
    for s in samples:
        total += s * s
    return (total / len(samples)) ** 0.5


class Vad:
    """
    Simple energy-based end-of-utterance detector.

    Tuned for 8 kHz telephony speech: a frame is "speech" when its RMS clears
    `threshold`, and the utterance ends after `silence_ms` of quiet frames.
    """

    def __init__(self, threshold: float = 500.0, silence_ms: int = 700,
                 min_speech_ms: int = 200, max_utterance_ms: int = 20000):
        self.threshold = threshold
        self.silence_frames_needed = max(1, silence_ms // FRAME_MS)
        self.min_speech_frames = max(1, min_speech_ms // FRAME_MS)
        self.max_frames = max_utterance_ms // FRAME_MS

        self.frames: list[bytes] = []
        self.speech_frames = 0
        self.silence_run = 0
        self.in_speech = False

    def push(self, frame: bytes) -> bool:
        """Add a frame; returns True when a complete utterance is ready."""
        self.frames.append(frame)
        if frame_rms(frame) >= self.threshold:
            self.in_speech = True
            self.speech_frames += 1
            self.silence_run = 0
        else:
            if self.in_speech:
                self.silence_run += 1

        if len(self.frames) >= self.max_frames:
            return True
        if self.in_speech and self.silence_run >= self.silence_frames_needed:
            return True
        return False

    def take(self) -> bytes:
        """Return the buffered utterance and reset."""
        data = b"".join(self.frames)
        usable = self.speech_frames >= self.min_speech_frames
        self.frames = []
        self.speech_frames = 0
        self.silence_run = 0
        self.in_speech = False
        return data if usable else b""

    @property
    def has_speech(self) -> bool:
        return self.speech_frames >= self.min_speech_frames
