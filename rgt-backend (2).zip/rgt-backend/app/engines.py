"""
Deterministic pricing and bargaining logic.

Design rule from the PRD (BG-1, BG-2): the LLM never invents a number. Every
rate the assistant speaks comes from these pure functions, and the floor is
enforced here in code, not in the prompt.
"""
from __future__ import annotations

from dataclasses import dataclass, field


# --------------------------------------------------------------------------
# Rate validation (dashboard-side guardrails)
# --------------------------------------------------------------------------

def validate_rate(
    base_rate: float,
    floor_rate: float,
    step: float,
    max_rounds: int,
    previous_base: float | None = None,
    ceiling_rate: float | None = None,
) -> list[str]:
    """Return a list of human-readable warnings. Empty list means clean."""
    warnings: list[str] = []

    if base_rate <= 0:
        warnings.append("Base rate must be greater than zero.")
    if floor_rate > base_rate:
        warnings.append("Floor rate cannot be higher than base rate (floor <= base).")
    if step < 0:
        warnings.append("Step size cannot be negative.")
    if step > (base_rate - floor_rate):
        warnings.append("Step size cannot exceed the total margin (step <= margin).")
    if max_rounds < 0 or max_rounds > 10:
        warnings.append("Max rounds should be between 0 and 10.")
    if ceiling_rate is not None and ceiling_rate < base_rate:
        warnings.append("Ceiling cannot be below base (ceiling >= base).")
    if previous_base and previous_base > 0:
        jump = abs(base_rate - previous_base) / previous_base * 100.0
        if jump > 5.0:
            warnings.append(
                f"Unusual jump: {jump:.1f}% vs previous base rate (over 5%). Please re-check."
            )
    return warnings


# --------------------------------------------------------------------------
# Landed price
# --------------------------------------------------------------------------

@dataclass
class LabourLine:
    type: str
    rate: float
    unit: str = "qtl"


@dataclass
class QuoteBreakdown:
    grain_rate: float
    quantity_qtl: float
    grain_total: float
    labour_total: float
    freight_total: float
    other_charges: float
    discount_total: float
    landed_total: float
    landed_per_qtl: float
    lines: list[dict] = field(default_factory=list)


def compute_quote(
    grain_rate: float,
    quantity_qtl: float,
    labour_lines: list[LabourLine] | None = None,
    freight_rate_per_qtl: float = 0.0,
    freight_min_charge: float = 0.0,
    other_charges_per_qtl: float = 0.0,
    discount_per_qtl: float = 0.0,
    discount_total_override: float | None = None,
) -> QuoteBreakdown:
    """
    Final Price = Negotiated Grain Rate
                + Labour (loading/tulai/silai)
                + Freight (zone x vehicle x quantity)
                + Other charges (mandi fee, GST where applicable)
                - Quantity/Payment discount
    """
    if quantity_qtl <= 0:
        raise ValueError("quantity_qtl must be greater than zero")

    lines: list[dict] = []
    grain_total = grain_rate * quantity_qtl
    lines.append({
        "head": "Grain rate",
        "rate": round(grain_rate, 2),
        "unit": "per qtl",
        "amount": round(grain_total, 2),
    })

    labour_total = 0.0
    for line in (labour_lines or []):
        if line.unit == "qtl":
            amount = line.rate * quantity_qtl
        elif line.unit == "truck":
            amount = line.rate
        elif line.unit == "bori":
            # ~1 bori = 0.5 quintal in the mandi trade
            amount = line.rate * (quantity_qtl / 0.5)
        else:
            amount = line.rate * quantity_qtl
        labour_total += amount
        lines.append({
            "head": f"Labour ({line.type})",
            "rate": round(line.rate, 2),
            "unit": f"per {line.unit}",
            "amount": round(amount, 2),
        })

    freight_total = max(freight_rate_per_qtl * quantity_qtl, freight_min_charge)
    lines.append({
        "head": "Freight",
        "rate": round(freight_rate_per_qtl, 2),
        "unit": "per qtl",
        "amount": round(freight_total, 2),
    })

    other_total = other_charges_per_qtl * quantity_qtl
    if other_total:
        lines.append({
            "head": "Other charges",
            "rate": round(other_charges_per_qtl, 2),
            "unit": "per qtl",
            "amount": round(other_total, 2),
        })

    if discount_total_override is not None:
        discount_total = max(discount_total_override, 0.0)
    else:
        discount_total = max(discount_per_qtl * quantity_qtl, 0.0)
    if discount_total:
        lines.append({
            "head": "Discount",
            "rate": round(-discount_total, 2),
            "unit": "total",
            "amount": round(-discount_total, 2),
        })

    landed_total = grain_total + labour_total + freight_total + other_total - discount_total
    return QuoteBreakdown(
        grain_rate=round(grain_rate, 2),
        quantity_qtl=quantity_qtl,
        grain_total=round(grain_total, 2),
        labour_total=round(labour_total, 2),
        freight_total=round(freight_total, 2),
        other_charges=round(other_total, 2),
        discount_total=round(discount_total, 2),
        landed_total=round(landed_total, 2),
        landed_per_qtl=round(landed_total / quantity_qtl, 2),
        lines=lines,
    )


# --------------------------------------------------------------------------
# Bargaining
# --------------------------------------------------------------------------

@dataclass
class OfferResult:
    offer: float
    round_no: int
    direction: str
    action: str            # offer | close | hold | escalate
    at_limit: bool
    remaining_rounds: int
    floor_rate: float
    base_rate: float
    message: str
    reached_floor: bool


def next_offer(
    base_rate: float,
    floor_rate: float,
    step: float,
    max_rounds: int,
    round_no: int = 0,
    caller_ask: float | None = None,
    previous_offer: float | None = None,
    ceiling_rate: float | None = None,
    direction: str = "down",
) -> OfferResult:
    """
    Compute the next allowed offer.

    direction="down": the assistant starts at base and concedes downward, never
        below floor_rate. (PRD section 6.2 worked example.)
    direction="up": the assistant starts at base and concedes upward, never
        above ceiling_rate. (Matches the sample dialogue in PRD section 22,
        where the farmer asks for a higher price.)

    previous_offer implements rule BG-4: the same caller must not extract a
    better price by simply calling again.
    """
    if direction not in ("down", "up"):
        raise ValueError("direction must be 'down' or 'up'")
    if max_rounds < 0:
        raise ValueError("max_rounds must be >= 0")

    round_no = max(0, int(round_no))

    if direction == "down":
        raw = base_rate - (step * round_no)
        offer = max(raw, floor_rate)          # BG-1 hard floor
        offer = min(offer, base_rate)
        if previous_offer is not None:
            offer = max(offer, previous_offer)  # BG-4: never cheaper on a re-call
        offer = min(offer, base_rate)
        at_limit = offer <= floor_rate + 1e-9
        reached_floor = at_limit
        hard_limit = floor_rate
    else:
        raw = base_rate + (step * round_no)
        ceiling = ceiling_rate if ceiling_rate is not None else base_rate + step * max_rounds
        offer = min(raw, ceiling)
        offer = max(offer, base_rate)
        if previous_offer is not None:
            offer = min(offer, previous_offer)  # BG-4: never pricier on a re-call
        offer = max(offer, base_rate)
        at_limit = offer >= ceiling - 1e-9
        reached_floor = at_limit
        hard_limit = ceiling

    remaining = max(0, max_rounds - round_no)

    # Decide what the assistant should do next.
    if caller_ask is None:
        action = "offer"
    else:
        satisfied = (
            caller_ask >= offer if direction == "down" else caller_ask <= offer
        )
        if satisfied:
            action = "close"
        elif at_limit or remaining <= 0:
            action = "escalate"
        else:
            action = "offer"

    if action == "close":
        message = f"Caller is within the offer. Close at Rs {offer:.0f}/qtl."
    elif action == "escalate":
        message = (
            "Limit reached and caller is still outside it. Offer a callback or a "
            "human transfer - do not quote a different number."
        )
    elif action == "hold":
        message = f"Hold at Rs {offer:.0f}/qtl."
    else:
        message = f"Offer Rs {offer:.0f}/qtl (round {round_no} of {max_rounds})."

    return OfferResult(
        offer=round(offer, 2),
        round_no=round_no,
        direction=direction,
        action=action,
        at_limit=at_limit,
        remaining_rounds=remaining,
        floor_rate=round(floor_rate, 2),
        base_rate=round(base_rate, 2),
        message=message,
        reached_floor=reached_floor,
    )


def instruction_breaks_floor(
    text: str,
    current_offer: float,
    floor_rate: float,
    direction: str = "down",
    ceiling_rate: float | None = None,
) -> bool:
    """
    Guard for the live-instruction panel (BG-7): does this free-text instruction
    push the price past the hard limit?

    We look for an explicit rupee amount outside the allowed band. Anything
    vaguer is left to the human, who sees the confirm dialog anyway.
    """
    import re

    amounts = [int(m) for m in re.findall(r"(?:rs\.?|\u20b9)?\s*(\d{3,6})", text.lower())]
    if not amounts:
        return False

    if direction == "down":
        return any(a < floor_rate for a in amounts)

    # direction == "up": the hard limit is the ceiling
    limit = ceiling_rate if ceiling_rate is not None else current_offer
    return any(a > limit for a in amounts)
