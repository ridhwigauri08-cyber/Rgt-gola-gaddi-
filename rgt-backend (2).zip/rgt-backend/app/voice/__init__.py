"""Real-time voice pipeline: telephony -> STT -> agent -> TTS -> telephony."""
