terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # For shared/team use, uncomment and create the bucket first:
  # backend "s3" {
  #   bucket = "rgt-terraform-state"
  #   key    = "rgt-api/terraform.tfstate"
  #   region = "ap-south-1"
  # }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "rgt-gola-gaddi"
      Environment = var.environment
      ManagedBy   = "terraform"
    }
  }
}
