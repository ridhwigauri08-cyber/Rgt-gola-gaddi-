"""
Telephony integration.

Twilio Media Streams is implemented fully: the number's voice webhook returns
TwiML that opens a WebSocket, and the handler speaks the Media Streams protocol
(connected / start / media / mark / stop).

Exotel / Ozonetel are stubbed with the shape of the integration and a clear
TODO, because their passthru payloads differ per account.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import Response
from pydantic import BaseModel

from .. import sarvam
from ..config import settings
from ..db import SessionLocal
from ..models import Call
from . import audio
from .agent import respond
from .pipeline import CallSession, decode_twilio_payload, encode_twilio_payload, ensure_call, registry

log = logging.getLogger("rgt.telephony")

router = APIRouter(tags=["telephony"])


def require_api_key(x_api_key: str | None = Header(default=None, alias="X-API-Key")) -> None:
    if not x_api_key or x_api_key != settings.app_api_key:
        raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key header")


# --------------------------------------------------------------------------
# Twilio
# --------------------------------------------------------------------------

def _public_host(request: Request) -> str:
    env_host = (settings.__dict__.get("public_host") or "").strip()
    if env_host:
        return env_host
    host = request.headers.get("x-forwarded-host") or request.headers.get("host") or "localhost:8000"
    proto = request.headers.get("x-forwarded-proto") or request.url.scheme
    scheme = "wss" if proto == "https" else "ws"
    return f"{scheme}://{host}"


@router.post("/telephony/twilio/voice")
async def twilio_voice(request: Request) -> Response:
    """Twilio voice webhook -> TwiML that opens a bidirectional media stream."""
    form = await request.form()
    caller = str(form.get("From", "unknown"))
    call_sid = str(form.get("CallSid", ""))
    log.info("inbound call %s from %s", call_sid, caller)

    stream_url = f"{_public_host(request)}/telephony/twilio/stream"
    twiml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="hi-IN">Namaste, RGT Gola Gaddi.</Say>
  <Connect>
    <Stream url="{stream_url}">
      <Parameter name="caller" value="{caller}" />
    </Stream>
  </Connect>
</Response>"""
    return Response(content=twiml, media_type="application/xml")


@router.websocket("/telephony/twilio/stream")
async def twilio_stream(websocket: WebSocket) -> None:
    await websocket.accept()

    stream_sid: str | None = None
    session: CallSession | None = None

    async def send_audio(frame: bytes) -> None:
        if not stream_sid:
            return
        await websocket.send_text(json.dumps({
            "event": "media",
            "streamSid": stream_sid,
            "media": {"payload": encode_twilio_payload(frame)},
        }))

    async def clear_audio() -> None:
        if not stream_sid:
            return
        await websocket.send_text(json.dumps({"event": "clear", "streamSid": stream_sid}))

    try:
        while True:
            raw = await websocket.receive_text()
            msg = json.loads(raw)
            event = msg.get("event")

            if event == "start":
                stream_sid = (msg.get("start") or {}).get("streamSid") or msg.get("streamSid")
                caller = ((msg.get("start") or {}).get("customParameters") or {}).get("caller", "unknown")
                call_id = ensure_call(caller)
                session = CallSession(call_id, send_audio, clear_audio)
                registry.add(session)
                log.info("stream started for call %s", call_id)

            elif event == "media" and session is not None:
                payload = ((msg.get("media") or {}).get("payload")) or ""
                if payload:
                    await session.on_audio_frame(decode_twilio_payload(payload))

            elif event == "stop":
                break

    except WebSocketDisconnect:
        log.info("stream disconnected")
    except Exception as exc:
        log.warning("stream error: %s", exc)
    finally:
        if session is not None:
            await session.close()
            registry.remove(session.call_id)


# --------------------------------------------------------------------------
# Exotel / Ozonetel
# --------------------------------------------------------------------------

@router.post("/telephony/exotel/passthru")
async def exotel_passthru(request: Request) -> Response:
    """
    Placeholder for Exotel's passthru applet.

    Exotel posts form fields (CallSid, From, To, Direction...) and expects XML
    back, then streams audio over a WebSocket applet. Wire your account's
    Applet/App Bazaar stream URL to a handler shaped like `twilio_stream`.
    """
    form = await request.form()
    log.info("exotel passthru from %s", form.get("From"))
    return Response(
        content="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                "<Response><Say>Namaste, RGT Gola Gaddi.</Say></Response>",
        media_type="application/xml",
    )


# --------------------------------------------------------------------------
# Simulate (no phone needed) - great for demos and tests
# --------------------------------------------------------------------------

class SimulateIn(BaseModel):
    text: str
    call_id: int | None = None
    phone: str = "+919999999999"
    speak: bool = False


@router.post("/voice/simulate", dependencies=[Depends(require_api_key)])
async def simulate(body: SimulateIn) -> dict[str, Any]:
    """
    Run one conversation turn from text, exercising the real agent and tools.

    Use this to demo the assistant without telephony, and to regression-test
    the bargaining/guard behaviour end to end.
    """
    call_id = body.call_id or ensure_call(body.phone)
    with SessionLocal() as db:
        call = db.get(Call, call_id)
        reply = await respond(db, call, body.text, [])

    result: dict[str, Any] = {
        "call_id": call_id,
        "caller_text": body.text,
        "reply": reply.text,
        "tools_used": reply.used_tools,
        "guard_passed": reply.guard_passed,
        "offline": reply.offline,
        "sarvam_configured": sarvam.is_configured(),
    }

    if body.speak and sarvam.is_configured():
        try:
            tts = await sarvam.speak(reply.text)
            result["audio_base64"] = tts.get("audio_base64")
            result["audio_format"] = "wav"
        except Exception as exc:
            result["audio_error"] = str(exc)[:200]

    return result


@router.get("/voice/status")
def voice_status() -> dict[str, Any]:
    return {
        "sarvam_configured": sarvam.is_configured(),
        "active_sessions": registry.count(),
        "telephony": ["twilio"],
        "frame_ms": audio.FRAME_MS,
        "telephony_rate": audio.TELEPHONY_RATE,
    }
