"""
Agent-facing tool endpoints.

These are meant to be called by a hosted voice agent (Sarvam's HTTP Tool), not
by the dashboard. They differ from the dashboard endpoints in one critical way:

    they never return floor_rate or ceiling_rate.

If the LLM sees the floor it can speak it, which breaks PRD rule BG-1. The
dashboard endpoints keep the floor because a supervisor needs it; these do not.

Every response is deliberately flat, because agent builders map response fields
into the prompt by name (e.g. `@offer`).
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from .config import settings
from .db import get_db
from .models import Call
from .voice import tools

router = APIRouter(prefix="/agent", tags=["agent-tools"])

# Keys that must never reach a language model.
_FORBIDDEN = {"floor_rate", "ceiling_rate", "margin"}


def require_api_key(x_api_key: str | None = Header(default=None, alias="X-API-Key")) -> None:
    if not x_api_key or x_api_key != settings.app_api_key:
        raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key header")


protected = [Depends(require_api_key)]


def _safe(value: Any) -> Any:
    """Defence in depth: strip any price band from the payload before returning."""
    if isinstance(value, dict):
        return {k: _safe(v) for k, v in value.items() if k not in _FORBIDDEN}
    if isinstance(value, list):
        return [_safe(v) for v in value]
    return value


def _call(db: Session, call_id: int | None) -> Call | None:
    if call_id is None:
        return None
    return db.get(Call, call_id)


# --------------------------------------------------------------------------
# Schemas
# --------------------------------------------------------------------------

class GetRateIn(BaseModel):
    grain: str = Field(description="Gehu, Chana, Sarson, Soyabean, Makka, Bajra")
    grade: str = "FAQ"


class QuoteIn(BaseModel):
    grain: str
    quantity_qtl: float = Field(gt=0)
    zone: str = "Rampur"
    vehicle_type: str = "pickup"
    loading_by: str = "us"


class BargainIn(BaseModel):
    grain: str
    caller_ask: float | None = None
    call_id: int | None = None
    round_no: int | None = Field(
        default=None,
        description="0 for the first offer, then increment. Pass it back each turn "
                    "when the agent has no call_id, otherwise rounds never advance.",
    )


class BookIn(BaseModel):
    caller_name: str
    grain: str
    quantity_qtl: float = Field(gt=0)
    final_rate: float
    labour: float = 0.0
    freight: float = 0.0
    delivery_date: str | None = None
    call_id: int | None = None


class EscalateIn(BaseModel):
    reason: str = ""
    call_id: int | None = None


class InfoIn(BaseModel):
    topic: str = "general"


# --------------------------------------------------------------------------
# Tools
# --------------------------------------------------------------------------

@router.post("/get_rate", dependencies=protected)
def get_rate(body: GetRateIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    """Today's rate per quintal. Call this before quoting any price."""
    result = tools.execute(db, None, "get_rate", {"grain": body.grain, "grade": body.grade})
    if "error" in result:
        return _safe({
            "available": False,
            "reason": result["error"],
            "say": result.get("say", "Abhi rate update ho raha hai, main callback le leta hoon."),
        })
    return _safe({
        "available": True,
        "grain": result["grain"],
        "grade": result["grade"],
        "rate_per_quintal": result["base_rate"],
        "currency": "INR",
    })


@router.post("/quote", dependencies=protected)
def quote(body: QuoteIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    """Landed price: grain + labour + freight - discount."""
    result = tools.execute(db, None, "calculate_price", {
        "grain": body.grain,
        "quantity_qtl": body.quantity_qtl,
        "zone": body.zone,
        "vehicle_type": body.vehicle_type,
        "loading_by": body.loading_by,
    })
    if "error" in result:
        return _safe({"ok": False, "reason": result["error"],
                      "say": result.get("say", "Detail theek se samajh nahi aayi.")})
    return _safe({
        "ok": True,
        "grain": result["grain"],
        "quantity_qtl": result["quantity_qtl"],
        "grain_rate": result["grain_rate"],
        "labour": result["labour"],
        "freight": result["freight"],
        "discount": result["discount"],
        "landed_per_quintal": result["landed_per_qtl"],
        "landed_total": result["landed_total"],
        "currency": "INR",
    })


@router.post("/bargain", dependencies=protected)
def bargain(body: BargainIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    """
    Next allowed offer. `action` tells the agent what to do:
    offer -> say the offer, close -> confirm the deal, escalate -> callback/human.
    """
    call = _call(db, body.call_id)
    result = tools.execute(db, call, "next_bargain_offer",
                           {"grain": body.grain, "caller_ask": body.caller_ask,
                            "round_no": body.round_no})
    if "error" in result:
        return _safe({"ok": False, "reason": result["error"],
                      "say": "Abhi rate update ho raha hai."})
    return _safe({
        "ok": True,
        "offer_per_quintal": result["offer"],
        "action": result["action"],
        "round_no": result["round_no"],
        "next_round_no": result["round_no"] + 1,
        "remaining_rounds": result["remaining_rounds"],
        "at_limit": result["at_limit"],
        "currency": "INR",
        "instruction": {
            "offer": "Say this offer out loud, then ask if it works.",
            "close": "Caller is within the offer - read back the rate and confirm the deal.",
            "escalate": "Do not quote another number. Offer a callback or transfer to a human.",
        }.get(result["action"], ""),
    })


@router.post("/book", dependencies=protected)
def book(body: BookIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    """Confirm a deal. Only call after the caller clearly says yes."""
    call = _call(db, body.call_id)
    result = tools.execute(db, call, "create_booking", {
        "caller_name": body.caller_name,
        "grain": body.grain,
        "quantity_qtl": body.quantity_qtl,
        "final_rate": body.final_rate,
        "labour": body.labour,
        "freight": body.freight,
        "delivery_date": body.delivery_date,
    })
    if "error" in result:
        # Opaque reason on purpose: telling the model "below_floor" invites it to
        # explain the floor to the caller. The real reason is logged server side.
        return _safe({"ok": False, "reason": "not_allowed",
                      "say": result.get("say", "Is rate par booking nahi ho sakti, main malik se poochta hoon.")})
    return _safe({
        "ok": True,
        "booking_id": result["booking_id"],
        "final_rate": result["final_rate"],
        "total": result["total"],
        "status": result["status"],
        "currency": "INR",
        "say": "Booking confirm ho gayi.",
    })


@router.post("/escalate", dependencies=protected)
def escalate(body: EscalateIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    """Transfer to a human. Use for complaints, legal, payment disputes, abuse."""
    call = _call(db, body.call_id)
    tools.execute(db, call, "escalate_to_human", {"reason": body.reason})
    return _safe({"ok": True, "status": "transferred",
                  "say": "Main aapka call supervisor se jod raha hoon."})


@router.post("/info", dependencies=protected)
def info(body: InfoIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    """Godown address, timings, payment terms."""
    result = tools.execute(db, None, "get_mandi_info", {"topic": body.topic})
    return _safe({"ok": True, "topic": result.get("topic"), "info": result.get("info")})


@router.get("/manifest")
def manifest() -> dict[str, Any]:
    """
    Machine-readable description of the tool endpoints, for whoever sets up the
    agent. Public (no key) so it can be read while configuring.
    """
    return {
        "base_path": "/agent",
        "auth_header": "X-API-Key",
        "currency": "INR",
        "note": "These endpoints never return floor or ceiling rates.",
        "tools": [
            {
                "name": "get_rate",
                "method": "POST",
                "path": "/agent/get_rate",
                "body": {"grain": "string", "grade": "string (optional, default FAQ)"},
                "returns": ["available", "grain", "grade", "rate_per_quintal"],
            },
            {
                "name": "quote",
                "method": "POST",
                "path": "/agent/quote",
                "body": {"grain": "string", "quantity_qtl": "number", "zone": "string",
                         "vehicle_type": "string", "loading_by": "us|caller"},
                "returns": ["landed_per_quintal", "landed_total", "labour", "freight"],
            },
            {
                "name": "bargain",
                "method": "POST",
                "path": "/agent/bargain",
                "body": {"grain": "string", "caller_ask": "number (optional)", "call_id": "int (optional)"},
                "returns": ["offer_per_quintal", "action", "remaining_rounds", "instruction"],
            },
            {
                "name": "book",
                "method": "POST",
                "path": "/agent/book",
                "body": {"caller_name": "string", "grain": "string", "quantity_qtl": "number",
                         "final_rate": "number", "labour": "number", "freight": "number",
                         "delivery_date": "string", "call_id": "int"},
                "returns": ["booking_id", "total", "status"],
            },
            {
                "name": "escalate",
                "method": "POST",
                "path": "/agent/escalate",
                "body": {"reason": "string", "call_id": "int (optional)"},
                "returns": ["status"],
            },
            {
                "name": "info",
                "method": "POST",
                "path": "/agent/info",
                "body": {"topic": "address|timing|payment|general"},
                "returns": ["info"],
            },
        ],
    }
