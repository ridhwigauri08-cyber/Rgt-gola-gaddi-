"""Tests for the agent-facing tool endpoints (used by Sarvam's HTTP Tool)."""
import json
import os
import pathlib

DB_PATH = pathlib.Path(__file__).parent / "test_rgt.db"
os.environ.setdefault("DATABASE_URL", f"sqlite:///{DB_PATH}")
os.environ.setdefault("APP_API_KEY", "test-key")
os.environ.setdefault("SARVAM_API_KEY", "")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

HEADERS = {"X-API-Key": "test-key"}
FORBIDDEN = ("floor_rate", "ceiling_rate", "margin", "floor", "ceiling")


def client() -> TestClient:
    return TestClient(app)


def _no_leak(payload) -> None:
    """Nothing in the response may hint at the hidden price band."""
    blob = json.dumps(payload).lower()
    for bad in FORBIDDEN:
        assert bad not in blob, f"leaked '{bad}' in {blob}"


def test_manifest_is_public():
    with client() as c:
        r = c.get("/agent/manifest")
        assert r.status_code == 200
        body = r.json()
        names = {t["name"] for t in body["tools"]}
        assert names == {"get_rate", "quote", "bargain", "book", "escalate", "info"}
        assert body["auth_header"] == "X-API-Key"


def test_agent_endpoints_require_key():
    with client() as c:
        assert c.post("/agent/get_rate", json={"grain": "Gehu"}).status_code == 401
        assert c.post("/agent/get_rate", json={"grain": "Gehu"},
                      headers={"X-API-Key": "nope"}).status_code == 401


def test_get_rate_hides_band():
    with client() as c:
        r = c.post("/agent/get_rate", headers=HEADERS, json={"grain": "Gehu", "grade": "FAQ"})
        assert r.status_code == 200
        body = r.json()
        assert body["available"] is True
        assert body["rate_per_quintal"] == 2500
        _no_leak(body)


def test_get_rate_unknown_grain_is_soft():
    with client() as c:
        r = c.post("/agent/get_rate", headers=HEADERS, json={"grain": "Rajma"})
        assert r.status_code == 200
        body = r.json()
        assert body["available"] is False
        assert "say" in body
        _no_leak(body)


def test_quote_is_flat_and_correct():
    with client() as c:
        r = c.post("/agent/quote", headers=HEADERS, json={
            "grain": "Gehu", "quantity_qtl": 40, "zone": "Rampur", "vehicle_type": "pickup"})
        body = r.json()
        assert body["ok"] is True
        assert body["landed_total"] == 40 * 2500 + 1400 + 1800
        assert body["landed_per_quintal"] == 2580
        _no_leak(body)


def test_bargain_returns_offer_and_action_only():
    with client() as c:
        r = c.post("/agent/bargain", headers=HEADERS,
                   json={"grain": "Gehu", "caller_ask": 2600})
        body = r.json()
        assert body["ok"] is True
        assert 2470 <= body["offer_per_quintal"] <= 2540
        assert body["action"] in ("offer", "close", "escalate")
        assert body["instruction"]
        _no_leak(body)


def test_bargain_escalates_at_limit():
    with client() as c:
        body = {}
        # Without a call_id the caller must pass round_no back each turn.
        for rnd in range(8):
            body = c.post("/agent/bargain", headers=HEADERS,
                          json={"grain": "Gehu", "caller_ask": 9999, "round_no": rnd}).json()
            assert 2470 <= body["offer_per_quintal"] <= 2540
        assert body["action"] == "escalate"
        assert body["at_limit"] is True
        assert body["next_round_no"] == body["round_no"] + 1
        _no_leak(body)


def test_book_success():
    with client() as c:
        body = c.post("/agent/book", headers=HEADERS, json={
            "caller_name": "Test Kisan", "grain": "Gehu", "quantity_qtl": 10,
            "final_rate": 2500, "labour": 350, "freight": 450,
        }).json()
        assert body["ok"] is True
        assert body["total"] == 10 * 2500 + 350 + 450
        _no_leak(body)


def test_book_below_floor_rejected_without_leaking():
    with client() as c:
        body = c.post("/agent/book", headers=HEADERS, json={
            "caller_name": "Test Kisan", "grain": "Gehu", "quantity_qtl": 10,
            "final_rate": 1000,
        }).json()
        assert body["ok"] is False
        assert "say" in body
        _no_leak(body)


def test_escalate_and_info():
    with client() as c:
        e = c.post("/agent/escalate", headers=HEADERS, json={"reason": "complaint"}).json()
        assert e["status"] == "transferred"
        i = c.post("/agent/info", headers=HEADERS, json={"topic": "address"}).json()
        assert i["ok"] is True
        assert "Kota" in i["info"]
        _no_leak(e)
        _no_leak(i)


def test_manifest_matches_live_paths():
    """Every path advertised in the manifest must actually exist."""
    with client() as c:
        manifest = c.get("/agent/manifest").json()
        for tool in manifest["tools"]:
            path = tool["path"]
            r = c.post(path, headers=HEADERS, json={"grain": "Gehu", "quantity_qtl": 1,
                                                    "caller_name": "x", "final_rate": 2500,
                                                    "reason": "x", "topic": "general"})
            assert r.status_code == 200, f"{path} -> {r.status_code}"
