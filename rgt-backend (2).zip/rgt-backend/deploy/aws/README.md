# Deploying the RGT Control API on AWS

What gets created:

```
                 ┌──────────────────────────────────────────┐
   Sarvam agent  │  App Runner (HTTPS, always-on, autoscale) │
   Android app ──┼──►  FastAPI container  (port 8000)       │
                 └───────────────┬──────────────────────────┘
                                 │ VPC connector
                                 ▼
                    RDS PostgreSQL 16 (private, encrypted)

   Secrets Manager: DATABASE_URL, APP_API_KEY, SARVAM_API_KEY
   ECR: container image
   CloudWatch: logs
```

Region defaults to **ap-south-1 (Mumbai)** — closest to the callers and keeps
data in India.

---

## Prerequisites

- AWS CLI v2 configured (`aws sts get-caller-identity` should work)
- Terraform >= 1.5
- Docker
- IAM permissions to create: ECR, RDS, App Runner, IAM roles, Secrets Manager,
  security groups

---

## Deploy (three steps)

The App Runner service needs an image to exist before it can start, so the first
apply deliberately skips it (`deploy_service = false`).

```bash
cd deploy/aws/terraform
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars -> set sarvam_api_key

terraform init
terraform apply          # ECR + RDS + secrets + IAM  (~8 min, RDS is slow)

cd ..
./deploy.sh              # docker build + push to ECR

cd terraform
terraform apply -var deploy_service=true   # creates App Runner
terraform output service_url              # your API base URL
```

You now have something like:

```
https://abc123xyz.ap-south-1.awsapprunner.com
```

Check it:

```bash
curl -s "$(terraform output -raw service_url)/health"
```

---

## Get the app API key

```bash
terraform output -raw app_api_key
```

Use that value in two places:

1. **Android app** → Settings → Backend → Base URL = the service URL, X-API-Key = this key.
2. **Sarvam HTTP Tool** → Auth tab → API Key → `X-API-Key` = this key.

The Sarvam subscription key stays in Secrets Manager; nothing in the app or the
agent config should ever contain it.

---

## Rotating the Sarvam key

```bash
aws secretsmanager put-secret-value \
  --secret-id rgt-api/sarvam-api-key \
  --secret-string "NEW_KEY" \
  --region ap-south-1
```

Then restart the service:

```bash
aws apprunner start-deployment --service-arn "$(terraform output -raw service_arn)" --region ap-south-1
```

---

## Cost (ap-south-1, approximate)

| Item | Config | ~Monthly |
|---|---|---|
| App Runner | 0.25 vCPU / 1 GB, min 1 instance | ~$17 (₹1,450) |
| RDS PostgreSQL | db.t4g.micro, 20 GB gp3, 7-day backup | ~$14 (₹1,200) |
| ECR + Secrets + logs | tiny | ~$1 |
| **Total** | | **~$32 (₹2,700)** |

`min_instances = 1` costs a little more than scaling to zero, but a cold start
in the middle of a phone call is unacceptable — keep it at 1.

To go bigger later: `app_cpu = "1024"`, `app_memory = "2048"`,
`db_instance_class = "db.t4g.small"`.

---

## Updating the app

```bash
./deploy.sh    # build + push + start-deployment
```

App Runner keeps the old version running until the new one is healthy, so
updates are effectively zero-downtime.

---

## Teardown

```bash
cd deploy/aws/terraform
terraform destroy -var deploy_service=true
```

RDS has `skip_final_snapshot = true`, so destroying it deletes the data. Set it
to `false` and add a `final_snapshot_identifier` before you rely on this in
production.

---

## Notes and caveats

- **This Terraform has not been `terraform validate`-d.** The environment it was
  written in could not reach `releases.hashicorp.com` or
  `registry.terraform.io`. It was checked statically (all `var.*` and `local.*`
  references resolve, 22 resources, braces balanced) but **run
  `terraform plan` and read it before applying.**
- The stack uses the account's **default VPC** to keep the footprint small.
  RDS is `publicly_accessible = false` and only accepts 5432 from the App
  Runner connector's security group. For stricter isolation, replace the
  `data "aws_vpc"` blocks with a dedicated VPC and private subnets.
- App Runner **does** support WebSockets, so `/calls/live/ws` works if you ever
  use the built-in pipeline instead of Sarvam's agent.
- The container runs as a non-root user and listens on `$PORT`.
- `PUBLIC_HOST` is only needed for the Twilio path; leave it empty when using
  Sarvam's hosted agent.
