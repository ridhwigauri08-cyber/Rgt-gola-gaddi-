# ---------------------------------------------------------------------------
# RGT Gola Gaddi - Control API on AWS
#
#   ECR  ->  App Runner (always-on, HTTPS, autoscaling)
#              |
#              +-- VPC connector --> RDS PostgreSQL (private, encrypted)
#              +-- Secrets Manager (DATABASE_URL, APP_API_KEY, SARVAM_API_KEY)
#
# This uses the account's DEFAULT VPC to keep the footprint small. If you need
# full network isolation, swap the `data "aws_vpc"` blocks for a dedicated VPC
# with private subnets.
# ---------------------------------------------------------------------------

data "aws_caller_identity" "current" {}

data "aws_vpc" "default" {
  default = true
}

data "aws_subnets" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }
}

locals {
  account_id = data.aws_caller_identity.current.account_id
  subnet_ids = data.aws_subnets.default.ids
}

# ---------------------------------------------------------------------------
# Container registry
# ---------------------------------------------------------------------------

resource "aws_ecr_repository" "api" {
  name                 = var.app_name
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }
}

resource "aws_ecr_lifecycle_policy" "api" {
  repository = aws_ecr_repository.api.name

  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Keep the last 10 images"
      selection = {
        tagStatus   = "any"
        countType   = "imageCountMoreThan"
        countNumber = 10
      }
      action = { type = "expire" }
    }]
  })
}

# ---------------------------------------------------------------------------
# Secrets
# ---------------------------------------------------------------------------

resource "random_password" "db" {
  length  = 28
  special = false # keeps the password URL-safe inside DATABASE_URL
}

resource "random_password" "app_api_key" {
  length  = 40
  special = false
}

resource "aws_secretsmanager_secret" "db_url" {
  name        = "${var.app_name}/database-url"
  description = "SQLAlchemy DATABASE_URL for the RGT control API"
}

resource "aws_secretsmanager_secret" "app_key" {
  name        = "${var.app_name}/app-api-key"
  description = "X-API-Key the Android app and Sarvam agent must send"
}

resource "aws_secretsmanager_secret" "sarvam_key" {
  name        = "${var.app_name}/sarvam-api-key"
  description = "Sarvam AI subscription key (server side only)"
}

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

resource "aws_security_group" "rds" {
  name        = "${var.app_name}-rds"
  description = "Postgres access from App Runner"
  vpc_id      = data.aws_vpc.default.id
}

resource "aws_security_group" "apprunner" {
  name        = "${var.app_name}-apprunner"
  description = "App Runner VPC connector"
  vpc_id      = data.aws_vpc.default.id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group_rule" "rds_from_apprunner" {
  type                     = "ingress"
  from_port                = 5432
  to_port                  = 5432
  protocol                 = "tcp"
  security_group_id        = aws_security_group.rds.id
  source_security_group_id = aws_security_group.apprunner.id
  description              = "App Runner VPC connector to Postgres"
}

resource "aws_db_subnet_group" "main" {
  name       = "${var.app_name}-subnets"
  subnet_ids = local.subnet_ids
}

resource "aws_db_instance" "postgres" {
  identifier     = "${var.app_name}-db"
  engine         = "postgres"
  engine_version = "16"

  instance_class        = var.db_instance_class
  allocated_storage     = 20
  max_allocated_storage = 100
  storage_type          = "gp3"
  storage_encrypted     = true

  db_name  = var.db_name
  username = var.db_username
  password = random_password.db.result

  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.rds.id]
  publicly_accessible    = false

  backup_retention_period   = 7
  auto_minor_version_upgrade = true
  apply_immediately         = false

  # Set to false and add a final_snapshot_identifier before going live.
  skip_final_snapshot = true
  deletion_protection = false
}

locals {
  database_url = format(
    "postgresql+psycopg://%s:%s@%s:%s/%s?sslmode=require",
    var.db_username,
    random_password.db.result,
    aws_db_instance.postgres.address,
    aws_db_instance.postgres.port,
    var.db_name,
  )
}

resource "aws_secretsmanager_secret_version" "db_url" {
  secret_id     = aws_secretsmanager_secret.db_url.id
  secret_string = local.database_url
}

resource "aws_secretsmanager_secret_version" "app_key" {
  secret_id     = aws_secretsmanager_secret.app_key.id
  secret_string = random_password.app_api_key.result
}

resource "aws_secretsmanager_secret_version" "sarvam_key" {
  secret_id     = aws_secretsmanager_secret.sarvam_key.id
  secret_string = var.sarvam_api_key
}

# ---------------------------------------------------------------------------
# IAM
# ---------------------------------------------------------------------------

data "aws_iam_policy_document" "ecr_trust" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["build.apprunner.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "apprunner_ecr" {
  name               = "${var.app_name}-apprunner-ecr"
  assume_role_policy = data.aws_iam_policy_document.ecr_trust.json
}

resource "aws_iam_role_policy_attachment" "apprunner_ecr" {
  role       = aws_iam_role.apprunner_ecr.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSAppRunnerServicePolicyForECRAccess"
}

data "aws_iam_policy_document" "instance_trust" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["tasks.apprunner.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "apprunner_instance" {
  name               = "${var.app_name}-apprunner-instance"
  assume_role_policy = data.aws_iam_policy_document.instance_trust.json
}

data "aws_iam_policy_document" "read_secrets" {
  statement {
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [
      aws_secretsmanager_secret.db_url.arn,
      aws_secretsmanager_secret.app_key.arn,
      aws_secretsmanager_secret.sarvam_key.arn,
    ]
  }
}

resource "aws_iam_role_policy" "read_secrets" {
  name   = "${var.app_name}-read-secrets"
  role   = aws_iam_role.apprunner_instance.id
  policy = data.aws_iam_policy_document.read_secrets.json
}

# ---------------------------------------------------------------------------
# App Runner
# ---------------------------------------------------------------------------

resource "aws_apprunner_vpc_connector" "api" {
  connector_name = "${var.app_name}-vpc"
  subnets        = local.subnet_ids
  security_groups = [aws_security_group.apprunner.id]
}

resource "aws_apprunner_auto_scaling_configuration_version" "api" {
  auto_scaling_configuration_name = "${var.app_name}-scaling"

  max_concurrency = 50
  min_size        = var.min_instances
  max_size        = var.max_instances
}

resource "aws_apprunner_service" "api" {
  count = var.deploy_service ? 1 : 0

  service_name = var.app_name

  source_configuration {
    auto_deployments_enabled = false

    authentication_configuration {
      access_role_arn = aws_iam_role.apprunner_ecr.arn
    }

    image_repository {
      image_identifier      = "${aws_ecr_repository.api.repository_url}:latest"
      image_repository_type = "ECR"

      image_configuration {
        port = "8000"

        runtime_environment_variables = {
          RATE_STALE_AFTER_HOURS = "14"
          PUBLIC_HOST            = ""
        }

        # Secrets are resolved by App Runner at start; the values never appear
        # in the image or in the task definition.
        runtime_environment_secrets = {
          DATABASE_URL   = aws_secretsmanager_secret.db_url.arn
          APP_API_KEY    = aws_secretsmanager_secret.app_key.arn
          SARVAM_API_KEY = aws_secretsmanager_secret.sarvam_key.arn
        }
      }
    }
  }

  instance_configuration {
    cpu               = var.app_cpu
    memory            = var.app_memory
    instance_role_arn = aws_iam_role.apprunner_instance.arn
  }

  health_check_configuration {
    protocol            = "HTTP"
    path                = "/health"
    interval            = 10
    timeout             = 5
    healthy_threshold   = 1
    unhealthy_threshold = 5
  }

  auto_scaling_configuration_arn = aws_apprunner_auto_scaling_configuration_version.api.arn

  network_configuration {
    egress_configuration {
      egress_type       = "VPC"
      vpc_connector_arn = aws_apprunner_vpc_connector.api.arn
    }
  }
}
