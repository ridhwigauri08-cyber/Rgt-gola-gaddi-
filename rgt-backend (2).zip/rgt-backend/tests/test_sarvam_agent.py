"""
Tests for the Sarvam Voice Agents integration.

The real Sarvam API is never called: httpx is patched with a MockTransport so we
can assert on the exact URL, headers and query params we send, and on how we map
the response into the app's shape.
"""
import json
import os
import pathlib

import httpx
import pytest

DB_PATH = pathlib.Path(__file__).parent / "test_rgt.db"
os.environ.setdefault("DATABASE_URL", f"sqlite:///{DB_PATH}")
os.environ.setdefault("APP_API_KEY", "test-key")
os.environ.setdefault("SARVAM_API_KEY", "")

from fastapi.testclient import TestClient  # noqa: E402

from app import sarvam_agents  # noqa: E402
from app.config import settings  # noqa: E402
from app.main import app  # noqa: E402

HEADERS = {"X-API-Key": "test-key"}

ORG = "01a16eb7-a899-74a8-b5c7-6b5aee19abb4"
WS = "01a16eb7-a8ae-7ddb-9246-e461ee4db2f5"
APP_ID = "Conversatio-3f2401da-4b9e"
DEPLOYMENT = "RGT-Gola-Ga-3916e00f-1d1c"

INTERACTION = {
    "interaction_id": "20261007/9f1c2a7e-4b3d-4e8a-a1f0-6c2d9b7e5a14",
    "user_contact": "+919812345678",
    "user_identifier": "user-1001",
    "duration_in_seconds": 42.5,
    "start_datetime": "2026-10-07T10:30:32Z",
    "ended_by": "user",
    "channel_direction": "inbound",
}


@pytest.fixture
def configured(monkeypatch):
    monkeypatch.setattr(settings, "sarvam_workspace_api_key", "sk_test_key")
    monkeypatch.setattr(settings, "sarvam_org_id", ORG)
    monkeypatch.setattr(settings, "sarvam_workspace_id", WS)
    monkeypatch.setattr(settings, "sarvam_app_id", APP_ID)
    monkeypatch.setattr(settings, "sarvam_deployment_id", DEPLOYMENT)
    monkeypatch.setattr(settings, "sarvam_connection_id", "")
    monkeypatch.setattr(settings, "sarvam_agent_phone_number", "")
    monkeypatch.setattr(settings, "webhook_token", "")
    monkeypatch.setattr(settings, "sarvam_cost_per_minute", 3.0)
    yield


@pytest.fixture
def mock_http(monkeypatch):
    """Install a MockTransport and hand back a list of seen requests."""
    seen: list[httpx.Request] = []
    state = {"handler": lambda req: httpx.Response(404, json={"detail": "no handler"})}

    transport = httpx.MockTransport(lambda req: (seen.append(req), state["handler"](req))[1])

    class PatchedClient(httpx.AsyncClient):
        def __init__(self, *args, **kwargs):
            kwargs["transport"] = transport
            super().__init__(*args, **kwargs)

    monkeypatch.setattr(sarvam_agents.httpx, "AsyncClient", PatchedClient)

    def set_handler(fn):
        state["handler"] = fn

    return seen, set_handler


def client() -> TestClient:
    return TestClient(app)


# ------------------------------------------------------------------ status

def test_status_when_not_configured(monkeypatch):
    monkeypatch.setattr(settings, "sarvam_workspace_api_key", "")
    monkeypatch.setattr(settings, "sarvam_org_id", "")
    monkeypatch.setattr(settings, "sarvam_workspace_id", "")
    monkeypatch.setattr(settings, "sarvam_app_id", "")
    with client() as c:
        body = c.get("/sarvam/status", headers=HEADERS).json()
    assert body["configured"] is False
    assert "X_API_KEY" in body["hint"]


def test_status_reports_deployment(configured, mock_http):
    seen, set_handler = mock_http
    set_handler(lambda req: httpx.Response(200, json={
        "items": [{
            "deployment_id": DEPLOYMENT, "app_id": APP_ID, "app_version": 3,
            "phone_numbers": ["+918047168000"], "channel_direction": "inbound_outbound",
            "status": "active", "name": "RGT Gola Gaddi line",
            "created_by": "x", "created_at": "2026-03-01T10:00:00Z",
            "updated_at": "2026-03-15T14:30:00Z",
        }],
        "total": 1, "limit": 100, "offset": 0,
    }))
    with client() as c:
        body = c.get("/sarvam/status", headers=HEADERS).json()
    assert body["configured"] is True
    assert body["deployment"]["found"] is True
    assert body["deployment"]["app_version"] == 3
    assert body["outbound_ready"] is False  # no connection id yet
    # correct host, path and auth header
    assert seen[0].url.host == "apps.sarvam.ai"
    assert f"/v1/orgs/{ORG}/workspaces/{WS}/deployments" in str(seen[0].url)
    assert seen[0].headers["X-API-Key"] == "sk_test_key"


# ------------------------------------------------------------------ calls

def test_list_calls_maps_interactions(configured, mock_http):
    seen, set_handler = mock_http
    set_handler(lambda req: httpx.Response(200, json={
        "items": [INTERACTION], "total": 1, "limit": 50, "offset": 0,
        "next_page_uri": "", "prev_page_uri": "",
    }))
    with client() as c:
        body = c.get("/sarvam/calls?hours=24&limit=10", headers=HEADERS).json()

    assert body["total"] == 1
    call = body["calls"][0]
    assert call["caller_number"] == "+919812345678"
    assert call["duration_sec"] == 42
    assert call["cost_inr"] == 2.13          # 42.5s at Rs 3/min
    assert call["interaction_id"] == INTERACTION["interaction_id"]

    url = str(seen[0].url)
    assert f"/v1/{ORG}/{WS}/{APP_ID}/interactions" in url
    assert "start_datetime=" in url and "end_datetime=" in url
    assert "include_transcript=false" in url


def test_get_transcript_maps_roles(configured, mock_http):
    seen, set_handler = mock_http
    set_handler(lambda req: httpx.Response(200, json={
        "interaction_id": INTERACTION["interaction_id"],
        "messages": [
            {"turn_id": 1, "role": "assistant", "content": "नमस्ते, RGT Gola Gaddi.", "language_name": "Hindi"},
            {"turn_id": 2, "role": "user", "content": "गेहूँ का भाव क्या है?", "language_name": "Hindi"},
        ],
    }))
    with client() as c:
        body = c.get(f"/sarvam/call/{INTERACTION['interaction_id']}", headers=HEADERS).json()

    assert body["turn_count"] == 2
    assert body["transcript"][0]["speaker"] == "AI"
    assert body["transcript"][1]["speaker"] == "Caller"
    assert body["transcript"][1]["text"] == "गेहूँ का भाव क्या है?"
    # the slash in the interaction id must be encoded in the path
    assert "%2F" in str(seen[0].url)


# ------------------------------------------------------------------ outbound

def test_dial_without_connection_id_fails(configured, mock_http):
    with client() as c:
        r = c.post("/sarvam/dial", headers=HEADERS, json={"phone": "+919812345678"})
    assert r.status_code == 503
    assert "SARVAM_CONNECTION_ID" in r.json()["detail"]


def test_dial_rejects_non_e164(configured, mock_http):
    with client() as c:
        r = c.post("/sarvam/dial", headers=HEADERS, json={"phone": "9812345678"})
    assert r.status_code == 422


def test_dial_success(configured, mock_http, monkeypatch):
    monkeypatch.setattr(settings, "sarvam_connection_id", "conn-123")
    monkeypatch.setattr(settings, "sarvam_agent_phone_number", "+918047168000")
    seen, set_handler = mock_http

    def handler(req):
        if req.method == "GET":  # deployment lookup for app_version
            return httpx.Response(200, json={"items": [{"deployment_id": DEPLOYMENT, "app_version": 3}],
                                             "total": 1, "limit": 100, "offset": 0})
        return httpx.Response(200, json={"attempt_id": "att-abc"})

    set_handler(handler)
    with client() as c:
        body = c.post("/sarvam/dial", headers=HEADERS,
                      json={"phone": "+919812345678", "language": "Hindi"}).json()

    assert body["ok"] is True and body["attempt_id"] == "att-abc"

    post = [r for r in seen if r.method == "POST"][0]
    sent = json.loads(post.content)
    assert sent["user_config"]["user_phone_number"] == "+919812345678"
    assert sent["app_config"]["app_id"] == APP_ID
    assert sent["app_config"]["app_version"] == 3
    assert sent["app_config"]["connection_config"]["connection_id"] == "conn-123"
    assert sent["app_config"]["app_overrides"]["initial_language_name"] == "Hindi"
    assert "/v1/orgs/" in str(post.url) and str(post.url).endswith("/outbounds")


# ------------------------------------------------------------------ webhook

def test_webhook_requires_token(configured, mock_http, monkeypatch):
    with client() as c:
        assert c.post("/sarvam/webhook", json={}).status_code == 503   # token not configured
    monkeypatch.setattr(settings, "webhook_token", "s3cret")
    with client() as c:
        assert c.post("/sarvam/webhook", json={}).status_code == 401   # wrong/missing token
        assert c.post("/sarvam/webhook?token=wrong", json={}).status_code == 401


def test_webhook_stores_event_and_computes_cost(configured, mock_http, monkeypatch):
    monkeypatch.setattr(settings, "webhook_token", "s3cret")
    payload = {
        "app_id": APP_ID, "app_version": 3, "attempt_id": "att-1",
        "campaign_id": "c1", "cohort_id": "co1",
        "completion_status": "completed", "connectivity_status": "connected",
        "user_identifier": "user-1001", "user_phone_number": "+919812345678",
        "agent_phone_number": "+918047168000", "duration": 60.0,
        "interaction_id": INTERACTION["interaction_id"], "retry_attempt": 0,
        "start_datetime": "2026-10-07T05:00:32Z", "end_datetime": "2026-10-07T05:01:32Z",
        "interaction_transcript": [{"role": "agent", "en_text": "Namaste"}, {"role": "user", "en_text": "Bhaav?"}],
    }
    with client() as c:
        r = c.post("/sarvam/webhook", headers={"X-Webhook-Token": "s3cret"}, json=payload)
        assert r.status_code == 200
        events = c.get("/sarvam/events", headers=HEADERS).json()

    assert events[0]["interaction_id"] == INTERACTION["interaction_id"]
    assert events[0]["completion_status"] == "completed"
    assert events[0]["cost_inr"] == 3.0        # 60s at Rs 3/min
    assert events[0]["transcript"][0]["en_text"] == "Namaste"


def test_sarvam_endpoints_require_api_key(configured, mock_http):
    with client() as c:
        assert c.get("/sarvam/calls").status_code == 401
        assert c.get("/sarvam/events").status_code == 401
        assert c.post("/sarvam/dial", json={"phone": "+919812345678"}).status_code == 401


def test_env_var_alias_x_api_key(monkeypatch):
    """The workspace key can be supplied as X_API_KEY (preferred) or the long name."""
    from app.config import Settings

    monkeypatch.setenv("X_API_KEY", "sk_from_alias")
    monkeypatch.delenv("SARVAM_WORKSPACE_API_KEY", raising=False)
    monkeypatch.delenv("SARVAM_X_API_KEY", raising=False)
    assert Settings().sarvam_workspace_api_key == "sk_from_alias"

    monkeypatch.delenv("X_API_KEY")
    monkeypatch.setenv("SARVAM_WORKSPACE_API_KEY", "sk_from_long_name")
    assert Settings().sarvam_workspace_api_key == "sk_from_long_name"


def test_header_is_always_x_api_key(configured, mock_http):
    """Whatever the env var is called, the outgoing header must be X-API-Key."""
    seen, set_handler = mock_http
    set_handler(lambda req: httpx.Response(200, json={"items": [], "total": 0,
                                                      "limit": 20, "offset": 0}))
    with client() as c:
        c.get("/sarvam/calls", headers=HEADERS)
    assert seen[0].headers["X-API-Key"] == "sk_test_key"
    assert "api-subscription-key" not in seen[0].headers
