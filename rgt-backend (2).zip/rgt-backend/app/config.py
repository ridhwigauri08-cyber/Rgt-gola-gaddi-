"""Environment-driven configuration. No secrets are ever sent to the client."""
import os


class Settings:
    def __init__(self) -> None:
        self.database_url: str = os.getenv("DATABASE_URL", "sqlite:///./rgt.db")
        self.app_api_key: str = os.getenv("APP_API_KEY", "dev-key-change-me")

        # Sarvam AI - server side only.
        self.sarvam_api_key: str = os.getenv("SARVAM_API_KEY", "")
        self.sarvam_base_url: str = os.getenv("SARVAM_BASE_URL", "https://api.sarvam.ai")
        self.sarvam_stt_model: str = os.getenv("SARVAM_STT_MODEL", "saaras:v4")
        self.sarvam_tts_model: str = os.getenv("SARVAM_TTS_MODEL", "bulbul:v4-flash")
        self.sarvam_tts_speaker: str = os.getenv("SARVAM_TTS_SPEAKER", "anushka")
        self.sarvam_chat_model: str = os.getenv("SARVAM_CHAT_MODEL", "sarvam-m")

        self.rate_stale_after_hours: int = int(os.getenv("RATE_STALE_AFTER_HOURS", "14"))

        # Public base URL of this service, e.g. https://api.yourdomain.com.
        # Used to build the Twilio media-stream WebSocket URL.
        self.public_host: str = os.getenv("PUBLIC_HOST", "")

        # ---- Sarvam Voice Agents (Samvaad) ----
        # The header sent to apps.sarvam.ai is ALWAYS "X-API-Key"; only the env
        # var name is flexible. X_API_KEY is the preferred name; the longer
        # aliases are kept so older deployments keep working.
        # This is a different key from SARVAM_API_KEY (api-subscription-key).
        self.sarvam_workspace_api_key: str = (
            os.getenv("X_API_KEY")
            or os.getenv("SARVAM_WORKSPACE_API_KEY")
            or os.getenv("SARVAM_X_API_KEY")
            or ""
        )
        self.sarvam_org_id: str = os.getenv("SARVAM_ORG_ID", "")
        self.sarvam_workspace_id: str = os.getenv("SARVAM_WORKSPACE_ID", "")
        self.sarvam_app_id: str = os.getenv("SARVAM_APP_ID", "")
        self.sarvam_deployment_id: str = os.getenv("SARVAM_DEPLOYMENT_ID", "")
        # Telephony connection, needed only for outbound calls.
        self.sarvam_connection_id: str = os.getenv("SARVAM_CONNECTION_ID", "")
        self.sarvam_agent_phone_number: str = os.getenv("SARVAM_AGENT_PHONE_NUMBER", "")
        # Used to estimate cost per call from duration.
        self.sarvam_cost_per_minute: float = float(os.getenv("SARVAM_COST_PER_MINUTE", "3.0"))

        # Shared secret for the Sarvam webhook receiver.
        self.webhook_token: str = os.getenv("WEBHOOK_TOKEN", "")

    @property
    def agents_configured(self) -> bool:
        return bool(
            self.sarvam_workspace_api_key.strip()
            and self.sarvam_org_id.strip()
            and self.sarvam_workspace_id.strip()
            and self.sarvam_app_id.strip()
        )

    @property
    def sarvam_configured(self) -> bool:
        return bool(self.sarvam_api_key.strip())


settings = Settings()
