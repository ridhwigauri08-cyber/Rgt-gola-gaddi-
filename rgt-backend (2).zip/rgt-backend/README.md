# RGT Gola Gaddi — Control API

Backend for the RGT Gola Gaddi AI voice calling assistant dashboard.

This service is the **only** thing that talks to Sarvam AI. The Android app talks
to this service and never sees the Sarvam key.

```
Android app  ──X-API-Key──►  this API  ──api-subscription-key──►  api.sarvam.ai
```

---

## Quick start

```bash
cd rgt-backend
python3 -m venv .venv && source .venv/bin/activate     # optional but recommended
pip install -r requirements.txt

cp .env.example .env          # then edit .env
export APP_API_KEY="$(python3 -c 'import secrets;print(secrets.token_urlsafe(32))')"
export SARVAM_API_KEY="your-sarvam-key"   # optional; voice endpoints stay off without it

uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open <http://localhost:8000/docs> for the interactive Swagger UI.

The database is created and seeded automatically on first start (7 grains,
daily rates, labour, freight slabs, 5 sample calls, 3 bookings).

---

## Authentication

Every endpoint except `/health` requires:

```
X-API-Key: <APP_API_KEY>
```

`/calls/live/ws` takes the key as a query parameter instead:
`ws://host/calls/live/ws?api_key=<APP_API_KEY>`

> **Never put `APP_API_KEY` or `SARVAM_API_KEY` inside the APK.** Anyone can
> unzip an APK and read strings out of it.

---

## Endpoints

### PRD section 11 (the ones the PRD specifies)

| Method | Path | Purpose |
|---|---|---|
| POST | `/rates/publish` | Publish daily rates (validates floor ≤ base, step ≤ margin, >5% jump warning) |
| GET | `/rates/current?grain=&grade=&location=` | Live rate for the assistant. `409 rate_update_pending` when missing/stale |
| POST | `/pricing/quote` | Landed price: grain + labour + freight + other − discount |
| POST | `/bargain/next` | Next allowed offer, floor/ceiling-safe |
| POST | `/calls/{id}/instruction` | Live instruction; `409 floor_override_required` if it breaks the band |
| POST | `/calls/{id}/takeover` | Human takeover |
| GET | `/calls/live` | Live calls (HTTP snapshot) |
| WS | `/calls/live/ws` | Live calls stream, every 3 s |
| POST | `/bookings` | Create booking with computed total |
| GET | `/analytics/summary` | Dashboard metrics |

### Additional endpoints used by the dashboard

`GET /rates`, `GET /calls`, `GET /calls/{id}`, `POST /calls`,
`POST /calls/{id}/turns`, `POST /instructions`, `GET /instructions`,
`GET /bookings`, `PATCH /bookings/{id}`, `GET /health`

### Sarvam proxy (server-side key)

| Method | Path | Purpose |
|---|---|---|
| POST | `/voice/transcribe` | multipart audio → transcript (Saaras) |
| POST | `/voice/speak` | text → base64 WAV (Bulbul) |
| POST | `/voice/chat` | LLM turn |

These return **503** with a clear message if `SARVAM_API_KEY` is not set.

---

## Pricing and bargaining rules

All money logic lives in `app/engines.py` as pure functions, so it is testable
and cannot be talked around by the LLM (PRD rules BG-1 and BG-2).

**Landed price**

```
final = grain_rate × qty
      + labour (loading / unloading / tulai)
      + freight (zone × vehicle × qty, with a minimum charge)
      + other charges
      − discount (incl. quantity slab)
```

**Bargaining** is deterministic: `base → step → max_rounds`, hard-clamped.

### A note on direction (please read)

The PRD contradicts itself in two places:

* **Section 6.2** describes the assistant starting at *base* and conceding
  **downward** toward *floor* (worked example: 2500 → 2490 → 2480 → 2470).
* **Section 22** (sample dialogue) has the farmer asking for a *higher* price and
  the assistant conceding **upward** ("bhaav thoda badha do" → "₹2,510 kar deta hoon").

Both are implemented. Each rate row carries a `direction` field:

* `"down"` — concede down, hard floor at `floor_rate`.
* `"up"` — concede up, hard ceiling at `ceiling_rate`.

The seed data uses `"up"`, because the callers in this business are farmers
selling grain who want a higher price. Change the seed or the published rates to
`"down"` if your commercial model is the opposite.

Rule **BG-4** is also enforced: `previous_offer` is read from the call record, so
a caller who hangs up and re-dials cannot squeeze a better price out of a fresh
conversation.

---

## Tests

```bash
python3 -m pytest tests/ -q
```

11 tests covering auth, rate validation, landed-price maths, floor/ceiling
safety across 6 bargaining rounds, the instruction guard, takeover → booking
flow, analytics and the Sarvam-not-configured path.

---

## Going to production

1. **Postgres** — set `DATABASE_URL=postgresql+psycopg://user:pass@host/db`.
   Add `psycopg[binary]` to `requirements.txt`. Nothing else changes.
2. **Secret management** — put `APP_API_KEY` and `SARVAM_API_KEY` in your
   platform's secret store (AWS Secrets Manager, Doppler, etc.), never in git.
3. **TLS** — terminate HTTPS in front of uvicorn (ALB, nginx, Caddy).
4. **Mumbai region** — the PRD targets low latency; host in `ap-south-1`.
5. **Observability** — the app logs to stdout; ship to Grafana/Sentry as needed.

### Docker

```bash
docker build -t rgt-api .
docker run -p 8000:8000 -e APP_API_KEY=change-me -e SARVAM_API_KEY=xxx rgt-api
```

---

## Wiring the Android app

In the app: **Settings → Backend → Base URL**, enter e.g.
`https://api.yourdomain.com` and the API key. The app then loads live rates,
calls, bookings and analytics from this service. Leave it blank and the app
falls back to its built-in demo data.

---

# Voice pipeline (telephony → AI → caller)

The assistant can now answer a real phone call. One inbound call becomes:

```
PSTN caller
   │  (Twilio number voice webhook)
   ▼
POST /telephony/twilio/voice        -> TwiML <Connect><Stream>
   │
   ▼
WS  /telephony/twilio/stream        -> G.711 mu-law, 8 kHz, 20 ms frames
   │
   ├─ VAD detects end of utterance
   ├─ Sarvam  POST /speech-to-text      (Saaras)
   ├─ agent: LLM + tools (rate / price / bargain / booking / escalate)
   ├─ Sarvam  POST /text-to-speech      (Bulbul)
   └─ mu-law frames streamed back to the caller
```

Every turn is written to `call_turns`, so the Android dashboard's Live Monitor
and transcript update as the call happens.

## Setting up Twilio

1. Buy an Indian number in the Twilio console (DLT registration is required for
   India — do that first, it takes a few days).
2. Point the number's **A call comes in** webhook to
   `https://<your-host>/telephony/twilio/voice` (HTTP POST).
3. Set `PUBLIC_HOST=https://<your-host>` so the TwiML can build the `wss://`
   stream URL behind a proxy or load balancer.
4. Call the number. You should hear the Hindi greeting, then the AI listens.

Media Streams requires a **secure** WebSocket, so terminate TLS in front of
uvicorn (ALB / nginx / Caddy).

## Exotel / Ozonetel

`POST /telephony/exotel/passthru` is a stub with the right shape. Their audio
streaming uses a different applet payload per account — wire your account's
stream URL to a handler shaped like `twilio_stream` and map their event names.

## Trying it without a phone

```bash
curl -X POST http://localhost:8000/voice/simulate \
  -H "X-API-Key: $APP_API_KEY" -H "Content-Type: application/json" \
  -d '{"text": "gehu ka rate kya hai"}'
```

```json
{
  "reply": "Ji, aaj Gehu ka bhaav 2500 rupaye prati quintal hai. Aap kitna quintal laa rahe hain?",
  "tools_used": ["get_rate"],
  "guard_passed": true,
  "offline": true
}
```

With `"speak": true` and a Sarvam key set, it also returns `audio_base64`
(WAV) so you can hear the voice.

`GET /voice/status` shows whether Sarvam is configured and how many calls are
live.

## Guardrails enforced in code, not prompts

| PRD rule | Where it lives |
|---|---|
| BG-1 floor never breached | `engines.next_offer`, plus `create_booking` re-checks the floor |
| BG-2 LLM never invents a rate | `agent.numbers_ok` — any price not returned by a tool is discarded and regenerated |
| Floor never spoken | `tools.get_rate` / `next_bargain_offer` omit floor & ceiling from tool output |
| Barge-in | `pipeline.CallSession.on_audio_frame` cancels playback and sends `clear` |
| Live instruction | `/calls/{id}/instruction` with the floor guard |
| Escalation | `escalate_to_human` tool flips the call to `human` |

## Known limitations (be honest with the client)

- **Turn-based, not full-duplex.** This uses Sarvam's REST STT/TTS, so a turn
  takes roughly 1.5–3 s end to end. The PRD targets 1.2 s. Upgrading to
  Sarvam's **Realtime** STT (`/speech-to-text-realtime/ws`) and **streaming**
  TTS is the next step and is the main latency win available.
- **VAD is energy-based.** It works for clean telephony audio; noisy mandi
  backgrounds will need a better VAD (Silero) or server-side VAD from Sarvam.
- **Recordings are held in memory per call** and not yet uploaded to S3.
- **No outbound calling yet** (PRD Phase 3).
- **Exotel is a stub**, Twilio is the implemented path.

## Tests

```bash
python3 -m pytest tests/ -q      # 30 tests
```

Covers audio codec round-trip, resampling, WAV decoding, VAD segmentation, tool
behaviour (no floor leakage, in-band bargaining, below-floor booking rejected),
the number guard, the offline agent, the simulate endpoint, the Twilio webhook
and a real Media Streams WebSocket handshake.

---

# Connecting Sarvam's hosted voice agent (HTTP Tools)

If you use Sarvam's Voice Agents instead of our own pipeline, your backend
becomes a set of **tools** the hosted agent calls. Use the `/agent/*`
endpoints, **not** the dashboard ones.

> **Why the separate endpoints?** `/bargain/next` returns `floor_rate` because a
> supervisor needs to see it. A language model reading that will eventually say
> it out loud. Every `/agent/*` response is stripped of floor and ceiling, and
> error reasons are made opaque (`not_allowed`, not `below_floor`).

## Prerequisites

1. The API must be reachable from Sarvam's cloud over **public HTTPS**.
   `http://localhost:8000` will always fail with `Not Found` — that is Sarvam's
   own localhost. For testing, expose your machine:
   `cloudflared tunnel --url http://localhost:8000`.
2. Set `PUBLIC_HOST` to that URL.

## Tools to create

Auth on every tool: type **API Key**, key name `X-API-Key`, value = your
`APP_API_KEY` (stored as a secret/vault value — never inline).

| Tool | Method + path | Body |
|---|---|---|
| `get_rate` | POST `/agent/get_rate` | `{"grain":"Gehu","grade":"FAQ"}` |
| `quote` | POST `/agent/quote` | `{"grain":"Gehu","quantity_qtl":40,"zone":"Rampur","vehicle_type":"pickup"}` |
| `bargain` | POST `/agent/bargain` | `{"grain":"Gehu","caller_ask":2600,"round_no":0}` |
| `book` | POST `/agent/book` | `{"caller_name":"...","grain":"Gehu","quantity_qtl":40,"final_rate":2510,"labour":1400,"freight":1800}` |
| `escalate` | POST `/agent/escalate` | `{"reason":"complaint"}` |
| `info` | POST `/agent/info` | `{"topic":"address"}` |

`GET /agent/manifest` returns this list as JSON.

## Mapping response fields into the agent

Use the builder's `@field` syntax against the returned keys:

- after `get_rate` → `@rate_per_quintal`
- after `quote` → `@landed_per_quintal`, `@landed_total`, `@labour`, `@freight`
- after `bargain` → `@offer_per_quintal`, `@action`, `@instruction`
- after `book` → `@total`, `@status`

Example prompt fragment:

```
Rate bataane se pehle get_rate tool call karo. Jo @rate_per_quintal aaye wahi bolo.
Bhaav-taav par bargain tool call karo, aur @offer_per_quintal hi bolo.
Agar @action "escalate" ho to koi naya number mat bolo — callback ya human offer karo.
```

## The `round_no` gotcha

The hosted agent has no per-call state on our side unless you pass `call_id`.
Without it, `bargain` cannot advance rounds on its own. So:

1. Keep a `round_no` variable in the agent's context, starting at `0`.
2. Pass it into every `bargain` call.
3. After each call, set it to the returned `@next_round_no`.

If you skip this, the agent will keep offering round 0 forever and the caller
will never get a second offer.

## Responses you will see

```json
// POST /agent/get_rate
{"available": true, "grain": "Gehu", "grade": "FAQ", "rate_per_quintal": 2500.0, "currency": "INR"}

// POST /agent/bargain
{"ok": true, "offer_per_quintal": 2500.0, "action": "offer", "round_no": 0,
 "next_round_no": 1, "remaining_rounds": 3, "at_limit": false,
 "instruction": "Say this offer out loud, then ask if it works."}

// POST /agent/book (rejected - note the opaque reason)
{"ok": false, "reason": "not_allowed",
 "say": "Is rate par booking nahi ho sakti, main malik se baat karke batata hoon."}
```

`action` values: `offer` (say it), `close` (caller accepted, read back and
confirm), `escalate` (limit reached — callback or human, never a new number).

## Which endpoints NOT to expose to the agent

`/rates`, `/rates/current`, `/pricing/quote`, `/bargain/next`, `/calls/*` —
these are for the dashboard and include the floor. Keep them out of the agent
config entirely.

---

# Sarvam Voice Agent integration (dashboard side)

The Android dashboard shows real calls from your Sarvam agent through this
backend. The app never talks to Sarvam directly — the workspace key stays here.

```
Android app ──X-API-Key──► this API ──X-API-Key (workspace key)──► apps.sarvam.ai
```

## Two different keys — don't mix them

| Purpose | Header | Env var | Host |
|---|---|---|---|
| Model APIs (STT/TTS/chat) | `api-subscription-key` | `SARVAM_API_KEY` | `api.sarvam.ai` |
| Voice Agents (calls, transcripts) | `X-API-Key` | `X_API_KEY` | `apps.sarvam.ai` |

## Configuration

```bash
X_API_KEY=sk_...                       # Settings -> API Key in the Sarvam dashboard
SARVAM_ORG_ID=01a16eb7-...
SARVAM_WORKSPACE_ID=01a16eb7-...
SARVAM_APP_ID=Conversatio-...
SARVAM_DEPLOYMENT_ID=RGT-Gola-Ga-...
SARVAM_COST_PER_MINUTE=3.0             # used to estimate cost per call
WEBHOOK_TOKEN=<random 32+ chars>
```

For outbound calling, additionally:

```bash
SARVAM_CONNECTION_ID=...               # telephony connection id
SARVAM_AGENT_PHONE_NUMBER=+91804...
```

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/sarvam/status` | Is it wired up? Shows the deployment, phone numbers, app_version |
| GET | `/sarvam/calls?hours=24&limit=50` | Recent calls (caller, duration, status, cost) |
| GET | `/sarvam/call/{interaction_id}` | One call's transcript (Hindi/original) |
| GET | `/sarvam/call/{interaction_id}/recording` | Audio for that call |
| POST | `/sarvam/dial` | Place an outbound AI call |
| POST | `/sarvam/webhook` | Sarvam → us, on call completion |
| GET | `/sarvam/events` | Webhook events we stored |

All except `/sarvam/webhook` require the app's `X-API-Key`.

## Webhook setup

Sarvam has no documented request signature, so we authenticate with a shared
token. Point Sarvam's `webhook_config.url` at:

```
https://<your-host>/sarvam/webhook?token=<WEBHOOK_TOKEN>
```

(or send `X-Webhook-Token: <WEBHOOK_TOKEN>`). Events land in the `sarvam_events`
table with the transcript, duration and computed cost.

## Cost per call

Sarvam does not return a price per call, so we estimate it:

```
cost_inr = duration_seconds / 60 × SARVAM_COST_PER_MINUTE
```

rounded half-up. Set `SARVAM_COST_PER_MINUTE` to your actual plan rate; the
default of 3.0 is Sarvam's advertised starting price.

## What the app still needs

The dashboard currently reads `/rates`, `/calls`, `/bookings`. Wiring the new
`/sarvam/*` endpoints into the Live Monitor and Call Logs screens is the next
step — the backend side is ready.

## Verified vs not verified

- 51 tests pass, including 12 for this integration. They run against a mocked
  HTTP transport and assert the exact URLs, headers, query params and payloads
  we send, plus the mapping back into the app's shape.
- **Not tested against the live Sarvam API** — no workspace key was available in
  the build environment. The first real call will confirm field names; the
  mapping in `normalise_interaction` reads them defensively with fallbacks.

---

# Running on AWS Lambda

See `deploy/aws-lambda/README.md` for the full runbook.

Quick version:

```bash
cd deploy/aws-lambda
cp env.lambda.example env.lambda     # DATABASE_URL must be RDS Postgres
./deploy.sh                          # builds linux/amd64, pushes to ECR, creates the function
```

Then put an API Gateway **HTTP API** in front (`ANY /{proxy+}`, payload 2.0).

**Four things that differ from a normal server:**

1. **SQLite will not work.** Lambda's disk is read-only and `/tmp` is wiped
   between invocations. `app/lambda_handler.py` raises `LambdaConfigError` at
   startup if `DATABASE_URL` is SQLite, rather than losing data silently.
2. **WebSockets are not reachable** (`/calls/live/ws`,
   `/telephony/twilio/stream`). The dashboard polls HTTP instead, and the Sarvam
   hosted-agent path is unaffected.
3. **API Gateway caps requests at 29 s** — `/voice/transcribe` with a 30 s clip
   can exceed that.
4. **Cold starts** cost 1–3 s; use provisioned concurrency (1 is enough).

Entry point: `app/lambda_handler.handler` (Mangum wrapping the FastAPI app).
