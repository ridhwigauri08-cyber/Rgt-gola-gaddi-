"""
Sarvam AI client.

The subscription key lives ONLY here, in the server's environment. The Android
app never sees it - it calls our own endpoints instead, and we proxy.

Endpoints used (see https://docs.sarvam.ai):
  POST {base}/speech-to-text     - Saaras, transcribe / translate / translit / codemix
  POST {base}/text-to-speech     - Bulbul, returns base64 audio
  POST {base}/chat/completions   - LLM turn
Authentication header: api-subscription-key
"""
from __future__ import annotations

import httpx

from .config import settings


class SarvamNotConfigured(RuntimeError):
    """Raised when SARVAM_API_KEY is empty."""


def is_configured() -> bool:
    return settings.sarvam_configured


def _headers() -> dict[str, str]:
    return {"api-subscription-key": settings.sarvam_api_key}


def _require_key() -> None:
    if not settings.sarvam_configured:
        raise SarvamNotConfigured(
            "SARVAM_API_KEY is not set on the server. Add it to the environment "
            "and restart. Never place this key in the mobile app."
        )


async def transcribe(
    audio_bytes: bytes,
    filename: str = "audio.wav",
    language_code: str = "hi-IN",
    mode: str = "transcribe",
    model: str | None = None,
) -> dict:
    """Speech -> text. `mode` may be transcribe|translate|verbatim|translit|codemix."""
    _require_key()
    files = {"file": (filename, audio_bytes, "application/octet-stream")}
    data = {
        "model": model or settings.sarvam_stt_model,
        "mode": mode,
        "language_code": language_code,
    }
    async with httpx.AsyncClient(timeout=90.0) as client:
        resp = await client.post(
            f"{settings.sarvam_base_url}/speech-to-text",
            headers=_headers(),
            files=files,
            data=data,
        )
        resp.raise_for_status()
        return resp.json()


async def speak(
    text: str,
    language_code: str = "hi-IN",
    speaker: str | None = None,
    model: str | None = None,
) -> dict:
    """Text -> speech. Returns the raw base64 audio the API gives us."""
    _require_key()
    payload = {
        "text": text,
        "language_code": language_code,
        "speaker": speaker or settings.sarvam_tts_speaker,
        "model": model or settings.sarvam_tts_model,
    }
    async with httpx.AsyncClient(timeout=90.0) as client:
        resp = await client.post(
            f"{settings.sarvam_base_url}/text-to-speech",
            headers=_headers(),
            json=payload,
        )
        resp.raise_for_status()
        data = resp.json()
    audios = data.get("audios") or []
    return {
        "request_id": data.get("request_id"),
        "audio_base64": "".join(audios),
        "format": "wav",
    }


async def chat(
    messages: list[dict],
    temperature: float = 0.3,
    tools: list[dict] | None = None,
    tool_choice: str | None = None,
) -> dict:
    """One LLM turn. The caller supplies the system prompt (and optional tools)."""
    _require_key()
    payload: dict = {
        "model": settings.sarvam_chat_model,
        "messages": messages,
        "temperature": temperature,
    }
    if tools:
        payload["tools"] = tools
        payload["tool_choice"] = tool_choice or "auto"
    async with httpx.AsyncClient(timeout=90.0) as client:
        resp = await client.post(
            f"{settings.sarvam_base_url}/chat/completions",
            headers=_headers(),
            json=payload,
        )
        resp.raise_for_status()
        return resp.json()
