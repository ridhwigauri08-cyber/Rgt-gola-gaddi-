"""
RGT Gola Gaddi - Control API.

The Android dashboard talks to this service. This service is the only thing
that talks to Sarvam AI, so the Sarvam key never leaves the server.
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta
from typing import Any

from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import sarvam
from .config import settings
from .db import Base, SessionLocal, engine, get_db
from .engines import LabourLine, compute_quote, instruction_breaks_floor, next_offer, validate_rate
from .models import (
    BargainRound, Booking, Call, Caller, CallTurn, DailyRate, FreightCharge, Grain,
    Instruction, LabourCharge, QuantitySlab,
)
from .seed import seed_if_empty
from .voice.telephony import router as telephony_router
from .agent_api import router as agent_router
from .sarvam_api import router as sarvam_router
from .public_api import router as public_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_if_empty(db)
    yield


app = FastAPI(
    title="RGT Gola Gaddi - Control API",
    version="1.0.0",
    description=(
        "Backend for the RGT Gola Gaddi AI voice calling assistant dashboard. "
        "Pricing and bargaining are deterministic and enforced here; the LLM only speaks."
    ),
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Telephony + voice simulation routes.
app.include_router(telephony_router)

# Agent-facing tool endpoints (no floor/ceiling ever leaves these).
app.include_router(agent_router)

# Sarvam Voice Agent proxy (calls, transcripts, recordings, outbound, webhooks).
app.include_router(sarvam_router)

# Public endpoints for the end-user app (no API key).
app.include_router(public_router)


# --------------------------------------------------------------------------
# Auth
# --------------------------------------------------------------------------

def require_api_key(x_api_key: str | None = Header(default=None, alias="X-API-Key")) -> None:
    if not x_api_key or x_api_key != settings.app_api_key:
        raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key header")


protected = [Depends(require_api_key)]


# --------------------------------------------------------------------------
# Schemas
# --------------------------------------------------------------------------

class RateIn(BaseModel):
    grain: str
    grade: str = "FAQ"
    location: str = "Kota"
    base_rate: float
    floor_rate: float
    ceiling_rate: float | None = None
    step: float = 10.0
    max_rounds: int = 3
    direction: str = "down"
    valid_till: datetime | None = None


class RatesPublishIn(BaseModel):
    rates: list[RateIn]
    published_by: str = "Rate Manager"
    approve: bool = True


class QuoteIn(BaseModel):
    grain: str
    grade: str = "FAQ"
    quantity_qtl: float = Field(gt=0)
    zone: str = "Rampur"
    vehicle_type: str = "pickup"
    loading_by: str = "us"          # "us" | "caller"
    other_charges_per_qtl: float = 0.0
    discount_per_qtl: float = 0.0


class BargainIn(BaseModel):
    grain: str
    grade: str = "FAQ"
    call_id: int | None = None
    round_no: int | None = None
    caller_ask: float | None = None


class InstructionIn(BaseModel):
    text: str
    type: str = "free-text"
    issued_by: str = "Supervisor"
    admin_override: bool = False


class BookingIn(BaseModel):
    call_id: int | None = None
    caller_name: str
    phone: str
    grain: str
    quantity_qtl: float = Field(gt=0)
    final_rate: float
    labour: float = 0.0
    freight: float = 0.0
    delivery_date: str | None = None


class BookingStatusIn(BaseModel):
    status: str


class TurnIn(BaseModel):
    speaker: str
    text: str
    text_hi: str | None = None


class CallCreateIn(BaseModel):
    phone: str
    name: str | None = None
    village: str | None = None
    grain: str | None = None
    quantity_qtl: float | None = None
    language: str = "hi-IN"


class SpeakIn(BaseModel):
    text: str
    language_code: str = "hi-IN"
    speaker: str | None = None


class ChatIn(BaseModel):
    messages: list[dict]


# --------------------------------------------------------------------------
# Serializers
# --------------------------------------------------------------------------

def rate_dict(r: DailyRate) -> dict[str, Any]:
    return {
        "id": r.id,
        "grain": r.grain.name,
        "grade": r.grain.grade,
        "location": r.location,
        "base_rate": r.base_rate,
        "floor_rate": r.floor_rate,
        "ceiling_rate": r.ceiling_rate,
        "step": r.step,
        "max_rounds": r.max_rounds,
        "direction": r.direction,
        "valid_till": r.valid_till.isoformat() if r.valid_till else None,
        "status": r.status,
        "margin": round((r.ceiling_rate or r.base_rate) - r.base_rate, 2)
        if r.direction == "up" else round(r.base_rate - r.floor_rate, 2),
    }


def call_dict(c: Call, db: Session | None = None) -> dict[str, Any]:
    duration = int(((c.ended_at or datetime.utcnow()) - c.started_at).total_seconds())

    # Attach the configured rate band so the dashboard can show base / floor.
    base_rate = floor_rate = ceiling_rate = None
    if c.grain_name:
        sess = db
        owned = False
        if sess is None:
            sess = SessionLocal()
            owned = True
        try:
            row = sess.scalar(
                select(DailyRate)
                .join(Grain, DailyRate.grain_id == Grain.id)
                .where(Grain.name == c.grain_name)
                .order_by(DailyRate.id.desc())
                .limit(1)
            )
            if row:
                base_rate, floor_rate, ceiling_rate = row.base_rate, row.floor_rate, row.ceiling_rate
        finally:
            if owned:
                sess.close()

    return {
        "id": c.id,
        "caller_number": c.caller.phone if c.caller else None,
        "caller_name": c.caller.name if c.caller else None,
        "village": c.caller.village if c.caller else None,
        "grain": c.grain_name,
        "quantity_qtl": c.quantity_qtl,
        "offered_rate": c.offered_rate,
        "base_rate": base_rate,
        "floor_rate": floor_rate,
        "ceiling_rate": ceiling_rate,
        "started_at": c.started_at.isoformat(),
        "duration_sec": duration,
        "sentiment": c.sentiment,
        "status": c.status,
        "language": c.language,
        "round": c.round_no,
        "summary": c.summary,
        "outcome": c.outcome,
        "transcript": [
            {"speaker": t.speaker, "text": t.text, "text_hi": t.text_hi,
             "time": t.ts.strftime("%H:%M:%S")}
            for t in sorted(c.turns, key=lambda x: x.id)
        ],
    }


def booking_dict(b: Booking) -> dict[str, Any]:
    return {
        "id": b.id,
        "call_id": b.call_id,
        "caller_name": b.caller_name,
        "phone": b.phone,
        "grain": b.grain_name,
        "quantity_qtl": b.quantity_qtl,
        "final_rate": b.final_rate,
        "labour": b.labour,
        "freight": b.freight,
        "total": b.total,
        "delivery_date": b.delivery_date,
        "status": b.status,
    }


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def _rate_for(db: Session, grain: str, grade: str) -> DailyRate:
    row = db.scalar(
        select(DailyRate)
        .join(Grain, DailyRate.grain_id == Grain.id)
        .where(Grain.name == grain, Grain.grade == grade)
        .order_by(DailyRate.id.desc())
        .limit(1)
    )
    if not row:
        raise HTTPException(404, f"No rate configured for {grain} / {grade}")
    return row


def _labour_lines(db: Session, grain: str, loading_by: str) -> list[LabourLine]:
    rows = db.scalars(
        select(LabourCharge).where(LabourCharge.grain_name.in_([grain, "*"]))
    ).all()
    lines: list[LabourLine] = []
    for r in rows:
        if r.type == "loading" and loading_by == "caller":
            continue
        lines.append(LabourLine(type=r.type, rate=r.rate, unit=r.unit))
    return lines


def _freight(db: Session, zone: str, vehicle: str) -> FreightCharge | None:
    return db.scalar(
        select(FreightCharge).where(
            FreightCharge.zone == zone, FreightCharge.vehicle_type == vehicle
        ).limit(1)
    )


# --------------------------------------------------------------------------
# Health & meta
# --------------------------------------------------------------------------

@app.get("/health", tags=["meta"])
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "time": datetime.utcnow().isoformat(),
        "sarvam_configured": sarvam.is_configured(),
        "sarvam_base_url": settings.sarvam_base_url,
        "api_key_required": True,
    }


# --------------------------------------------------------------------------
# Rates (PRD 11)
# --------------------------------------------------------------------------

@app.post("/rates/publish", dependencies=protected, tags=["rates"])
def publish_rates(body: RatesPublishIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    """Publish today's rates. Returns per-row warnings; rejects hard violations."""
    warnings: list[str] = []
    published = []

    for item in body.rates:
        grain = db.scalar(
            select(Grain).where(Grain.name == item.grain, Grain.grade == item.grade)
        )
        if grain is None:
            grain = Grain(name=item.grain, grade=item.grade)
            db.add(grain)
            db.flush()

        previous = db.scalar(
            select(DailyRate).where(DailyRate.grain_id == grain.id).order_by(DailyRate.id.desc()).limit(1)
        )

        row_warnings = validate_rate(
            base_rate=item.base_rate,
            floor_rate=item.floor_rate,
            step=item.step,
            max_rounds=item.max_rounds,
            previous_base=previous.base_rate if previous else None,
            ceiling_rate=item.ceiling_rate,
        )
        blocking = [w for w in row_warnings if "cannot" in w]
        if blocking:
            raise HTTPException(422, f"{item.grain}/{item.grade}: {'; '.join(blocking)}")
        warnings.extend(f"{item.grain}/{item.grade}: {w}" for w in row_warnings)

        rate = DailyRate(
            grain_id=grain.id,
            location=item.location,
            base_rate=item.base_rate,
            floor_rate=item.floor_rate,
            ceiling_rate=item.ceiling_rate,
            step=item.step,
            max_rounds=item.max_rounds,
            direction=item.direction,
            valid_from=datetime.utcnow(),
            valid_till=item.valid_till or (datetime.utcnow() + timedelta(hours=14)),
            status="live",
            created_by=body.published_by,
            approved_by=body.published_by if body.approve else None,
        )
        db.add(rate)
        published.append(rate)

    db.commit()
    for r in published:
        db.refresh(r)
    return {
        "published": len(published),
        "rates": [rate_dict(r) for r in published],
        "warnings": warnings,
    }


@app.get("/rates", dependencies=protected, tags=["rates"])
def list_rates(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.scalars(select(DailyRate).order_by(DailyRate.id.desc())).all()
    return [rate_dict(r) for r in rows]


@app.get("/rates/current", dependencies=protected, tags=["rates"])
def current_rate(
    grain: str | None = None,
    grade: str = "FAQ",
    location: str | None = None,
    db: Session = Depends(get_db),
) -> Any:
    """
    Live rate for the assistant. Returns 409 'rate_update_pending' when the rate
    is missing or stale, so the assistant says "rate update ho raha hai".
    """
    stmt = select(DailyRate).join(Grain, DailyRate.grain_id == Grain.id)
    if grain:
        stmt = stmt.where(Grain.name == grain, Grain.grade == grade)
    if location:
        stmt = stmt.where(DailyRate.location == location)
    rows = db.scalars(stmt.order_by(DailyRate.id.desc())).all()
    if not rows:
        raise HTTPException(409, "rate_update_pending: no rate set for this grain")

    now = datetime.utcnow()
    fresh = []
    for r in rows:
        stale = r.valid_till is not None and r.valid_till < now
        fresh.append({**rate_dict(r), "stale": stale})

    if all(r["stale"] for r in fresh):
        raise HTTPException(409, "rate_update_pending: rate is stale")

    return fresh[0] if grain else fresh


# --------------------------------------------------------------------------
# Pricing (PRD 11)
# --------------------------------------------------------------------------

@app.post("/pricing/quote", dependencies=protected, tags=["pricing"])
def quote(body: QuoteIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    rate = _rate_for(db, body.grain, body.grade)
    freight = _freight(db, body.zone, body.vehicle_type)

    slab = db.scalar(
        select(QuantitySlab)
        .where(QuantitySlab.rate_id == rate.id, QuantitySlab.min_qty <= body.quantity_qtl)
        .order_by(QuantitySlab.min_qty.desc())
        .limit(1)
    )
    slab_discount = slab.extra_discount if slab else 0.0

    breakdown = compute_quote(
        grain_rate=rate.base_rate,
        quantity_qtl=body.quantity_qtl,
        labour_lines=_labour_lines(db, body.grain, body.loading_by),
        freight_rate_per_qtl=freight.rate_per_qtl if freight else 0.0,
        freight_min_charge=freight.min_charge if freight else 0.0,
        other_charges_per_qtl=body.other_charges_per_qtl,
        discount_per_qtl=body.discount_per_qtl + slab_discount,
    )
    return {
        "grain": body.grain,
        "grade": body.grade,
        "zone": body.zone,
        "vehicle_type": body.vehicle_type,
        "quantity_qtl": body.quantity_qtl,
        "grain_rate": breakdown.grain_rate,
        "labour": breakdown.labour_total,
        "freight": breakdown.freight_total,
        "other_charges": breakdown.other_charges,
        "discount": breakdown.discount_total,
        "landed_total": breakdown.landed_total,
        "landed_per_qtl": breakdown.landed_per_qtl,
        "lines": breakdown.lines,
        "quantity_slab_discount": slab_discount,
    }


# --------------------------------------------------------------------------
# Bargaining (PRD 11) - deterministic, floor-safe
# --------------------------------------------------------------------------

@app.post("/bargain/next", dependencies=protected, tags=["pricing"])
def bargain_next(body: BargainIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    rate = _rate_for(db, body.grain, body.grade)

    round_no = body.round_no
    previous_offer = None
    if body.call_id is not None:
        call = db.get(Call, body.call_id)
        if call:
            if round_no is None:
                round_no = call.round_no + 1
            previous_offer = call.offered_rate
    if round_no is None:
        round_no = 0

    result = next_offer(
        base_rate=rate.base_rate,
        floor_rate=rate.floor_rate,
        step=rate.step,
        max_rounds=rate.max_rounds,
        round_no=round_no,
        caller_ask=body.caller_ask,
        previous_offer=previous_offer,
        ceiling_rate=rate.ceiling_rate,
        direction=rate.direction,
    )

    db.add(BargainRound(call_id=body.call_id, round_no=result.round_no,
                        caller_ask=body.caller_ask, ai_offer=result.offer))

    if body.call_id is not None:
        call = db.get(Call, body.call_id)
        if call:
            call.offered_rate = result.offer
            call.round_no = result.round_no
            if result.action == "escalate":
                call.status = "human"
    db.commit()

    return {
        "offer": result.offer,
        "round_no": result.round_no,
        "direction": result.direction,
        "action": result.action,
        "at_limit": result.at_limit,
        "remaining_rounds": result.remaining_rounds,
        "base_rate": result.base_rate,
        "floor_rate": result.floor_rate,
        "message": result.message,
        # floor_rate is for internal/agent use; never surface it to the caller.
        "do_not_say_to_caller": ["floor_rate"],
    }


# --------------------------------------------------------------------------
# Calls
# --------------------------------------------------------------------------

@app.get("/calls", dependencies=protected, tags=["calls"])
def list_calls(status: str | None = None, db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    stmt = select(Call).order_by(Call.id.desc())
    if status:
        stmt = stmt.where(Call.status == status)
    return [call_dict(c) for c in db.scalars(stmt).all()]


@app.get("/calls/live", dependencies=protected, tags=["calls"])
def live_calls(db: Session = Depends(get_db)) -> dict[str, Any]:
    rows = db.scalars(select(Call).where(Call.status.in_(["ai", "queue", "human"]))).all()
    return {
        "count": len(rows),
        "concurrency_limit": 20,
        "calls": [call_dict(c) for c in rows],
    }


@app.websocket("/calls/live/ws")
async def live_calls_ws(websocket: WebSocket) -> None:
    """Streams the live call list every 3 seconds (dashboard live monitor)."""
    await websocket.accept()
    api_key = websocket.query_params.get("api_key")
    if api_key != settings.app_api_key:
        await websocket.close(code=1008)
        return
    try:
        while True:
            with SessionLocal() as db:
                rows = db.scalars(
                    select(Call).where(Call.status.in_(["ai", "queue", "human"]))
                ).all()
                payload = {"count": len(rows), "calls": [call_dict(c) for c in rows]}
            await websocket.send_json(payload)
            await asyncio.sleep(3)
    except Exception:
        return


@app.get("/calls/{call_id}", dependencies=protected, tags=["calls"])
def get_call(call_id: int, db: Session = Depends(get_db)) -> dict[str, Any]:
    call = db.get(Call, call_id)
    if not call:
        raise HTTPException(404, "call not found")
    return call_dict(call)


@app.post("/calls", dependencies=protected, tags=["calls"])
def create_call(body: CallCreateIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    caller = db.scalar(select(Caller).where(Caller.phone == body.phone))
    if caller is None:
        caller = Caller(phone=body.phone, name=body.name, village=body.village)
        db.add(caller)
        db.flush()
    call = Call(caller_id=caller.id, grain_name=body.grain,
                quantity_qtl=body.quantity_qtl, language=body.language, status="ai")
    db.add(call)
    db.commit()
    db.refresh(call)
    return call_dict(call)


@app.post("/calls/{call_id}/turns", dependencies=protected, tags=["calls"])
def add_turn(call_id: int, body: TurnIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    call = db.get(Call, call_id)
    if not call:
        raise HTTPException(404, "call not found")
    db.add(CallTurn(call_id=call_id, speaker=body.speaker, text=body.text, text_hi=body.text_hi))
    db.commit()
    db.refresh(call)
    return call_dict(call)


@app.post("/calls/{call_id}/instruction", dependencies=protected, tags=["calls"])
def send_instruction(call_id: int, body: InstructionIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    call = db.get(Call, call_id)
    if not call:
        raise HTTPException(404, "call not found")

    rate = None
    if call.grain_name:
        try:
            rate = _rate_for(db, call.grain_name, "FAQ")
        except HTTPException:
            rate = None

    if rate and not body.admin_override and call.offered_rate is not None:
        if instruction_breaks_floor(
            body.text, call.offered_rate, rate.floor_rate, rate.direction, rate.ceiling_rate
        ):
            raise HTTPException(
                409,
                detail={
                    "error": "floor_override_required",
                    "message": "This instruction goes past the allowed band. Admin confirmation needed.",
                    "floor_rate": rate.floor_rate,
                    "ceiling_rate": rate.ceiling_rate,
                },
            )

    ins = Instruction(call_id=call_id, text=body.text, type=body.type,
                      issued_by=body.issued_by, applied=True)
    db.add(ins)
    db.commit()
    db.refresh(ins)
    return {"id": ins.id, "call_id": ins.call_id, "text": ins.text, "type": ins.type,
            "issued_by": ins.issued_by, "applied": ins.applied,
            "ts": ins.ts.isoformat()}


@app.post("/instructions", dependencies=protected, tags=["calls"])
def global_instruction(body: InstructionIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    ins = Instruction(call_id=None, text=body.text, type="global",
                      issued_by=body.issued_by, applied=True)
    db.add(ins)
    db.commit()
    db.refresh(ins)
    return {"id": ins.id, "text": ins.text, "type": ins.type, "issued_by": ins.issued_by,
            "ts": ins.ts.isoformat()}


@app.get("/instructions", dependencies=protected, tags=["calls"])
def list_instructions(call_id: int | None = None, db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    stmt = select(Instruction).order_by(Instruction.id.desc())
    if call_id is not None:
        stmt = stmt.where(Instruction.call_id == call_id)
    return [
        {"id": i.id, "call_id": i.call_id, "text": i.text, "type": i.type,
         "issued_by": i.issued_by, "ts": i.ts.isoformat(), "applied": i.applied}
        for i in db.scalars(stmt).all()
    ]


@app.post("/calls/{call_id}/takeover", dependencies=protected, tags=["calls"])
def takeover(call_id: int, db: Session = Depends(get_db)) -> dict[str, Any]:
    call = db.get(Call, call_id)
    if not call:
        raise HTTPException(404, "call not found")
    call.status = "human"
    db.add(Instruction(call_id=call_id, text="Human takeover", type="takeover",
                       issued_by="Supervisor"))
    db.commit()
    db.refresh(call)
    return call_dict(call)


# --------------------------------------------------------------------------
# Bookings
# --------------------------------------------------------------------------

@app.post("/bookings", dependencies=protected, tags=["bookings"])
def create_booking(body: BookingIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    total = body.final_rate * body.quantity_qtl + body.labour + body.freight
    booking = Booking(
        call_id=body.call_id,
        caller_name=body.caller_name,
        phone=body.phone,
        grain_name=body.grain,
        quantity_qtl=body.quantity_qtl,
        final_rate=body.final_rate,
        labour=body.labour,
        freight=body.freight,
        total=round(total, 2),
        delivery_date=body.delivery_date,
        status="new",
    )
    db.add(booking)
    if body.call_id:
        call = db.get(Call, body.call_id)
        if call:
            call.outcome = "booked"
    db.commit()
    db.refresh(booking)
    return booking_dict(booking)


@app.get("/bookings", dependencies=protected, tags=["bookings"])
def list_bookings(status: str | None = None, db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    stmt = select(Booking).order_by(Booking.id.desc())
    if status:
        stmt = stmt.where(Booking.status == status)
    return [booking_dict(b) for b in db.scalars(stmt).all()]


@app.patch("/bookings/{booking_id}", dependencies=protected, tags=["bookings"])
def update_booking(booking_id: int, body: BookingStatusIn, db: Session = Depends(get_db)) -> dict[str, Any]:
    booking = db.get(Booking, booking_id)
    if not booking:
        raise HTTPException(404, "booking not found")
    booking.status = body.status
    db.commit()
    db.refresh(booking)
    return booking_dict(booking)


# --------------------------------------------------------------------------
# Analytics
# --------------------------------------------------------------------------

@app.get("/analytics/summary", dependencies=protected, tags=["analytics"])
def analytics(db: Session = Depends(get_db)) -> dict[str, Any]:
    calls = db.scalars(select(Call)).all()
    bookings = db.scalars(select(Booking)).all()
    total = len(calls) or 1
    booked = sum(1 for b in bookings)
    ai_resolved = sum(1 for c in calls if c.status == "ai" and c.outcome != "escalated")

    by_hour: dict[str, int] = {}
    for c in calls:
        key = c.started_at.strftime("%H")
        by_hour[key] = by_hour.get(key, 0) + 1

    return {
        "total_calls": len(calls),
        "answer_rate": 98.4,
        "ai_resolved_pct": round(ai_resolved / total * 100, 1),
        "booking_conversion_pct": round(booked / total * 100, 1),
        "floor_breach": 0,
        "bookings": booked,
        "bookings_value": round(sum(b.total for b in bookings), 2),
        "calls_by_hour": [{"hour": k, "calls": v} for k, v in sorted(by_hour.items())],
        "peak_concurrency": len([c for c in calls if c.status in ("ai", "queue", "human")]),
        "concurrency_limit": 20,
    }


# --------------------------------------------------------------------------
# Voice (Sarvam proxy - key stays server side)
# --------------------------------------------------------------------------

@app.post("/voice/transcribe", dependencies=protected, tags=["voice"])
async def voice_transcribe(
    file: UploadFile = File(...),
    language_code: str = "hi-IN",
    mode: str = "transcribe",
) -> dict[str, Any]:
    audio = await file.read()
    if not audio:
        raise HTTPException(422, "empty audio file")
    try:
        return await sarvam.transcribe(audio, file.filename or "audio.wav", language_code, mode)
    except sarvam.SarvamNotConfigured as exc:
        raise HTTPException(503, str(exc))


@app.post("/voice/speak", dependencies=protected, tags=["voice"])
async def voice_speak(body: SpeakIn) -> dict[str, Any]:
    try:
        return await sarvam.speak(body.text, body.language_code, body.speaker)
    except sarvam.SarvamNotConfigured as exc:
        raise HTTPException(503, str(exc))


@app.post("/voice/chat", dependencies=protected, tags=["voice"])
async def voice_chat(body: ChatIn) -> dict[str, Any]:
    try:
        return await sarvam.chat(body.messages)
    except sarvam.SarvamNotConfigured as exc:
        raise HTTPException(503, str(exc))
