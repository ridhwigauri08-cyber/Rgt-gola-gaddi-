"""Seed the database with a realistic mandi dataset (idempotent)."""
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import (
    Booking, Call, Caller, CallTurn, DailyRate, FreightCharge, Grain,
    LabourCharge, QuantitySlab,
)

GRAINS = [
    ("Gehu", "FAQ"), ("Gehu", "Mill"), ("Chana", "Desi"), ("Soyabean", "FAQ"),
    ("Makka", "FAQ"), ("Bajra", "FAQ"), ("Sarson", "FAQ"),
]

# (grain, grade, base, floor, ceiling, step, max_rounds, direction)
RATES = [
    ("Gehu", "FAQ", 2500, 2470, 2540, 10, 3, "up"),
    ("Gehu", "Mill", 2540, 2510, 2580, 10, 3, "up"),
    ("Chana", "Desi", 4800, 4740, 4860, 20, 3, "up"),
    ("Soyabean", "FAQ", 4450, 4400, 4500, 10, 4, "up"),
    ("Makka", "FAQ", 2150, 2120, 2180, 10, 3, "up"),
    ("Bajra", "FAQ", 2350, 2310, 2380, 10, 3, "up"),
    ("Sarson", "FAQ", 5600, 5530, 5680, 20, 4, "up"),
]

LABOUR = [
    ("*", "loading", 15.0, "qtl"),
    ("*", "unloading", 12.0, "qtl"),
    ("*", "tulai", 8.0, "qtl"),
]

# (zone, vehicle, rate_per_qtl, min_charge)
FREIGHT = [
    ("Rampur", "pickup", 45.0, 500.0),
    ("Rampur", "407", 38.0, 800.0),
    ("Kota", "10-wheeler", 30.0, 1500.0),
    ("Kota", "trailer", 26.0, 2500.0),
    ("Ajmer", "407", 42.0, 900.0),
    ("Bhilwara", "pickup", 50.0, 600.0),
    ("Jodhpur", "10-wheeler", 34.0, 1600.0),
]


def seed_if_empty(db: Session) -> bool:
    if db.scalar(select(Grain).limit(1)):
        return False

    grain_map: dict[tuple[str, str], Grain] = {}
    for name, grade in GRAINS:
        g = Grain(name=name, grade=grade)
        db.add(g)
        grain_map[(name, grade)] = g
    db.flush()

    now = datetime.utcnow()
    for name, grade, base, floor, ceiling, step, rounds, direction in RATES:
        g = grain_map[(name, grade)]
        r = DailyRate(
            grain_id=g.id,
            location="Kota",
            base_rate=base,
            floor_rate=floor,
            ceiling_rate=ceiling,
            step=step,
            max_rounds=rounds,
            direction=direction,
            valid_from=now,
            valid_till=now + timedelta(hours=14),
            status="live",
            created_by="Rate Manager",
            approved_by="Admin",
        )
        db.add(r)
        db.flush()
        if name in ("Gehu", "Sarson"):
            db.add(QuantitySlab(rate_id=r.id, min_qty=50, max_qty=None, extra_discount=10.0))

    for grain_name, ltype, rate, unit in LABOUR:
        db.add(LabourCharge(grain_name=grain_name, type=ltype, rate=rate, unit=unit))

    for zone, vehicle, per_qtl, minimum in FREIGHT:
        db.add(FreightCharge(zone=zone, vehicle_type=vehicle,
                             rate_per_qtl=per_qtl, min_charge=minimum))

    callers = [
        Caller(phone="+919800011223", name="Ramesh Yadav", village="Rampur", type="kisan"),
        Caller(phone="+919400055671", name="Unknown", village="Bhilwara", type="kisan"),
        Caller(phone="+919000088214", name="Suresh Patel", village="Kota", type="vyapari", tag="VIP"),
        Caller(phone="+919900033410", name="Bhanwar Lal", village="Ajmer", type="kisan"),
        Caller(phone="+919700071198", name="Mahesh Kumar", village="Jodhpur", type="vyapari"),
    ]
    for c in callers:
        db.add(c)
    db.flush()

    live_specs = [
        (callers[0], "ai", "Gehu", 40, 2500.0, "neutral", 0),
        (callers[1], "ai", "Chana", 15, 4800.0, "happy", 0),
        (callers[2], "human", "Sarson", 120, 5600.0, "angry", 2),
        (callers[3], "queue", "Makka", 8, None, "neutral", 0),
        (callers[4], "ai", "Soyabean", 60, 4450.0, "happy", 1),
    ]
    transcripts = {
        0: [
            ("ai", "Namaste, RGT Gola Gaddi me aapka swagat hai. Bataiye, main kya madad karun?",
             "नमस्ते, RGT गोला गद्दी में आपका स्वागत है। बताइए, मैं क्या मदद करूँ?"),
            ("caller", "Gehu ka bhaav kya chal raha hai?", "गेहूँ का भाव क्या चल रहा है?"),
            ("ai", "Ji, aaj gehu ka bhaav Rs 2500 prati quintal hai. Kitna maal hai?",
             "जी, आज गेहूँ का भाव ₹2500 प्रति क्विंटल है। कितना माल है?"),
        ],
        2: [
            ("ai", "Ji, sarson Rs 5600 prati quintal hai.", "जी, सरसों ₹5600 प्रति क्विंटल है।"),
            ("caller", "Nahi, malik se baat karao.", "नहीं, मालिक से बात कराओ।"),
        ],
        3: [
            ("queue-ai", "Namaste, main aapka call abhi le raha hoon. Aapka naam aur kaam bata dijiye.",
             "नमस्ते, मैं आपका कॉल अभी ले रहा हूँ। आपका नाम और काम बता दीजिए।"),
        ],
    }

    for idx, (caller, status, grain, qty, offered, sentiment, rnd) in enumerate(live_specs):
        call = Call(
            caller_id=caller.id,
            started_at=now - timedelta(minutes=idx + 1),
            language="hi-IN",
            status=status,
            grain_name=grain,
            quantity_qtl=qty,
            offered_rate=offered,
            round_no=rnd,
            sentiment=sentiment,
        )
        db.add(call)
        db.flush()
        for speaker, text, text_hi in transcripts.get(idx, []):
            db.add(CallTurn(call_id=call.id, speaker=speaker, text=text, text_hi=text_hi))

    bookings = [
        ("Ramesh Yadav", "+919800011223", "Gehu", 40, 2490.0, 600.0, 1800.0, 101400.0, "2026-10-26", "confirmed"),
        ("Mahesh Kumar", "+919700071198", "Soyabean", 60, 4440.0, 900.0, 2700.0, 270000.0, "2026-10-26", "dispatched"),
        ("Bhanwar Lal", "+919900033410", "Sarson", 80, 5540.0, 1600.0, 4000.0, 449000.0, "2026-10-27", "confirmed"),
    ]
    for name, phone, grain, qty, rate, labour, freight, total, ddate, status in bookings:
        db.add(Booking(caller_name=name, phone=phone, grain_name=grain, quantity_qtl=qty,
                       final_rate=rate, labour=labour, freight=freight, total=total,
                       delivery_date=ddate, status=status))

    db.commit()
    return True
