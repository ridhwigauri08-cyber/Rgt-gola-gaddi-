"""Tests for the voice pipeline: audio, tools, agent, telephony, simulate."""
import io
import os
import pathlib
import wave
from array import array

DB_PATH = pathlib.Path(__file__).parent / "test_rgt.db"
os.environ.setdefault("DATABASE_URL", f"sqlite:///{DB_PATH}")
os.environ.setdefault("APP_API_KEY", "test-key")
os.environ.setdefault("SARVAM_API_KEY", "")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.db import SessionLocal  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Call  # noqa: E402
from app.voice import audio  # noqa: E402
from app.voice import tools as voice_tools  # noqa: E402
from app.voice.agent import _offline_reply, numbers_ok, extract_numbers  # noqa: E402

HEADERS = {"X-API-Key": "test-key"}


def client() -> TestClient:
    return TestClient(app)


def _tone_frames(amplitude: int, count: int) -> list[bytes]:
    frames = []
    for _ in range(count):
        samples = array("h", [amplitude, -amplitude] * 80)  # 160 samples = 20 ms
        frames.append(samples.tobytes())
    return frames


def _silence_frames(count: int) -> list[bytes]:
    return [b"\x00" * 320 for _ in range(count)]


# ------------------------------------------------------------------ audio

def test_ulaw_roundtrip_is_close():
    samples = array("h", [0, 1000, -1000, 8000, -8000, 20000, -20000])
    pcm = samples.tobytes()
    decoded = array("h")
    decoded.frombytes(audio.ulaw_to_pcm16(audio.pcm16_to_ulaw(pcm)))
    assert len(decoded) == len(samples)
    for original, got in zip(samples, decoded):
        # mu-law is lossy; allow ~5% of full scale
        assert abs(original - got) < 2500


def test_resample_16k_to_8k_halves_length():
    pcm = array("h", list(range(0, 1600))).tobytes()
    out = audio.resample_pcm16(pcm, 16000, 8000)
    assert len(out) == len(pcm) // 2


def test_wav_decode_reads_rate_and_mono():
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(24000)
        w.writeframes(array("h", [100, 100] * 2400).tobytes())
    pcm, rate = audio.decode_to_pcm16_mono(buf.getvalue())
    assert rate == 24000
    assert len(pcm) == 2400 * 2  # downmixed to mono


def test_vad_detects_utterance():
    vad = audio.Vad(threshold=500, silence_ms=200, min_speech_ms=100)
    ready = False
    for frame in _silence_frames(3):
        ready = vad.push(frame)
    for frame in _tone_frames(4000, 8):
        ready = vad.push(frame)
    for frame in _silence_frames(15):
        ready = vad.push(frame)
        if ready:
            break
    assert ready is True
    assert vad.has_speech
    assert len(vad.take()) > 0


def test_vad_ignores_silence_only():
    vad = audio.Vad(threshold=500, silence_ms=200, min_speech_ms=100)
    for frame in _silence_frames(30):
        vad.push(frame)
    assert vad.take() == b""


# ------------------------------------------------------------------ tools

def test_get_rate_never_leaks_floor():
    with SessionLocal() as db:
        res = voice_tools.execute(db, None, "get_rate", {"grain": "Gehu", "grade": "FAQ"})
    assert res["base_rate"] > 0
    assert "floor_rate" not in res
    assert "ceiling_rate" not in res


def test_calculate_price_breakdown():
    with SessionLocal() as db:
        res = voice_tools.execute(db, None, "calculate_price", {
            "grain": "Gehu", "quantity_qtl": 40, "zone": "Rampur",
            "vehicle_type": "pickup", "loading_by": "us",
        })
    assert res["grain_rate"] == 2500
    assert res["labour"] == 1400
    assert res["freight"] == 1800
    assert res["landed_total"] == 40 * 2500 + 1400 + 1800


def test_bargain_offer_stays_in_band():
    with SessionLocal() as db:
        offers = []
        for _ in range(6):
            res = voice_tools.execute(db, None, "next_bargain_offer",
                                      {"grain": "Gehu", "caller_ask": 9999})
            offers.append(res["offer"])
            assert 2470 <= res["offer"] <= 2540, f"out of band: {res}"
        assert offers == sorted(offers)


def test_booking_below_floor_is_rejected():
    with SessionLocal() as db:
        res = voice_tools.execute(db, None, "create_booking", {
            "caller_name": "Test", "grain": "Gehu", "quantity_qtl": 10, "final_rate": 2000,
        })
    assert res.get("error") == "below_floor"


def test_escalate_sets_human():
    call_id = None
    with SessionLocal() as db:
        from app.voice.pipeline import ensure_call
        call_id = ensure_call("+911234567890")
    with SessionLocal() as db:
        call = db.get(Call, call_id)
        voice_tools.execute(db, call, "escalate_to_human", {"reason": "complaint"})
    with SessionLocal() as db:
        assert db.get(Call, call_id).status == "human"


# ------------------------------------------------------------------ agent

def test_number_guard():
    assert extract_numbers("Rs 2,500 per quintal") == {2500}
    assert numbers_ok("Aaj 2500 rupaye hai", {2500}) is True
    assert numbers_ok("Aaj 9999 rupaye hai", {2500}) is False
    assert numbers_ok("Ek second ji, 40 quintal", {40}) is True


def test_offline_agent_greets():
    with SessionLocal() as db:
        reply = _offline_reply(db, None, "hello")
    assert "RGT Gola Gaddi" in reply.text
    assert reply.offline is True


def test_offline_agent_quotes_rate_from_tools():
    with SessionLocal() as db:
        reply = _offline_reply(db, None, "gehu ka rate kya hai")
    assert "get_rate" in reply.used_tools
    assert "2500" in reply.text


def test_offline_agent_bargains():
    with SessionLocal() as db:
        from app.voice.pipeline import ensure_call
        call_id = ensure_call("+919888877776")
    with SessionLocal() as db:
        call = db.get(Call, call_id)
        call.grain_name = "Gehu"
        db.commit()
        reply = _offline_reply(db, call, "bhaav thoda badha do")
    assert "next_bargain_offer" in reply.used_tools
    assert "rupaye" in reply.text


# ------------------------------------------------------------------ endpoints

def test_simulate_endpoint():
    with client() as c:
        r = c.post("/voice/simulate", headers=HEADERS,
                   json={"text": "gehu ka rate kya hai", "phone": "+919700000001"})
        assert r.status_code == 200
        data = r.json()
        assert data["reply"]
        assert "get_rate" in data["tools_used"]
        assert data["sarvam_configured"] is False


def test_simulate_requires_auth():
    with client() as c:
        r = c.post("/voice/simulate", json={"text": "hi"})
        assert r.status_code == 401


def test_twilio_webhook_returns_twiml():
    with client() as c:
        r = c.post("/telephony/twilio/voice",
                   data={"From": "+919812345678", "CallSid": "CA123"})
        assert r.status_code == 200
        assert "application/xml" in r.headers["content-type"]
        assert "<Connect>" in r.text
        assert "/telephony/twilio/stream" in r.text


def test_voice_status():
    with client() as c:
        r = c.get("/voice/status")
        assert r.status_code == 200
        body = r.json()
        assert body["telephony"] == ["twilio"]
        assert body["telephony_rate"] == 8000


def test_twilio_media_stream_handshake():
    """Drives the real Media Streams handler: start -> media -> stop."""
    import base64
    with client() as c:
        with c.websocket_connect("/telephony/twilio/stream") as ws:
            ws.send_text('{"event":"start","start":{"streamSid":"MZ123",'
                         '"customParameters":{"caller":"+919812345678"}}}')
            frame = base64.b64encode(b"\x00" * 160).decode()
            for _ in range(5):
                ws.send_text('{"event":"media","streamSid":"MZ123",'
                             '"media":{"payload":"%s"}}' % frame)
            ws.send_text('{"event":"stop","streamSid":"MZ123"}')
        # Reaching here without an exception means the handler ran cleanly.
    assert True
