"""End-to-end smoke tests for the RGT control API."""
import os
import pathlib

DB_PATH = pathlib.Path(__file__).parent / "test_rgt.db"
if DB_PATH.exists():
    DB_PATH.unlink()

os.environ["DATABASE_URL"] = f"sqlite:///{DB_PATH}"
os.environ["APP_API_KEY"] = "test-key"
os.environ["SARVAM_API_KEY"] = ""

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

HEADERS = {"X-API-Key": "test-key"}


def client() -> TestClient:
    return TestClient(app)


def test_health_is_public():
    with client() as c:
        r = c.get("/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"


def test_auth_required():
    with client() as c:
        assert c.get("/rates").status_code == 401
        assert c.get("/rates", headers={"X-API-Key": "wrong"}).status_code == 401


def test_rates_seeded_and_current():
    with client() as c:
        rates = c.get("/rates", headers=HEADERS).json()
        assert len(rates) >= 7
        one = c.get("/rates/current", params={"grain": "Gehu", "grade": "FAQ"}, headers=HEADERS).json()
        assert one["grain"] == "Gehu"
        assert one["floor_rate"] <= one["base_rate"]
        assert one["stale"] is False


def test_publish_rate_validation():
    with client() as c:
        bad = c.post("/rates/publish", headers=HEADERS, json={
            "rates": [{"grain": "Gehu", "grade": "FAQ", "base_rate": 2400, "floor_rate": 2500}]
        })
        assert bad.status_code == 422  # floor > base

        good = c.post("/rates/publish", headers=HEADERS, json={
            "rates": [{"grain": "Bajra", "grade": "FAQ", "base_rate": 2360,
                       "floor_rate": 2320, "ceiling_rate": 2400, "step": 10, "max_rounds": 3,
                       "direction": "up"}]
        })
        assert good.status_code == 200
        assert good.json()["published"] == 1


def test_quote_landed_price():
    with client() as c:
        q = c.post("/pricing/quote", headers=HEADERS, json={
            "grain": "Gehu", "grade": "FAQ", "quantity_qtl": 40,
            "zone": "Rampur", "vehicle_type": "pickup", "loading_by": "us",
        }).json()
        # 40 * 2500 grain + labour (15+12+8 per qtl = 35*40=1400) + freight 45*40=1800
        assert q["grain_rate"] == 2500
        assert q["labour"] == 1400
        assert q["freight"] == 1800
        assert q["landed_total"] == 40 * 2500 + 1400 + 1800
        assert len(q["lines"]) >= 3


def test_bargain_never_below_floor():
    with client() as c:
        # direction "up" on Gehu: base 2500, floor 2470, ceiling 2540, step 10
        seen = []
        for rnd in range(0, 6):
            r = c.post("/bargain/next", headers=HEADERS, json={
                "grain": "Gehu", "grade": "FAQ", "round_no": rnd, "caller_ask": 2600,
            }).json()
            seen.append(r["offer"])
            assert r["offer"] >= r["floor_rate"], "floor breached!"
            assert r["offer"] <= 2540, "ceiling breached!"
        assert seen == sorted(seen), "offers must not go backwards"
        assert seen[-1] == 2540  # capped at ceiling


def test_bargain_close_and_escalate():
    with client() as c:
        close = c.post("/bargain/next", headers=HEADERS, json={
            "grain": "Gehu", "grade": "FAQ", "round_no": 0, "caller_ask": 2450,
        }).json()
        assert close["action"] == "close"

        esc = c.post("/bargain/next", headers=HEADERS, json={
            "grain": "Gehu", "grade": "FAQ", "round_no": 99, "caller_ask": 9999,
        }).json()
        assert esc["action"] == "escalate"
        assert esc["at_limit"] is True


def test_instruction_floor_guard():
    with client() as c:
        calls = c.get("/calls", headers=HEADERS).json()
        gehu = next(x for x in calls if x["grain"] == "Gehu")
        call_id = gehu["id"]
        # Gehu ceiling is 2540; asking the assistant to promise 3000 must be blocked
        blocked = c.post(f"/calls/{call_id}/instruction", headers=HEADERS, json={
            "text": "Is party ko 3000 de do", "issued_by": "Supervisor"
        })
        assert blocked.status_code == 409
        assert blocked.json()["detail"]["error"] == "floor_override_required"

        allowed = c.post(f"/calls/{call_id}/instruction", headers=HEADERS, json={
            "text": "Is party ko 3000 de do", "issued_by": "Admin", "admin_override": True
        })
        assert allowed.status_code == 200


def test_takeover_and_booking_flow():
    with client() as c:
        call_id = c.get("/calls", headers=HEADERS).json()[0]["id"]
        t = c.post(f"/calls/{call_id}/takeover", headers=HEADERS).json()
        assert t["status"] == "human"

        b = c.post("/bookings", headers=HEADERS, json={
            "call_id": call_id, "caller_name": "Test Kisan", "phone": "+919000000000",
            "grain": "Gehu", "quantity_qtl": 40, "final_rate": 2500,
            "labour": 1400, "freight": 1800,
        }).json()
        assert b["total"] == 40 * 2500 + 1400 + 1800
        assert b["status"] == "new"

        upd = c.patch(f"/bookings/{b['id']}", headers=HEADERS, json={"status": "confirmed"}).json()
        assert upd["status"] == "confirmed"


def test_analytics_and_live():
    with client() as c:
        a = c.get("/analytics/summary", headers=HEADERS).json()
        assert a["total_calls"] >= 5
        assert a["floor_breach"] == 0
        live = c.get("/calls/live", headers=HEADERS).json()
        assert live["count"] >= 1


def test_voice_requires_sarvam_key():
    with client() as c:
        r = c.post("/voice/speak", headers=HEADERS, json={"text": "Namaste"})
        assert r.status_code == 503
        assert "SARVAM_API_KEY" in r.json()["detail"]
