variable "aws_region" {
  description = "AWS region. ap-south-1 (Mumbai) is closest to the callers."
  type        = string
  default     = "ap-south-1"
}

variable "environment" {
  description = "Environment name, used in resource names and tags."
  type        = string
  default     = "prod"
}

variable "app_name" {
  description = "Short name used for ECR repo, App Runner service and secrets."
  type        = string
  default     = "rgt-api"
}

variable "sarvam_api_key" {
  description = "Sarvam subscription key. Stored in Secrets Manager, never in the image."
  type        = string
  sensitive   = true
  default     = ""
}

variable "db_instance_class" {
  description = "RDS instance class. db.t4g.micro is plenty for the MVP."
  type        = string
  default     = "db.t4g.micro"
}

variable "db_name" {
  description = "Database name."
  type        = string
  default     = "rgt"
}

variable "db_username" {
  description = "Master username for RDS."
  type        = string
  default     = "rgt"
}

variable "app_cpu" {
  description = "App Runner CPU units: 256 = 0.25 vCPU, 1024 = 1 vCPU. Tool calls are light; 256 is plenty for the MVP."
  type        = string
  default     = "256"
}

variable "app_memory" {
  description = "App Runner memory in MB. With cpu=256 use 512 or 1024."
  type        = string
  default     = "1024"
}

variable "min_instances" {
  description = "Keep at least 1 so tool calls never hit a cold start mid-call."
  type        = number
  default     = 1
}

variable "max_instances" {
  description = "Upper bound for autoscaling."
  type        = number
  default     = 3
}

variable "deploy_service" {
  description = <<-EOT
    Create the App Runner service. Keep false on the first apply: the ECR image
    must exist before App Runner can start the service. Flow:
      1. terraform apply -var deploy_service=false
      2. ./deploy.sh          (builds and pushes the image)
      3. terraform apply -var deploy_service=true
  EOT
  type        = bool
  default     = false
}
