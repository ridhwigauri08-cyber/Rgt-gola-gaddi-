#!/usr/bin/env bash
#
# Build the API as a Lambda container image and create/update the function.
#
#   cp env.lambda.example env.lambda     # fill in DATABASE_URL, keys
#   ./deploy.sh
#
# Prerequisites: docker, aws cli v2, and credentials with ECR + Lambda rights.
# The image must be linux/amd64 - Lambda does not run arm64 from a local Mac
# build unless you target it explicitly.

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$(cd "$HERE/../.." && pwd)"          # repo root, contains Dockerfile.lambda
ENV_FILE="${ENV_FILE:-$HERE/env.lambda}"

FUNCTION_NAME="${FUNCTION_NAME:-rgt-api}"
REGION="${AWS_REGION:-ap-south-1}"
MEMORY="${MEMORY:-1024}"
TIMEOUT="${TIMEOUT:-30}"                       # API Gateway caps at 29s anyway
IMAGE_TAG="${IMAGE_TAG:-latest}"

need() { command -v "$1" >/dev/null 2>&1 || { echo "ERROR: '$1' not found" >&2; exit 1; }; }
need docker
need aws

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: $ENV_FILE not found. Copy env.lambda.example and fill it in." >&2
  exit 1
fi

# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

: "${DATABASE_URL:?DATABASE_URL must be set in $ENV_FILE (RDS Postgres)}"
: "${APP_API_KEY:?APP_API_KEY must be set in $ENV_FILE}"

if [[ "$DATABASE_URL" == sqlite* ]]; then
  echo "ERROR: DATABASE_URL is SQLite. Lambda has no writable disk - use RDS." >&2
  exit 1
fi

ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
REGISTRY="$ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com"
REPO="$REGISTRY/$FUNCTION_NAME"
IMAGE_URI="$REPO:$IMAGE_TAG"

echo "Function : $FUNCTION_NAME"
echo "Region   : $REGION"
echo "Image    : $IMAGE_URI"
echo

# ------------------------------------------------------------------ ECR
aws ecr describe-repositories --repository-names "$FUNCTION_NAME" --region "$REGION" >/dev/null 2>&1 \
  || aws ecr create-repository --repository-name "$FUNCTION_NAME" --region "$REGION" \
       --image-scanning-configuration scanOnPush=true >/dev/null

aws ecr get-login-password --region "$REGION" \
  | docker login --username AWS --password-stdin "$REGISTRY"

docker build --platform linux/amd64 -f "$APP_DIR/Dockerfile.lambda" -t "$IMAGE_URI" "$APP_DIR"
docker push "$IMAGE_URI"

# ------------------------------------------------------------------ env vars
# Everything except DATABASE_URL is optional; empty values are skipped.
python3 - "$ENV_FILE" > /tmp/lambda_env.json <<'PY'
import json, sys, pathlib
keep = {}
for line in pathlib.Path(sys.argv[1]).read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    v = v.strip().strip('"').strip("'")
    if v:
        keep[k.strip()] = v
keep.setdefault("RATE_STALE_AFTER_HOURS", "14")
print(json.dumps({"Variables": keep}))
PY

# ------------------------------------------------------------------ function
if aws lambda get-function --function-name "$FUNCTION_NAME" --region "$REGION" >/dev/null 2>&1; then
  echo "Updating existing function..."
  aws lambda update-function-code --function-name "$FUNCTION_NAME" \
    --image-uri "$IMAGE_URI" --region "$REGION" >/dev/null
  aws lambda wait function-updated --function-name "$FUNCTION_NAME" --region "$REGION"
  aws lambda update-function-configuration --function-name "$FUNCTION_NAME" \
    --timeout "$TIMEOUT" --memory-size "$MEMORY" \
    --environment "file:///tmp/lambda_env.json" --region "$REGION" >/dev/null
else
  echo "Creating function..."
  ROLE_ARN="${ROLE_ARN:-}"
  if [[ -z "$ROLE_ARN" ]]; then
    echo "ERROR: ROLE_ARN not set. Create a Lambda execution role first, e.g." >&2
    echo "  aws iam create-role --role-name rgt-lambda-role \\" >&2
    echo "    --assume-role-policy-document '{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Principal\":{\"Service\":\"lambda.amazonaws.com\"},\"Action\":\"sts:AssumeRole\"}]}'" >&2
    echo "  aws iam attach-role-policy --role-name rgt-lambda-role \\" >&2
    echo "    --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole" >&2
    echo "  (add AWSLambdaVPCAccessExecutionRole if the database is in a VPC)" >&2
    exit 1
  fi
  aws lambda create-function --function-name "$FUNCTION_NAME" \
    --package-type Image --code "ImageUri=$IMAGE_URI" \
    --role "$ROLE_ARN" --timeout "$TIMEOUT" --memory-size "$MEMORY" \
    --environment "file:///tmp/lambda_env.json" --region "$REGION" >/dev/null
  aws lambda wait function-active --function-name "$FUNCTION_NAME" --region "$REGION"
fi

# Optional: attach the function to a VPC so it can reach a private RDS.
if [[ -n "${VPC_SUBNET_IDS:-}" && -n "${VPC_SECURITY_GROUP_IDS:-}" ]]; then
  echo "Configuring VPC access..."
  aws lambda update-function-configuration --function-name "$FUNCTION_NAME" \
    --vpc-config "SubnetIds=${VPC_SUBNET_IDS},SecurityGroupIds=${VPC_SECURITY_GROUP_IDS}" \
    --region "$REGION" >/dev/null
fi

echo
echo "Function ready: $FUNCTION_NAME"
aws lambda get-function --function-name "$FUNCTION_NAME" --region "$REGION" \
  --query 'Configuration.[FunctionArn,State,LastUpdateStatus]' --output table

cat <<EOF

Next steps
----------
1. Create an HTTP API in front of it:
     aws apigatewayv2 create-api --name rgt-api-http --protocol-type HTTP --region $REGION
     aws apigatewayv2 create-integration --api-id <API_ID> --integration-type AWS_PROXY \\
       --integration-uri <FUNCTION_ARN> --payload-format-version 2.0 --region $REGION
     aws apigatewayv2 create-route --api-id <API_ID> --route-key 'ANY /{proxy+}' \\
       --target integrations/<INTEGRATION_ID> --region $REGION
     aws apigatewayv2 create-stage --api-id <API_ID> --stage-name '\$default' --auto-deploy --region $REGION

2. Allow API Gateway to invoke the function:
     aws lambda add-permission --function-name $FUNCTION_NAME --statement-id apigw \\
       --action lambda:InvokeFunction --principal apigateway.amazonaws.com \\
       --source-arn "<API_ARN>/*/*" --region $REGION

3. Kill cold starts (recommended for a voice agent):
     aws lambda put-provisioned-concurrency-config --function-name $FUNCTION_NAME \\
       --qualifier \$LATEST --provisioned-concurrent-executions 1 --region $REGION

4. Verify:
     curl -s "https://<API_ID>.execute-api.$REGION.amazonaws.com/health"

Remember: API Gateway times out at 29s, and WebSocket routes are not available.
EOF
