#!/usr/bin/env bash
#
# Build the API image and push it to ECR.
#
#   ./deploy.sh                      # uses terraform outputs
#   ./deploy.sh <repo-url> <region>  # explicit
#
# Requires: docker, aws cli v2, and credentials with ECR push rights.
#
# After pushing, trigger a deployment:
#   aws apprunner start-deployment --service-arn <arn>
# or re-run `terraform apply -var deploy_service=true`.

set -euo pipefail

TAG="${TAG:-latest}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$(cd "$HERE/../.." && pwd)"   # repo root (contains Dockerfile)
TF_DIR="$HERE/terraform"

need() {
  command -v "$1" >/dev/null 2>&1 || { echo "ERROR: '$1' not found in PATH" >&2; exit 1; }
}
need docker
need aws

# ---------------------------------------------------------------- resolve target
REPO_URL="${1:-}"
REGION="${2:-}"

if [[ -z "$REPO_URL" ]]; then
  if [[ -d "$TF_DIR" ]] && command -v terraform >/dev/null 2>&1; then
    echo "Reading ECR URL from terraform outputs..."
    REPO_URL="$(cd "$TF_DIR" && terraform output -raw ecr_repository_url 2>/dev/null || true)"
  fi
fi

if [[ -z "$REPO_URL" ]]; then
  cat >&2 <<'EOF'
ERROR: ECR repository URL unknown.

Run one of:
  cd terraform && terraform apply -var deploy_service=false && cd ..
  ./deploy.sh
or pass it explicitly:
  ./deploy.sh 123456789012.dkr.ecr.ap-south-1.amazonaws.com/rgt-api ap-south-1
EOF
  exit 1
fi

REGION="${REGION:-$(echo "$REPO_URL" | cut -d. -f4)}"
REGISTRY="${REPO_URL%%/*}"

echo "Repository : $REPO_URL"
echo "Registry   : $REGISTRY"
echo "Region     : $REGION"
echo "Tag        : $TAG"
echo "Build dir  : $APP_DIR"
echo

# ---------------------------------------------------------------- build & push
aws ecr describe-repositories --repository-names "$(basename "$REPO_URL")" \
  --region "$REGION" >/dev/null

aws ecr get-login-password --region "$REGION" \
  | docker login --username AWS --password-stdin "$REGISTRY"

docker build --platform linux/amd64 -t "$REPO_URL:$TAG" "$APP_DIR"
docker push "$REPO_URL:$TAG"

echo
echo "Pushed $REPO_URL:$TAG"

# ---------------------------------------------------------------- trigger deploy
if command -v terraform >/dev/null 2>&1 && [[ -d "$TF_DIR" ]]; then
  SERVICE_ARN="$(cd "$TF_DIR" && terraform output -raw service_arn 2>/dev/null || true)"
  if [[ -n "${SERVICE_ARN:-}" ]]; then
    echo "Starting App Runner deployment..."
    aws apprunner start-deployment --service-arn "$SERVICE_ARN" --region "$REGION" >/dev/null
    echo "Deployment started. Watch it with:"
    echo "  aws apprunner describe-service --service-arn $SERVICE_ARN --region $REGION"
  else
    echo "Service ARN not found yet. Run: terraform apply -var deploy_service=true"
  fi
fi
