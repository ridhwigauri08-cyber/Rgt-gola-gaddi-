"""
AWS Lambda entry point.

API Gateway (HTTP API) -> Lambda -> this handler -> FastAPI app, via Mangum.

Two things are different from running under uvicorn:

1. Lambda's filesystem is read-only except /tmp, and /tmp is discarded between
   invocations. SQLite therefore cannot work - DATABASE_URL must point at RDS
   (or another networked database). We fail loudly rather than silently losing
   every rate and booking.

2. WebSocket routes (`/calls/live/ws`, `/telephony/twilio/stream`) are not
   reachable through API Gateway. They stay registered but unused; the dashboard
   polls the HTTP endpoints instead.
"""
from __future__ import annotations

import os

from mangum import Mangum

from .config import settings
from .main import app


class LambdaConfigError(RuntimeError):
    """Raised when the app is about to run on Lambda with unusable settings."""


def ensure_lambda_safe_config() -> None:
    """Refuse to start on Lambda with a filesystem database."""
    if not os.getenv("AWS_LAMBDA_FUNCTION_NAME"):
        return  # not on Lambda (local run, tests, uvicorn) - nothing to check
    if settings.database_url.startswith("sqlite"):
        raise LambdaConfigError(
            "DATABASE_URL is SQLite, which cannot work on Lambda (read-only "
            "filesystem, /tmp is wiped between invocations). Point it at RDS: "
            "postgresql+psycopg://user:pass@host:5432/rgt?sslmode=require"
        )


ensure_lambda_safe_config()

# lifespan="on" runs the FastAPI startup (create_all + seed) on each cold start.
handler = Mangum(app, lifespan="on")
