"""ORM models mirroring PRD section 10 (Data Model)."""
from datetime import datetime, date

from sqlalchemy import (
    Boolean, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


class Grain(Base):
    __tablename__ = "grains"
    __table_args__ = (UniqueConstraint("name", "grade", name="uq_grain_grade"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(64), index=True)
    grade: Mapped[str] = mapped_column(String(32), default="FAQ")
    unit: Mapped[str] = mapped_column(String(16), default="qtl")


class DailyRate(Base):
    __tablename__ = "daily_rates"

    id: Mapped[int] = mapped_column(primary_key=True)
    grain_id: Mapped[int] = mapped_column(ForeignKey("grains.id"), index=True)
    location: Mapped[str] = mapped_column(String(64), default="Kota", index=True)
    date: Mapped[date] = mapped_column(Date, default=date.today)
    base_rate: Mapped[float] = mapped_column(Float)
    floor_rate: Mapped[float] = mapped_column(Float)
    # Optional hard ceiling, used when the assistant concedes upward (farmer selling).
    ceiling_rate: Mapped[float | None] = mapped_column(Float, nullable=True)
    step: Mapped[float] = mapped_column(Float, default=10.0)
    max_rounds: Mapped[int] = mapped_column(Integer, default=3)
    direction: Mapped[str] = mapped_column(String(8), default="down")  # "down" | "up"
    valid_from: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    valid_till: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="live")  # live | pending | stale
    created_by: Mapped[str] = mapped_column(String(64), default="system")
    approved_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    grain: Mapped[Grain] = relationship(lazy="joined")


class QuantitySlab(Base):
    __tablename__ = "quantity_slabs"

    id: Mapped[int] = mapped_column(primary_key=True)
    rate_id: Mapped[int] = mapped_column(ForeignKey("daily_rates.id"), index=True)
    min_qty: Mapped[float] = mapped_column(Float)
    max_qty: Mapped[float | None] = mapped_column(Float, nullable=True)
    extra_discount: Mapped[float] = mapped_column(Float, default=0.0)


class LabourCharge(Base):
    __tablename__ = "labour_charges"

    id: Mapped[int] = mapped_column(primary_key=True)
    grain_name: Mapped[str] = mapped_column(String(64), default="*")  # "*" = applies to all
    type: Mapped[str] = mapped_column(String(32))  # load | unload | tulai | silai
    rate: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(16), default="qtl")  # qtl | bori | truck


class FreightCharge(Base):
    __tablename__ = "freight_charges"

    id: Mapped[int] = mapped_column(primary_key=True)
    zone: Mapped[str] = mapped_column(String(64), index=True)
    vehicle_type: Mapped[str] = mapped_column(String(32), index=True)
    rate_per_qtl: Mapped[float] = mapped_column(Float)
    min_charge: Mapped[float] = mapped_column(Float, default=0.0)


class Caller(Base):
    __tablename__ = "callers"

    id: Mapped[int] = mapped_column(primary_key=True)
    phone: Mapped[str] = mapped_column(String(24), unique=True, index=True)
    name: Mapped[str | None] = mapped_column(String(64), nullable=True)
    village: Mapped[str | None] = mapped_column(String(64), nullable=True)
    type: Mapped[str] = mapped_column(String(16), default="kisan")  # kisan | vyapari
    tag: Mapped[str | None] = mapped_column(String(16), nullable=True)  # VIP | blocked
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class Call(Base):
    __tablename__ = "calls"

    id: Mapped[int] = mapped_column(primary_key=True)
    caller_id: Mapped[int | None] = mapped_column(ForeignKey("callers.id"), nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    language: Mapped[str] = mapped_column(String(16), default="hi-IN")
    status: Mapped[str] = mapped_column(String(16), default="ai")  # ai | queue | human
    grain_name: Mapped[str | None] = mapped_column(String(64), nullable=True)
    quantity_qtl: Mapped[float | None] = mapped_column(Float, nullable=True)
    offered_rate: Mapped[float | None] = mapped_column(Float, nullable=True)
    round_no: Mapped[int] = mapped_column(Integer, default=0)
    sentiment: Mapped[str] = mapped_column(String(16), default="neutral")
    outcome: Mapped[str | None] = mapped_column(String(16), nullable=True)
    recording_url: Mapped[str | None] = mapped_column(String(256), nullable=True)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)

    caller: Mapped[Caller | None] = relationship(lazy="joined")
    turns: Mapped[list["CallTurn"]] = relationship(back_populates="call", cascade="all, delete-orphan")


class CallTurn(Base):
    __tablename__ = "call_turns"

    id: Mapped[int] = mapped_column(primary_key=True)
    call_id: Mapped[int] = mapped_column(ForeignKey("calls.id"), index=True)
    speaker: Mapped[str] = mapped_column(String(16))  # ai | caller | queue-ai | human
    text: Mapped[str] = mapped_column(Text)
    text_hi: Mapped[str | None] = mapped_column(Text, nullable=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    call: Mapped[Call] = relationship(back_populates="turns")


class BargainRound(Base):
    __tablename__ = "bargain_rounds"

    id: Mapped[int] = mapped_column(primary_key=True)
    call_id: Mapped[int | None] = mapped_column(ForeignKey("calls.id"), nullable=True, index=True)
    round_no: Mapped[int] = mapped_column(Integer)
    caller_ask: Mapped[float | None] = mapped_column(Float, nullable=True)
    ai_offer: Mapped[float] = mapped_column(Float)
    ts: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Booking(Base):
    __tablename__ = "bookings"

    id: Mapped[int] = mapped_column(primary_key=True)
    call_id: Mapped[int | None] = mapped_column(ForeignKey("calls.id"), nullable=True)
    caller_name: Mapped[str] = mapped_column(String(64))
    phone: Mapped[str] = mapped_column(String(24))
    grain_name: Mapped[str] = mapped_column(String(64))
    quantity_qtl: Mapped[float] = mapped_column(Float)
    final_rate: Mapped[float] = mapped_column(Float)
    labour: Mapped[float] = mapped_column(Float, default=0.0)
    freight: Mapped[float] = mapped_column(Float, default=0.0)
    total: Mapped[float] = mapped_column(Float)
    delivery_date: Mapped[str | None] = mapped_column(String(32), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="new")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Instruction(Base):
    __tablename__ = "instructions"

    id: Mapped[int] = mapped_column(primary_key=True)
    call_id: Mapped[int | None] = mapped_column(ForeignKey("calls.id"), nullable=True, index=True)
    text: Mapped[str] = mapped_column(Text)
    type: Mapped[str] = mapped_column(String(24), default="free-text")
    issued_by: Mapped[str] = mapped_column(String(64), default="system")
    ts: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    applied: Mapped[bool] = mapped_column(Boolean, default=True)


class SarvamEvent(Base):
    """One call-completion webhook from Sarvam Voice Agents."""

    __tablename__ = "sarvam_events"

    id: Mapped[int] = mapped_column(primary_key=True)
    interaction_id: Mapped[str | None] = mapped_column(String(128), index=True, nullable=True)
    attempt_id: Mapped[str | None] = mapped_column(String(128), index=True, nullable=True)
    app_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    caller_number: Mapped[str | None] = mapped_column(String(32), nullable=True)
    agent_phone_number: Mapped[str | None] = mapped_column(String(32), nullable=True)
    direction: Mapped[str | None] = mapped_column(String(16), nullable=True)
    completion_status: Mapped[str | None] = mapped_column(String(32), nullable=True)
    connectivity_status: Mapped[str | None] = mapped_column(String(32), nullable=True)
    duration_sec: Mapped[float | None] = mapped_column(Float, nullable=True)
    started_at: Mapped[str | None] = mapped_column(String(40), nullable=True)
    ended_at: Mapped[str | None] = mapped_column(String(40), nullable=True)
    transcript_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    raw_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    received_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class CallbackRequest(Base):
    """A callback request raised from the public end-user app."""

    __tablename__ = "callback_requests"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60))
    phone: Mapped[str] = mapped_column(String(20), index=True)
    grain: Mapped[str | None] = mapped_column(String(64), nullable=True)
    quantity_qtl: Mapped[float | None] = mapped_column(Float, nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="new")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
