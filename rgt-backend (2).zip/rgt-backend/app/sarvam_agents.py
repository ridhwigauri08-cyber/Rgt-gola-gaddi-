"""
Sarvam Voice Agents (Samvaad) client.

This is a DIFFERENT API from the model APIs in `sarvam.py`:

    model APIs        api.sarvam.ai          header: api-subscription-key
    Voice Agents      apps.sarvam.ai         header: X-API-Key  (workspace key)

Do not mix the two keys up.

Endpoints used (all documented at docs.sarvam.ai):

    GET  /app-authoring/v1/orgs/{org}/workspaces/{ws}/deployments
    GET  /analytics/v1/{org}/{ws}/{app}/interactions
    GET  /analytics/v1/{org}/{ws}/{app}/transcripts/{interaction_id}
    GET  /analytics/v1/{org}/{ws}/{app}/recordings/{interaction_id}
    POST /outbounds/v1/orgs/{org}/workspaces/{ws}/outbounds
"""
from __future__ import annotations

import urllib.parse
from datetime import datetime, timedelta, timezone
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

import httpx

from .config import settings

APP_AUTHORING_BASE = "https://apps.sarvam.ai/api/app-authoring"
ANALYTICS_BASE = "https://apps.sarvam.ai/api/analytics"
OUTBOUNDS_BASE = "https://apps.sarvam.ai/api/outbounds"

IST = timezone(timedelta(hours=5, minutes=30))


class SarvamAgentsError(RuntimeError):
    """Raised when the Voice Agents API is not configured or the call fails."""

    def __init__(self, message: str, status_code: int | None = None, body: str = "") -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


def is_configured() -> bool:
    return settings.agents_configured


def _headers() -> dict[str, str]:
    return {
        "X-API-Key": settings.sarvam_workspace_api_key,
        "Accept": "application/json",
    }


def _require() -> None:
    if not settings.agents_configured:
        raise SarvamAgentsError(
            "Voice Agents API is not configured. Set X_API_KEY (the workspace key "
            "sent as the X-API-Key header), plus SARVAM_ORG_ID, "
            "SARVAM_WORKSPACE_ID and SARVAM_APP_ID on the server."
        )


def _org_ws() -> str:
    return f"/v1/orgs/{settings.sarvam_org_id}/workspaces/{settings.sarvam_workspace_id}"


def _analytics_prefix() -> str:
    return f"/v1/{settings.sarvam_org_id}/{settings.sarvam_workspace_id}/{settings.sarvam_app_id}"


async def _get(url: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    _require()
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(url, headers=_headers(), params=params)
        if resp.status_code >= 400:
            raise SarvamAgentsError(
                f"GET {url} failed with {resp.status_code}", resp.status_code, resp.text[:500]
            )
        return resp.json()


# --------------------------------------------------------------------------
# Deployments
# --------------------------------------------------------------------------

async def list_deployments(limit: int = 20, search: str | None = None) -> dict[str, Any]:
    params: dict[str, Any] = {"limit": limit}
    if search:
        params["search"] = search
    return await _get(f"{APP_AUTHORING_BASE}{_org_ws()}/deployments", params)


async def get_deployment() -> dict[str, Any] | None:
    """Our configured deployment, or None if it isn't in the workspace."""
    data = await list_deployments(limit=100)
    for item in data.get("items", []):
        if item.get("deployment_id") == settings.sarvam_deployment_id:
            return item
    return None


# --------------------------------------------------------------------------
# Interactions (call records)
# --------------------------------------------------------------------------

def _iso(dt: datetime) -> str:
    return dt.astimezone(IST).isoformat()


async def list_interactions(
    hours: int = 24,
    limit: int = 50,
    offset: int = 0,
    include_transcript: bool = False,
    sort_order: str = "desc",
) -> dict[str, Any]:
    """
    Conversations for the agent in a time window.

    `start_datetime` / `end_datetime` are required by the API and must carry an
    offset, so we always send IST.
    """
    end = datetime.now(IST)
    start = end - timedelta(hours=max(1, min(hours, 24 * 30)))
    params = {
        "start_datetime": _iso(start),
        "end_datetime": _iso(end),
        "limit": max(1, min(limit, 1000)),
        "offset": max(0, offset),
        "sort_order": sort_order,
        "include_transcript": str(include_transcript).lower(),
    }
    return await _get(f"{ANALYTICS_BASE}{_analytics_prefix()}/interactions", params)


async def get_transcript(interaction_id: str) -> dict[str, Any]:
    """
    Turn-by-turn transcript. Roles here are `assistant` / `user`.

    The interaction id looks like `20261007/<uuid>`; the slash must be encoded.
    """
    encoded = urllib.parse.quote(interaction_id, safe="")
    return await _get(f"{ANALYTICS_BASE}{_analytics_prefix()}/transcripts/{encoded}")


async def get_recording(interaction_id: str) -> tuple[bytes, str]:
    """Raw recording bytes plus content-type."""
    _require()
    encoded = urllib.parse.quote(interaction_id, safe="")
    url = f"{ANALYTICS_BASE}{_analytics_prefix()}/recordings/{encoded}"
    async with httpx.AsyncClient(timeout=60.0) as client:
        resp = await client.get(url, headers=_headers())
        if resp.status_code >= 400:
            raise SarvamAgentsError(
                f"recording fetch failed with {resp.status_code}", resp.status_code, resp.text[:300]
            )
        return resp.content, resp.headers.get("content-type", "audio/wav")


# --------------------------------------------------------------------------
# Instant outbound
# --------------------------------------------------------------------------

async def create_outbound(
    user_phone_number: str,
    app_version: int | None = None,
    agent_variables: dict[str, Any] | None = None,
    webhook_url: str | None = None,
    language: str | None = None,
) -> dict[str, Any]:
    """
    Place one outbound AI call.

    Needs `app_version` and a telephony `connection_id`. If app_version is not
    supplied we read it from the deployment.
    """
    _require()
    if not settings.sarvam_connection_id:
        raise SarvamAgentsError(
            "SARVAM_CONNECTION_ID is not set. The Instant Outbound API needs the "
            "telephony connection id and the agent phone number from your workspace."
        )

    version = app_version
    if version is None:
        deployment = await get_deployment()
        version = int(deployment["app_version"]) if deployment and deployment.get("app_version") else 1

    app_config: dict[str, Any] = {
        "app_id": settings.sarvam_app_id,
        "app_version": version,
        "connection_config": {
            "connection_id": settings.sarvam_connection_id,
            "agent_phone_number": settings.sarvam_agent_phone_number,
        },
    }
    if agent_variables:
        app_config["agent_variables"] = agent_variables
    if language:
        app_config["app_overrides"] = {"initial_language_name": language}

    payload: dict[str, Any] = {
        "app_config": app_config,
        "user_config": {"user_phone_number": user_phone_number},
    }
    if webhook_url:
        payload["webhook_config"] = {"url": webhook_url}

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{OUTBOUNDS_BASE}{_org_ws()}/outbounds",
            headers={**_headers(), "Content-Type": "application/json"},
            json=payload,
        )
        if resp.status_code >= 400:
            raise SarvamAgentsError(
                f"outbound call failed with {resp.status_code}", resp.status_code, resp.text[:500]
            )
        return resp.json()


# --------------------------------------------------------------------------
# Mapping helpers (the dashboard talks in one shape)
# --------------------------------------------------------------------------

def estimate_cost_inr(duration_seconds: float | None) -> float | None:
    """Estimated call cost. Rounded half-up, the way money is normally rounded."""
    if duration_seconds is None:
        return None
    value = (
        Decimal(str(duration_seconds))
        / Decimal(60)
        * Decimal(str(settings.sarvam_cost_per_minute))
    )
    return float(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def normalise_interaction(item: dict[str, Any]) -> dict[str, Any]:
    """
    Turn one Sarvam interaction into the shape our app and DB use.

    Written defensively: field names in the raw payload are read with fallbacks
    because the public schema for the item is not fully enumerated in the docs.
    """
    duration = item.get("duration_in_seconds") or item.get("duration")
    interaction_id = item.get("interaction_id") or item.get("id")
    ended_by = item.get("ended_by")
    status = item.get("status") or item.get("completion_status")

    transcript = item.get("original_transcript") or item.get("interaction_transcript") or []
    turns = []
    for t in transcript if isinstance(transcript, list) else []:
        if not isinstance(t, dict):
            continue
        role = (t.get("role") or "").lower()
        turns.append({
            "speaker": "AI" if role in ("agent", "assistant") else "Caller",
            "text": t.get("content") or t.get("en_text") or t.get("text") or "",
            "time": "",
        })

    return {
        "interaction_id": interaction_id,
        "caller_number": item.get("user_contact") or item.get("user_phone_number"),
        "caller_name": item.get("user_identifier"),
        "started_at": item.get("start_datetime") or item.get("attempted_at") or item.get("effective_datetime"),
        "duration_sec": int(duration) if isinstance(duration, (int, float)) else None,
        "status": status or ended_by or "unknown",
        "ended_by": ended_by,
        "direction": item.get("channel_direction") or item.get("direction"),
        "cost_inr": estimate_cost_inr(duration if isinstance(duration, (int, float)) else None),
        "has_transcript": bool(turns),
        "transcript": turns,
    }
